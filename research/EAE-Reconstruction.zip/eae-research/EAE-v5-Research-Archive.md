# EAE v5: byte-range writes and in-place mmap editing

20 September 2026. Runnable Rust 0.5.0 research implementation. V1–V4 reports and benchmarks remain in the archive.

**Implemented:** `delta::DeltaEngine` edits its exclusively borrowed anonymous mmap in place, saves byte-sized undo ranges in memory, and appends only merged byte-range redo records at commit. It never rounds a commit payload up to a page. Eight-byte updates now emit eight payload bytes rather than 4096. Historical snapshots remain immutable by reconstructing separate mappings from the committed records.

This removes **page-copy write amplification**, not every form of write amplification. Record metadata remains, and actual filesystem/device writes are not measured. The file is temporary and the publication index is in memory: this is not a crash-recoverable database.

## Algorithm and correctness

1. `begin()` exclusively borrows the engine. Existing borrowed live bytes cannot overlap a transaction in safe Rust.
2. `write(offset, bytes)` validates bounds, copies the previous byte range to an undo entry, then modifies the live mapping at the same logical address. Empty writes and identical writes of at most 64 bytes are skipped.
3. Commit sorts and unions overlapping/adjacent submitted ranges. It reads each union's final bytes from the live mapping, so overlapping writes are logged once with their final values.
4. Serialize one record: 16-byte transaction header, then one 16-byte `(offset, length)` descriptor and exact payload per merged range. Append with `write_all_at`; optionally call `sync_data`.
5. Only after successful output, publish an immutable in-memory record node. Snapshots hold an Arc to the node; commits do not copy the full history index. History destruction uses an iterative loop to avoid stack overflow.
6. Dropping an uncommitted transaction, or a write/sync error, restores undo entries in reverse order. Reserve the log extent before output, so failed partial records are orphaned and subsequent commits do not reuse them. Unpublished records are absent from the snapshot chain.
7. Opening a snapshot walks its committed record chain, reads records in commit order and applies them to a fresh zero-filled anonymous mmap. Returned views expose immutable slices. Latest-version reads can instead borrow the live mapping directly and need no replay.

Cap’n Proto segment-relative offsets do not change. The raw API leaves wire layout and allocation ownership to its caller. Independent Cap’n Proto tests decode both the live mapping and a reconstructed older struct/Text version. The delta path does not implement the v4 page-rebinding relocation API or a complete Cap’n Proto builder.

### Why not overwrite the existing snapshot file?

A shared file mapping exposes mutations to other mappings. A private mapping also does not guarantee a stable snapshot when the underlying file is subsequently changed: Linux specifies that visibility of such changes is unspecified. Consequently, simply replacing page-COW output with `pwrite(old_offset, eight_bytes)` would break the previous snapshot contract. [Linux mmap documentation](https://man7.org/linux/man-pages/man2/mmap.2.html)

V5 chooses a mutable in-memory working image plus immutable byte records. It performs in-place **memory** updates; it does not overwrite old snapshot data on disk. Positional writes can target exact byte ranges, but short writes must still be handled; Rust's `write_all_at` does that here. [Rust FileExt documentation](https://doc.rust-lang.org/std/os/unix/fs/trait.FileExt.html)

A direct disk-in-place mode could avoid record headers if it discarded retained snapshots and transactional rollback guarantees. Recoverable in-place transactions would require an undo/redo protocol and recovery implementation. Neither is silently substituted for the existing snapshot behavior.

## Bytes actually submitted to file I/O

| Transaction | Application bytes | V4 page payload | V5 payload | V5 total record | V5 total/application |
|---|---:|---:|---:|---:|---:|
| One 8-byte field | 8 | 4,096 | 8 | 40 | 5.00× |
| 32 scattered 8-byte fields | 256 | 131,072 | 256 | 784 | 3.0625× |
| One 4 KiB range | 4,096 | 4,096 | 4,096 | 4,128 | 1.0078× |
| One 1 MiB range | 1,048,576 | 1,048,576 | 1,048,576 | 1,048,608 | 1.00003× |
| 32 scattered 4 KiB ranges | 131,072 | 131,072 | 131,072 | 131,600 | 1.0040× |

For the small-write cases, payload amplification falls from **512× to 1×**. Including the v5 record metadata, file bytes fall **102.4×** for one word and **167.2×** for 32 scattered words. V4's metadata was only in RAM; its reported file bytes contain no persisted manifest overhead.

Accounting is based on the union of submitted ranges, not a byte-by-byte diff against the initial transaction state. A caller submitting an entire page still requests a page's payload. Writes that change and then restore a value in the same transaction can still emit a record. Undo and staging buffers also copy bytes in RAM; this is not a zero-copy algorithm.

## Same-run throughput and latency comparison

Decimal MB/s, median of three trial throughput values. V4 and v5 alternate run order. No trial or outlier is removed.

| Workload | V4 application MB/s | V5 application MB/s | V4 p50 µs | V5 p50 µs |
|---|---:|---:|---:|---:|
| One 8-byte field | 2.586 | 9.828 | 2.789 | 0.744 |
| 32 scattered 8-byte fields | 6.756 | 79.371 | 29.183 | 2.573 |
| One 4 KiB range | 1,409.505 | 1,275.556 | 2.544 | 2.929 |
| One 1 MiB range | 3,231.602 | 2,016.688 | 287.614 | 493.095 |
| 32 scattered 4 KiB ranges | 3,944.818 | 2,499.722 | 31.320 | 46.506 |

The measured benefit is small edits: **3.80×** application throughput for one word and **11.75×** for 32 scattered words. Full-buffer writes regress because v5 also allocates/copies undo bytes and stages a record. Keep `Mode::Batched` for workloads dominated by full pages or frequent snapshot opening; use `DeltaEngine` for small edits with frequent live reads. No automatic hybrid strategy is implemented.

Each case uses an 8 MiB segment, 20 warm-up transactions, then 1500 single-word, 1000 scattered-word, 1000 4 KiB, 100 1 MiB, or 300 scattered-page transactions. Both modes use the same offsets and values. Timing includes begin, writes, undo/dirty tracking, commit, snapshot publication and dropping the returned snapshot. Input generation, initialization, validation and snapshot reconstruction are outside write timing. Throughput is total application bytes divided by the sum of measured transaction durations, divided by 1,000,000; it is not derived from p50. Percentiles shown are medians of per-trial percentiles.

Buffered file writes, no fsync, no recovery protocol, shared Linux host. These are page/delta engine microbenchmarks, not disk durability, network, serialization or end-to-end application bandwidth. Raw CSV preserves a slow v4 scattered-word trial (0.849 MB/s) and a slow v4 1 MiB trial (1214.640 MB/s). Results are noisy and have no confidence interval.

## Snapshot cost is the explicit tradeoff

| Workload/history at measurement | V4 view construction µs | V5 view reconstruction µs |
|---|---:|---:|
| 1520 single-word commits | 30.332 | 573.868 |
| 1020 scattered-word commits | 160.566 | 1322.261 |
| 1020 4 KiB commits | 25.440 | 1331.543 |
| 120 1 MiB commits | 42.518 | 43819.012 |
| 320 scattered-page commits | 161.229 | 11028.686 |

Median of one final-view opening measurement per trial. V4 binds file mappings lazily; v5 eagerly reads/replays history. Subsequent validation and page faults during that validation are excluded, so this table measures construction latency, not complete traversal latency. Snapshot handle creation itself shares a record node; it does not replay. Cache an opened immutable view for repeated historical reads. Direct live reads bypass reconstruction entirely.

V5 reconstruction is O(total committed history bytes plus record count), not O(current live data size). Memory includes touched live pages, transaction undo bytes, a reusable serialized-record buffer, one metadata node per commit, and each opened snapshot's reconstructed pages. No checkpoints, bounded replay, history GC or durable reopen are implemented. Checkpointing can bound replay but would reintroduce amortized bulk writes; it must be accounted for explicitly in any future design.

## Validation and reproduction

**86 executed cases pass in debug and release**, including 10 new cases (9 integration tests and 1 compile-fail borrowing doctest). Strict Clippy with warnings denied and formatting checks pass.

New coverage: exact byte accounting; pinned and already-open snapshots; overlap/adjacency and cross-page ranges; reverse-order abort; no-op and overflow checks; snapshots surviving engine drop and cross-thread use; partial log-write failure followed by successful recovery within the process; 16,000 randomized range writes across 8 seeds with model comparison and scheduled aborts; stock Cap’n Proto live/old-version decoding; and iterative destruction of 20,000 history nodes. The previous 76 page-engine cases remain. These are not power-loss, Miri or race-detector tests.

```sh
cd rust
cargo test --all-features --locked
cargo test --release --all-features --locked
cargo clippy --all-targets --all-features --locked -- -D warnings
cargo fmt --check
cargo run --release --locked --bin delta_throughput > delta-throughput-results.csv
python3 summarize_delta.py
```

Sources: `rust/src/delta.rs`, `rust/tests/delta.rs`, `rust/src/bin/delta_throughput.rs`. Raw measurements: `rust/delta-throughput-results.csv`; derived medians: `rust/delta-throughput-summary.json`. Historical v4 numbers are preserved separately; the comparison above reruns both implementations in this session.
