# EAE v2: page-versioned virtual segments for Cap’n Proto and mmap

Reconstructed 20 September 2026. Supersedes the v1 recommendation for workloads needing snapshots; the simpler v1 exclusive editor remains useful for small, transient messages.

**The principal change: separate an object's logical position from the physical file pages that hold its bytes.** Keep standard Cap’n Proto words in contiguous virtual segments. Version the segment's logical-page-to-file-page mapping. A small edit then copies changed pages, not the complete containing object or its ancestor objects.

This is a proposed storage architecture with a working Linux mmap experiment, not a complete database or a claim of a new underlying virtual-memory technique. The experiments verify the central mapping mechanism and selected Cap’n Proto layouts. Durable metadata publication, general allocation and stock-runtime interoperability remain implementation gates.

## 1. What changes from v1

| Concern | v1 | Reconstructed v2 |
|---|---|---|
| Object identity | Stable ID, relocatable body | Same, but physical page moves do not relocate the logical body |
| Snapshot edits | Copy changed objects and ancestors | Copy changed logical pages; version the page map |
| Space accounting | Allocated body and retained contiguous capacity | Logical extent reservation separate from populated physical pages |
| Small allocations | Global best-fit extent indexes | Proposed slab/size-class allocation by page and update locality |
| Growing large lists | Doubling with occasional body copies | Sparse logical reservation; page rebinding for eligible scalar relocation |
| Reclamation | Clear freed bytes eagerly in prototype | Release logical allocation metadata; initialize before reuse |
| Compaction | Move objects, repair pointers | First repack physical pages at unchanged logical positions |
| Storage | Mutable mapped container with journal | Immutable physical pages plus recoverable generation publication |

The reader still sees normal Cap’n Proto segments. The backing file is **a custom container**, not an ordinary stream-framed message. Export is a separate operation.

## 2. The central invariant

For each version `v`:

```text
Map[v, segment, logical_page] -> immutable physical file page, or ZERO
```

For each snapshot mapping:

```text
segment_base + logical_byte_offset
```

addresses the correct bytes of that version, even when physically adjacent logical pages live at unrelated file offsets. Different snapshots get separate virtual mapping ranges.

| Same logical page | Version 7 | Version 8 |
|---|---|---|
| Root page | Physical page A | Physical page A |
| List page containing edited value | Physical page B | Physical page D |
| Unchanged list page | Physical page C | Physical page C |

Root and list pointers can be byte-identical across versions. Following them reaches the correct version because the snapshot's mappings differ. The file-page map is resolved at mapping time; ordinary field loads do not perform a software page-table lookup.

Cap’n Proto has segment-relative near pointers, segment-addressed far pointers, contiguous list representations, and separate composite-list tags. Its specification permits mmap-specific framing. Those properties motivate the design. [Encoding specification](https://capnproto.org/encoding.html)

**Physical relocation is not logical relocation.** Moving bytes to different file pages requires no wire-pointer repair if their logical addresses stay fixed. Moving an object to a different logical offset still requires the v1 pointer-repair rules.

## 3. Container and mapping layout

Proposed default, to be tuned rather than treated as an optimum:

- Logical segment limit: 256 MiB. Keep logical locations comfortably within pointer encoding bounds.
- Page granularity: host mapping page size, initially 4 KiB on Linux/x86-64. Store it in the container header. A container with smaller pages than another host can map is not automatically portable; require conversion or a compatible mapping granularity.
- Segment data pages: immutable once published.
- Metadata: a persistent, checksummed page-map tree, allocator state, segment directory and generation descriptor, outside the Cap’n Proto segments.
- Reader mappings: contiguous virtual ranges per mapped segment, read-only, tied to a pinned generation.
- Writer mapping: a private copy-on-write view of one committed generation, exclusively owned by one transaction.

Reserve each virtual segment as an anonymous zero mapping. Replace populated runs with file-backed mappings inside that owned reservation. Coalesce adjacent logical pages with adjacent physical offsets into one mapping call. `MAP_FIXED` is used only within the process's own reserved region and while constructing an unexposed view.

Linux permits private mappings and fixed-address mappings, but a private mapping is not itself a snapshot of externally overwritten backing bytes. Here, the committed backing pages are deliberately immutable. Page alignment, mapping errors and mapping lifetime remain explicit responsibilities. [mmap documentation](https://man7.org/linux/man-pages/man2/mmap.2.html)

A read-only runtime adapter receives the reconstructed segment slices/arrays. A stock stream reader cannot open the physical container directly. Interoperability must be checked using the target runtime's supported segment-reader interface. The C++ API distinguishes message readers/builders and segment access. [Cap’n Proto C++ serialization](https://capnproto.org/cxx.html)

Do not initialize or read a whole reserved segment on open: zero holes are not committed payload pages. Do not eagerly map every database segment if the runtime can request segments on demand; lazy mapping applies at segment boundaries. Transparent per-page first-access mapping needs a separate fault-handling system and is not part of this design.

## 4. The editing algorithm

```text
begin_transaction():
    acquire single-writer ownership
    pin current generation under the publication/reclamation lock
    build or obtain a private mutable view of that generation
    start transaction-local allocator and page-map updates
    dirty_pages = empty

write_range(segment, offset, length, operation):
    validate the logical allocation and checked bounds
    register all affected pages in dirty_pages BEFORE mutation
    perform operation through the transaction's private mapping
    # First write to an existing file-backed page triggers private COW.
    # Subsequent writes to the page in this transaction reuse that copy.

set_scalar(handle, field, value):
    locate object and field within this transaction
    write_range(field, width, store encoded value)

append(list, values):
    ensure logical capacity
    write_range(new payload range, initialize appended values)
    update the appropriate owner-pointer length and any tag
    # Both updates belong to this transaction's version, not a public view.

abort():
    discard private mappings and transaction-local metadata
    release pin and writer ownership
```

The explicit write barrier is essential: kernel COW does not tell this library which bytes to persist. All generated mutation methods, pointer repair, `memmove`, initialization and allocator metadata changes must participate. An API may offer a scoped `edit_range` that marks the range and returns a mutable slice. It must not expose unrestricted stock mutable builders that bypass tracking.

In debug mode, map unregistered pages read-only and enable ranges through the barrier, accepting extra `mprotect` calls and mapping pressure. Release mode can use a dirty bitmap plus a dirty-page list and range marking. The prototype uses explicit marking without page protection; it does not detect callers that bypass the API.

After commit, do not treat a still-writable transaction mapping as a reader snapshot. Either construct a new immutable view, or freeze it and prevent further writes. Keep all Rust borrows scoped to the transaction or pinned snapshot. Replacing a process's current generation must not remap bytes underneath existing reader slices.

### Why ancestor copying disappears

Changing a scalar in a large object leaves its logical location and enclosing pointers unchanged. The new generation maps the edited page to a new physical page. The old generation still maps it to the old page. No containing object's body needs copying merely to give its child a new physical location.

The page-map tree itself uses copy-on-write metadata updates. Thus ancestor copying moves out of the application object graph into a bounded-fanout storage index. It is reduced and controlled, not eliminated from every part of the system.

## 5. Allocation optimized for Cap’n Proto

Keep all allocator headers and freelist links outside wire-visible object bytes. Proposed three allocation paths:

| Object size/behavior | Proposed allocation | Reason |
|---|---|---|
| Small structs and short blobs | Size-class slabs, group objects commonly changed together | Cheap allocation and less page write amplification |
| Medium, mostly stable objects | Coalescing page/span allocator with modest capacity classes | Avoid large virtual holes for ordinary objects |
| Large, growing lists/Text/Data | Dedicated page-aligned logical extent, reserve growth room, populate pages on demand | Avoid copying and touching unused capacity |

Start with small-object classes up to roughly 512 bytes, medium spans up to roughly 64 KiB, and large dedicated extents above that. These are hypotheses, not measured crossover points. Do not force every tiny object onto its own page.

Track three distinct quantities:

```text
logical_length     = bytes currently represented by the wire layout
reserved_capacity  = exclusively owned logical address range
populated_pages    = actual backing pages referenced by this generation
```

The reserved tail is not a globally available free hole. But it also need not occupy physical file pages or RAM. Cap logical reservations per segment and per object; use expected maximum size when supplied, otherwise geometric growth and bounded extra headroom. A failed reservation must fall back to relocation or allocation failure, not steal another object's capacity.

A practical descriptor target is 32–48 bytes in a dense table, with an implicit object ID and bounded-width segment/offset/capacity fields. Exact owner-path encoding, composite-list element identity and generation widths need a Rust layout/API decision. Avoid claiming a specific descriptor size before implementation.

Small-object allocation should use slab bitmaps and non-full class lists rather than updating two global trees for every allocation. Large logical extents can use address-coalesced span indexes or a buddy allocator. Large physical writes should allocate contiguous runs where possible. Allocation policy is versioned with the message.

### Initialization and deletion

Do not clear dead pages merely because they were freed. For wholly dead logical pages, remove their mappings from the new generation; old generations retain their mappings. For holes within still-live pages, remember allocation state and initialize any bytes before exposing them again. A scalar append overwriting all eight new bytes requires no extra pre-zeroing; newly exposed pointer slots do.

Shrinking then growing must not expose old data accidentally. Track initialized length or explicitly initialize newly visible ranges. Clear partial bits for Boolean lists. Text still needs valid content and its new terminator. Export by traversing/copying live values or scrub unreachable bytes before exposing raw segments.

The format's separate data and pointer sections also permit schema-independent pointer repair without scanning scalar contents. Composite layouts require element-aware scans. Far landing pads remain owned allocations. Capability persistence stays outside this storage prototype.

## 6. Relocation without copying scalar payload

When a dedicated clean scalar list exhausts its reservation:

```text
relocate_scalar_extent(old, larger_reservation):
    require page-aligned, exclusive body pages and scalar-only layout
    allocate new logical extent
    rebind its complete pages to the old immutable physical pages
    copy/initialize any boundary fragments or dirty transaction pages
    remove the old logical page bindings in the new version
    update the inbound pointer and allocator metadata
```

This copies page-map entries instead of the payload. Old snapshots retain their old addresses and maps. A page-aligned 8 MiB scalar list has 2,048 page bindings; rebinding them is **not O(1)**. Extent descriptors can compress runs, but fragmented mappings still have a real metadata cost.

The prototype demonstrates the clean, aligned case. It changes only the owner-pointer payload page and aliases all 8 MiB of body pages into a new logical location.

Do not use this unchanged for pointer lists or arbitrary composite lists: outgoing near-pointer offsets would be wrong after a logical move. Those slots must be repaired. Mixed pages may require copying even if their scalar bytes could otherwise be shared. Dirty unpublished pages require copying or a separately implemented frame-transfer mechanism. Shared boundary pages cannot be remapped as if they belonged exclusively to one object.

If a whole subtree is moved by the same displacement within a segment, internal near offsets can remain unchanged, but proving the complete relocation closure and handling far pointers is nontrivial. It is a later optimization, not part of the validated path.

## 7. mmap needs a mapping-fragmentation budget

Updating random pages scatters a logical segment across file offsets. A virtual view then needs many mapping runs. The prototype produced **1,935** file mapping runs after 100 random transactions. Repacking those bytes in logical order reduced the count to **three** without changing any logical wire bytes.

Mapping-run count is not exactly VMA count: anonymous holes and kernel merging affect it. Budget both run count and actual process mappings across every simultaneously pinned view. Linux enforces a per-process mapping-area limit. [Kernel mapping-limit documentation](https://www.kernel.org/doc/html/latest/admin-guide/sysctl/vm.html)

Proposed policy:

1. Sort dirty pages by logical address and write adjacent dirty pages contiguously.
2. Track projected mapping runs per hot segment and across pinned versions.
3. Repack selected spans when projected open cost or mapping count exceeds a configured budget. Write them to new contiguous physical extents; publish the same logical bytes with a new page map.
4. Optionally rewrite a 64 KiB span when many constituent pages are dirty. This trades extra write bytes for fewer runs. Select using a measured cost function and maximum write-amplification budget, not a fixed assumption that bigger writes are always better.
5. Keep old pinned views unchanged. Repacking the latest version does not reduce the mapping count of old views. Admission limits or reader backpressure may be necessary.

Physical repacking costs read and write bandwidth and temporarily retains both copies. It is cheaper in pointer work than logical object compaction, but it is not free. Prefer background, bounded work; account for its bytes in benchmarks.

Long-lived immutable mappings amortize open cost. Beginning every tiny transaction by recreating thousands of mappings can erase the savings. A production writer may reuse its private address range between transactions, rebinding changed runs only after all mutable borrows end; this is not implemented in the prototype. Pool immutable views per generation when possible.

## 8. Durable commit: proposed protocol, not validated storage code

Use immutable data pages and immutable metadata-tree pages. Keep two generation descriptors in distinct, appropriately aligned/preallocated failure units. Never overwrite the currently authoritative descriptor while preparing its successor. Checksums detect accidental torn/corrupt records under an explicit storage fault model; they are not an unconditional proof against arbitrary hardware behavior.

```text
commit(tx):
    finalize and validate transaction-local logical allocation state
    write new physical images for dirty payload pages
    write changed page-map and allocator metadata pages
    flush data/metadata files successfully                    # barrier A
    write inactive generation descriptor with checksums
    flush descriptor successfully                            # barrier B
    publish generation to in-process readers under a lock
    acknowledge success
```

A generation descriptor identifies the segment directory, mapping-tree roots, allocator roots, format/page-size/version fields, generation and storage bounds. All of them change together. Batch changes to the same metadata leaf once per transaction; do not persist a full flat page map on every commit.

Recovery selects the highest valid committed descriptor under the defined failure model and validates required metadata. Interrupted unreferenced writes are garbage. During garbage collection, retain every physical page reachable from pinned snapshots, retained checkpoints **and recovery fallback roots**. Do not reuse a page just because the newest generation no longer references it. Publish physical-free-space changes transactionally too.

Readers pin a generation under the same synchronization that governs publication/reclamation. A single-writer lock simplifies transaction ordering. Multi-process reader death and leases require an explicit protocol; timeouts alone do not justify reclaiming potentially mapped pages.

`pwrite` may complete partially; retry appropriately and propagate errors. `fdatasync`/`fsync` failures prevent acknowledging a successful commit. If a descriptor write has started, the transaction outcome may be uncertain until recovery; do not report a guaranteed rollback. File creation/replacement may require directory synchronization. [pwrite documentation](https://man7.org/linux/man-pages/man2/pwrite.2.html), [fsync documentation](https://man7.org/linux/man-pages/man2/fsync.2.html)

The above two-barrier structure depends on immutable old pages, recoverable descriptors and correct reclamation. It does not rehabilitate the original proposal's arbitrary pointer-store commits. Torn writes, failed flushes, recovery during repeated crashes, descriptor placement and checkpoint reuse need fault-injection tests before this is durable. SQLite's atomic-commit discussion is a useful statement of the storage assumptions that must be made explicit. [SQLite atomic commit](https://www.sqlite.org/atomiccommit.html)

## 9. Correctness argument

Assume each committed page image is immutable while any retained generation references it, each version map is complete and valid, and mapped reader views never change during their lifetime.

1. Reading a logical byte under version V always reaches V's selected page image.
2. Writing through a private transaction mapping cannot alter an existing page image visible to V.
3. New payload and pointer/tag words are all selected by the new version map. Readers cannot combine an old pointer page with a new tag page within one pinned version.
4. Publication switches the entire generation descriptor, not individual publicly shared wire words.
5. Physical repacking preserves every logical byte, so it preserves the decoded message.
6. Logical scalar relocation preserves payload bytes through page bindings and changes its owner pointer within the new version only.

This supports stable snapshots without application-graph ancestor copying. It does not excuse invalid wire edits, missing dirty tracking, unsupported readers, or premature reuse.

## 10. What was implemented and measured

Two Linux C++ experiments are included under `v2/`.

`page_versions.cpp` uses actual mmap mappings and an unlinked temporary backing file. It encodes a root struct, an 8 MiB UInt64 list, Text and an inline-composite scalar list. Published physical pages are append-only. Different versions reconstruct the logical segment at different virtual bases. Explicit marking records mutated pages.

It checks scalar updates with unchanged ancestor pointers, Text and composite append snapshots, 3,200 randomized scalar writes across 100 transactions, ten pinned snapshots using repeated sampled checks, a full final-model comparison, abort, clean scalar page rebinding, and byte-for-byte physical repacking. Some payload writes are synchronized, but the version maps exist **only in process memory**. It is not reopenable after process exit and has no durable descriptor, page-map tree, physical reuse or crash recovery.

`growth_bench.cpp` compares the v1 scalar allocator, the same allocator without eager clearing, and dedicated sparse logical reservations using anonymous mmap. All execute one million appends across 64 lists; correctness checks occur outside the timer. It measures payload work, resident pages and local elapsed time, with no snapshot or durable commit layer. Reservations are fixed at 1 MiB per list in this workload, not automatically sized by a production allocator.

The code explicitly targets little-endian Linux with 4 KiB pages. No claim is made for another host ABI. Source builds without external libraries using GCC. The original v1 tests and archived report are retained in the package.

### Captured mmap results

| Experiment | Observed result |
|---|---|
| Scalar edit in 8 MiB list | 1 payload page; 4,096 payload bytes written |
| Text append | 2 payload pages |
| Composite-list append | 2 payload pages |
| Rebind 8 MiB scalar list to new logical location | 4,096 owner-pointer payload bytes written; body pages shared |
| Random edits | 3,200 across 100 transactions |
| Retained versions | 10 sampled repeatedly; final version checked exhaustively |
| Physical repacking | 1,935 mapping runs reduced to 3 |
| Snapshot, abort and repacking checks | Passed |

**The 4 KiB figure excludes durable metadata, commit records, page-table work and kernel COW traffic.** It is 2,048 times smaller than copying an entire 8 MiB list body for an object-level snapshot, not a measured 2,048-fold speedup. An exclusive in-place scalar update already needs no object copy; this design adds snapshot isolation rather than making that memory store cheaper. Other page-based storage designs can provide similar page-sized writes.

### Captured growth experiment

Median of seven local repetitions, GCC 13.3.0, `-O3`, Linux/x86-64. All rows append 1,000,000 UInt64 values across 64 lists. Timings include first-touch page faults and exclude correctness scans, construction and commit.

| Mode | Median ms | Copied words | Cleared words | Resident pages | Logical extent words |
|---|---:|---:|---:|---:|---:|
| v1_eager_clear | 40.5894 | 1032160 | 1032160 | 2111 | 1081278 |
| v2_lazy_clear | 40.5879 | 1032160 | 0 | 2111 | 1081278 |
| v2_reserved_large_lists | 40.1113 | 0 | 0 | 1984 | 8388608 |

Removing eager clearing eliminated 8,257,280 bytes of clearing in this workload. Sparse reservations also eliminated 8,257,280 copied bytes. But local median elapsed time remained approximately 40 ms in all three cases: **this experiment does not demonstrate a substantial throughput improvement**. Resident-page counts reflect this run's `mincore` observation, not a durability or disk-allocation measurement.

Reserved capacity uses 64 MiB of logical space for 8,000,000 bytes of payload. Only 1,984 pages, about 7.75 MiB, became resident in that arena. This is the intended space trade-off, not free capacity or an unlimited-growth guarantee. The old allocator's logical high-water range was much smaller.

## 11. Performance bounds and implementation choice

Let D be distinct modified logical pages, B the host page size, M new metadata pages, R mapping runs, and W the changed object's total bytes.

| Work | Proposed bound or cost |
|---|---|
| Scalar edit within a transaction | O(1) field work; at most first-write COW for its page |
| Transaction data-page output | D × B bytes, before repacking and metadata |
| Metadata output | M × B plus generation publication; depends on tree shape and batching |
| Open/map a version | Page-map traversal and O(R) mapping calls, plus later page faults |
| Scalar page rebinding | O(number of page bindings), plus boundary/dirty copies and owner update |
| Pointer-bearing logical relocation | O(W) worst-case repair/copy; no zero-copy claim |
| Append in reserved range | O(new bytes), plus affected length/tag pages and transaction overhead |
| Middle insertion in a flat list | O(tail bytes/pointers), still fundamental to the representation |
| Physical repacking | Read/write selected pages and change metadata; zero wire-pointer repairs |

For example, a one-page scalar edit plus three newly written page-map metadata pages and one 4 KiB descriptor would output 20 KiB, not 4 KiB. This is an illustrative accounting example, not the prototype's measured durable cost. Batch edits sharing pages and metadata paths to amortize those costs.

Implementation order:

1. Preserve the v1 exclusive editor's checked wire operations and stable handles.
2. Add the tested immutable-page mapping layer and snapshot-bound reader adapter.
3. Add tracked generated mutations, transaction-local allocator state and slab/span allocation.
4. Add sparse reservations for large append-heavy values; keep page rebinding restricted to eligible scalar extents.
5. Implement a persistent page-map tree, recoverable descriptor protocol and transactional physical reclamation.
6. Introduce mapping-run budgets, pooled views and bounded physical repacking based on measurements.

Keep a simpler exclusive memory mode for small transient messages. Choose the page-versioned mmap mode when persistent mutation and stable snapshots justify its metadata, mapping and page-sized write overhead. Avoid automatic object-neighbor evacuation on either mode's foreground path.

## 12. Reproduction and remaining gates

From the package's `eae-research` directory:

```sh
g++ -O2 -std=c++17 -Wall -Wextra -o /tmp/eae-pages v2/page_versions.cpp
/tmp/eae-pages
g++ -O3 -std=c++17 -Wall -Wextra -o /tmp/eae-growth v2/growth_bench.cpp
/tmp/eae-growth
```

Both create transient memory/storage only; the mmap prototype unlinks its temporary page store and retains version metadata in memory. Captured results are `v2/mmap-results.json` and `v2/growth-results.csv`. The final mmap source also passed a GCC undefined-behavior-sanitized run; see `v2/validation.txt`.

Still required before production: stock Cap’n Proto interoperability; far/double-far and capability policy; general struct/pointer-list/composite/Boolean mutations; checked malformed import; Rust borrow and write-barrier soundness; multi-thread/process pinning; persistent page maps; allocation exhaustion and mapping failures; metadata checksums and recovery; disk-full handling; torn-write and repeated-crash tests; cold-open, p99 latency, database-scale fragmentation and total-I/O benchmarks.

**Recommended algorithm:** retain standard Cap’n Proto logical layouts; version immutable backing pages; allocate small objects densely and large growing objects in sparse logical reservations; rebind eligible scalar pages on logical relocation; repack physical storage before attempting logical object compaction. This provides a concrete route to smaller snapshot writes without pretending that mmap, sparse address space or pointer publication removes the costs of storage management.
