# EAE v4: gathered page writes and MB/s benchmarks

20 September 2026. The v1–v3 reports remain in the package as historical records.

**Implemented:** v4 gathers scattered dirty pages using positional vectored writes, updates page-table metadata by leaf, and avoids sorting when pages were discovered in order. The largest measured benefit is scattered work: about 2.2× application throughput for full-page writes and 2.4× for eight-byte fields on separate pages. Large contiguous writes show little reliable change.

This remains a Linux mmap research implementation. Cap’n Proto logical offsets remain stable while version maps select immutable physical file pages. Readers have separate mappings, and the writer retains private pages across transactions. Generation metadata is process-local; the backing file is temporary and append-only. The results below measure buffered transactions, not durable disk, serialization, network or full-application throughput.

## Algorithm changes

V3 batches adjacent logical pages, but 32 scattered dirty pages still require 32 logical positional writes. V4 gathers those same pages from the writer mapping into one contiguous physical output batch.

```text
commit_v4:
    obtain unique dirty-page list
    sort only if discovery order was not monotonic
    for each batch of at most 256 pages:
        reserve consecutive physical output space
        coalesce adjacent source pages into iovec entries
        if all source pages are adjacent:
            write the contiguous slice directly
        else:
            pwritev the spans in logical-page order
        update each affected page-table leaf as a batch
    optionally synchronize payload bytes
    publish the new process-local page-map generation
    retain private writer pages and reusable descriptor storage
```

No staging buffer copies the gathered payload. The kernel still copies buffered write data; this is not zero-copy disk I/O. Physical output order matches writing the pages sequentially in separate calls. Pointer encoding, logical positions, snapshot semantics and write amplification are unchanged.

Batches are limited to 1 MiB and 256 vectors. The vector allocation is reused. `pwritev` may complete partially or be interrupted; the wrapper advances both file offset and vector position until complete, rejects zero writes and propagates errors. [Linux positional vectored I/O documentation](https://man7.org/linux/man-pages/man2/pwritev.2.html)

Metadata updates obtain mutable ownership once per affected page-table leaf rather than checking root/leaf ownership for every page. Dirty tracking records whether page discovery remains ordered. V3 writer-cache retention, bitmap deduplication, identical-small-write suppression and explicit cache trimming remain active.

`Mode::Optimized` preserves v3 for comparison; `Mode::Batched` selects v4. `Mode::Baseline` is the older v2-style reference path. These are strategies in the same Rust engine, not competing production databases.

## Throughput definitions and method

**MB = 1,000,000 bytes.** KiB/MiB workload sizes are binary.

```text
application_MB_s = application bytes submitted / summed transaction seconds / 1,000,000
page_output_MB_s = page-image bytes output / summed transaction seconds / 1,000,000
```

Timed work includes transaction begin, application stores/copies, dirty tracking, output calls, metadata changes and in-memory publication. Input generation, setup/warm-up, validation, reader-view opening, fsync and durable-manifest work are excluded equally for both modes. Throughput uses total bytes divided by total timed duration, not bytes divided by median latency.

For 32 full 4 KiB pages, both byte counts are 131,072 per transaction. For 32 eight-byte fields on different pages, application work is 256 bytes and output is 131,072 bytes: **512× write amplification**. Reporting page output as application throughput would exaggerate useful throughput by that factor.

Configuration: Rust 1.90.0, release build, 64-bit Linux, 4 KiB pages, one writer, 32 MiB logical segment, temporary file/page cache. Each workload has three trials and 20 warm-up transactions per mode/trial. Mode order reverses on the middle trial. There are 100–1,500 measured transactions per trial depending on workload. See `rust/throughput-results.csv` for exact parameters and every observation.

## Results

The following values are medians of three per-trial application-throughput measurements, not confidence intervals.

| Workload | V3 application MB/s | V4 application MB/s | Ratio |
|---|---:|---:|---:|
| 4 KiB contiguous write | 959.03 | 1,052.00 | 1.10× |
| 64 KiB contiguous write | 3,413.73 | 3,541.98 | 1.04× |
| 1 MiB contiguous write | 3,327.72 | 3,350.36 | 1.01× |
| 32 scattered full pages (128 KiB) | 1,642.02 | 3,642.25 | 2.22× |
| 32 scattered eight-byte values (256 B) | 3.34 | 8.03 | 2.41× |
| One eight-byte value | 2.63 | 2.69 | 1.02× |

The clear improvement is scattered work: logical output batches fell from 32 to one. Contiguous and single-value differences overlap run-to-run variation. The 1 MiB case had a slow v3 first trial and a v4 tail outlier; all observations are retained, with neither removed from the median calculation. These short, shared-host measurements are not service-level guarantees.

### V4 useful work versus whole-page output

| Workload | Application MB/s | Page-output MB/s | Output/application bytes |
|---|---:|---:|---:|
| 4 KiB contiguous write | 1,052.00 | 1,052.00 | 1× |
| 64 KiB contiguous write | 3,541.98 | 3,541.98 | 1× |
| 1 MiB contiguous write | 3,350.36 | 3,350.36 | 1× |
| 32 scattered full pages (128 KiB) | 3,642.25 | 3,642.25 | 1× |
| 32 scattered eight-byte values (256 B) | 8.03 | 4,113.63 | 512× |
| One eight-byte value | 2.69 | 1,376.62 | 512× |

Page-output MB/s means writes accepted by the buffered file interface, not measured device bandwidth. Durable throughput cannot yet be measured because persistent publication and recovery are unimplemented.

### Latency cross-check

| Workload | V3 p50 µs | V4 p50 µs | V3 p99 µs | V4 p99 µs |
|---|---:|---:|---:|---:|
| 4 KiB contiguous write | 2.93 | 2.83 | 24.55 | 18.38 |
| 64 KiB contiguous write | 17.43 | 17.16 | 79.38 | 51.49 |
| 1 MiB contiguous write | 292.48 | 282.94 | 562.22 | 539.08 |
| 32 scattered full pages (128 KiB) | 74.94 | 33.80 | 174.85 | 100.81 |
| 32 scattered eight-byte values (256 B) | 71.15 | 28.47 | 184.37 | 96.07 |
| One eight-byte value | 2.70 | 2.79 | 5.08 | 4.82 |

These are medians of trial-specific percentiles, not percentiles of pooled samples. Full-page scattered median latency fell from about 75 to 34 µs; scattered word-edit latency fell from about 71 to 28 µs. Raw trial values remain available.

## Validation

The suite executes **76 passing cases**:

- 31 shared regression cases in v3 mode and the same 31 in v4 mode, with mode-specific batch expectations.
- Four vectored-I/O unit tests covering partial writes, interruptions, zero writes, error propagation and empty vectors.
- Two gather tests covering out-of-order dirty pages, zero holes, metadata-leaf boundaries, the 256-page output-batch boundary and old snapshots.
- Six stock `capnp 0.21.7` reader tests, now using v4, including canonical comparison, scalar relocation, backward near pointers, composite versions and handcrafted far/double-far layouts.
- Two compile-fail borrowing tests.

The shared randomized test applies 23,040 attempted writes per engine mode, compares an independent byte-vector model after every transaction, and checks retained snapshots. Existing injected failures verify that committed metadata remains unchanged after output/publication/flush failures and that subsequent transactions recover.

The partial-write test accepts only three bytes per callback and interrupts an intermediate attempt. This specifically tests vector advancement without relying on the host to produce short writes. On output error, no new manifest is published; the reserved append range is orphaned and never reused. This is tested process-level failure handling, not torn-sector or power-loss recovery.

## Reproduction and files

From `rust/`:

```sh
cargo test --all-features --locked
cargo test --release --all-features --locked
cargo clippy --all-targets --all-features --locked -- -D warnings
cargo fmt --check
cargo run --release --locked --bin throughput > throughput-results.csv
```

`throughput-summary.csv` and `.json` contain medians. The raw CSV contains byte counts, summed timed duration, both MB/s rates, transactions/second, p50/p99 and logical batch counts. A batch may need additional system calls after short writes. Historical latency files are retained but are not the current v3/v4 comparison.

Current code: `src/lib.rs`, `src/bin/throughput.rs`, `tests/common/regressions.rs`, both regression-mode entry points, `tests/gather.rs`, and `tests/stock_reader.rs`. The core has no external runtime crate dependency; the independent reader is a pinned development dependency. No schema compiler is needed.

## Remaining limits

Raw writes validate memory ranges, not a complete Cap’n Proto ownership graph. Scalar relocation requires a logically unused destination and is intentionally limited. General generated builders, hardened import and arbitrary pointer-bearing mutation are not implemented.

Generation metadata is process-local. There is no reopenable store, persistent root publication, crash recovery, physical reclamation or automatic cache budget. Payload synchronization does not persist a recoverable manifest. Explicit cache trimming and reader-view construction still cost time. Gathered writes do not reduce the page output caused by isolated small edits.

Use `Mode::Batched` for the current prototype, particularly for transactions touching scattered pages. Keep useful-byte and page-output metrics separate. Measure durable MB/s only after persistent publication and recovery exist.
