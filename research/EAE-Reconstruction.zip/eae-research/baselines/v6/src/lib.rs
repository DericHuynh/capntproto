//! Linux research engines for mutable Cap'n Proto-compatible segment bytes.
//! Legacy page/delta engines have temporary files and process-local publication.
//! The optional `durable` adapter adds recovery and checkpointing, not a full DB.
//! Snapshot views are immutable; mutable access is transaction-borrowed.
#![deny(unsafe_op_in_unsafe_fn)]
#[cfg(not(all(target_os = "linux", target_pointer_width = "64")))]
compile_error!("This prototype supports 64-bit Linux only");
pub mod delta;
pub mod durable;
use std::ffi::c_void;
use std::fs::{File, OpenOptions};
use std::io::{self, Error, ErrorKind};
use std::os::fd::AsRawFd;
use std::os::unix::fs::FileExt;
use std::ptr::NonNull;
use std::sync::{
    atomic::{AtomicU64, Ordering},
    Arc,
};

pub const PAGE: usize = 4096;
const LEAF: usize = 256;
const ZERO: u64 = u64::MAX;
const MAX_BYTES: usize = 256 * 1024 * 1024;
const READ: i32 = 1;
const WRITE: i32 = 2;
const PRIVATE: i32 = 2;
const FIXED: i32 = 0x10;
const ANON: i32 = 0x20;
unsafe extern "C" {
    fn mmap(
        addr: *mut c_void,
        len: usize,
        prot: i32,
        flags: i32,
        fd: i32,
        offset: i64,
    ) -> *mut c_void;
    fn munmap(addr: *mut c_void, len: usize) -> i32;
    fn sysconf(name: i32) -> i64;
    fn pwritev(fd: i32, iov: *const IoVec, count: i32, offset: i64) -> isize;
}
fn invalid(s: &str) -> Error {
    Error::new(ErrorKind::InvalidInput, s)
}
fn bounds(bytes: usize, pos: usize, n: usize) -> io::Result<()> {
    if pos > bytes || n > bytes - pos {
        Err(invalid("range exceeds segment"))
    } else {
        Ok(())
    }
}

#[repr(C)]
#[derive(Clone, Copy)]
struct IoVec {
    base: *const u8,
    len: usize,
}

// The caller owns readable buffers throughout this synchronous operation.
// Mutating the descriptors after short writes never mutates their payload.
fn vectored_all_with(
    vecs: &mut [IoVec],
    mut offset: u64,
    mut write: impl FnMut(&[IoVec], u64) -> io::Result<usize>,
) -> io::Result<()> {
    let mut i = 0;
    while i < vecs.len() {
        if vecs[i].len == 0 {
            i += 1;
            continue;
        }
        let n = match write(&vecs[i..], offset) {
            Err(e) if e.kind() == ErrorKind::Interrupted => continue,
            x => x?,
        };
        if n == 0 {
            return Err(Error::new(ErrorKind::WriteZero, "zero vectored write"));
        }
        let remaining: usize = vecs[i..].iter().map(|v| v.len).sum();
        if n > remaining {
            return Err(Error::other("invalid vectored write count"));
        }
        offset = offset
            .checked_add(n as u64)
            .ok_or_else(|| invalid("offset overflow"))?;
        let mut consumed = n;
        while i < vecs.len() && consumed >= vecs[i].len {
            consumed -= vecs[i].len;
            i += 1;
        }
        if consumed != 0 {
            // SAFETY: consumed < this live buffer's remaining initialized length.
            vecs[i].base = unsafe { vecs[i].base.add(consumed) };
            vecs[i].len -= consumed;
        }
    }
    Ok(())
}
fn vectored_all(file: &File, vecs: &mut [IoVec], offset: u64) -> io::Result<()> {
    vectored_all_with(vecs, offset, |v, pos| {
        // SAFETY: descriptors refer to live readable Mapping bytes and stay
        // valid for this synchronous call. <=256 entries, <=1 MiB per batch.
        let n = unsafe { pwritev(file.as_raw_fd(), v.as_ptr(), v.len() as i32, pos as i64) };
        if n < 0 {
            Err(Error::last_os_error())
        } else {
            Ok(n as usize)
        }
    })
}

#[derive(Clone)]
struct Table {
    root: Arc<Vec<Arc<[u64; LEAF]>>>,
    pages: usize,
}
impl Table {
    fn new(pages: usize) -> Self {
        let zero = Arc::new([ZERO; LEAF]);
        Self {
            root: Arc::new(vec![zero; pages.div_ceil(LEAF)]),
            pages,
        }
    }
    fn get(&self, p: usize) -> u64 {
        self.root[p / LEAF][p % LEAF]
    }
    fn set_batch(&mut self, pages: &[usize], offset: u64) {
        let root = Arc::make_mut(&mut self.root);
        let mut i = 0;
        while i < pages.len() {
            let leaf_id = pages[i] / LEAF;
            let leaf = Arc::make_mut(&mut root[leaf_id]);
            while i < pages.len() && pages[i] / LEAF == leaf_id {
                leaf[pages[i] % LEAF] = offset + (i * PAGE) as u64;
                i += 1;
            }
        }
    }
    fn set(&mut self, p: usize, offset: u64) {
        Arc::make_mut(&mut Arc::make_mut(&mut self.root)[p / LEAF])[p % LEAF] = offset;
    }
}
struct Store {
    file: File,
}
static NEXT: AtomicU64 = AtomicU64::new(0);
impl Store {
    fn new() -> io::Result<Self> {
        let path = std::env::temp_dir().join(format!(
            "eae-rust-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create_new(true)
            .open(&path)?;
        std::fs::remove_file(&path)?;
        Ok(Self { file })
    }
}
struct Mapping {
    ptr: NonNull<u8>,
    bytes: usize,
}
impl Mapping {
    fn new(bytes: usize, writable: bool) -> io::Result<Self> {
        // SAFETY: anonymous mapping, nonzero page-aligned checked length.
        let ptr = unsafe {
            mmap(
                std::ptr::null_mut(),
                bytes,
                READ | if writable { WRITE } else { 0 },
                PRIVATE | ANON,
                -1,
                0,
            )
        };
        if ptr as isize == -1 {
            return Err(Error::last_os_error());
        }
        // A zero address is unusable as a Rust reference. Release it if returned.
        match NonNull::new(ptr.cast()) {
            Some(ptr) => Ok(Self { ptr, bytes }),
            None => {
                unsafe {
                    munmap(ptr, bytes);
                }
                Err(invalid("zero mapping address"))
            }
        }
    }
    fn bind(
        &mut self,
        store: &Store,
        page: usize,
        count: usize,
        offset: u64,
        writable: bool,
    ) -> io::Result<()> {
        bounds(self.bytes, page * PAGE, count * PAGE)?;
        let (flags, fd, off) = if offset == ZERO {
            (PRIVATE | FIXED | ANON, -1, 0)
        } else {
            if !offset.is_multiple_of(PAGE as u64) || offset > i64::MAX as u64 {
                return Err(invalid("file page offset"));
            }
            (PRIVATE | FIXED, store.file.as_raw_fd(), offset as i64)
        };
        // SAFETY: only replace pages in our owned reservation, with exclusive
        // access to Mapping. No view/reference survives a mutable operation.
        let result = unsafe {
            mmap(
                self.ptr.as_ptr().add(page * PAGE).cast(),
                count * PAGE,
                READ | if writable { WRITE } else { 0 },
                flags,
                fd,
                off,
            )
        };
        if result as isize == -1 {
            Err(Error::last_os_error())
        } else {
            Ok(())
        }
    }
    fn read(&self, pos: usize, n: usize) -> io::Result<&[u8]> {
        bounds(self.bytes, pos, n)?;
        // SAFETY: full virtual range is mapped and initialized (anonymous zeros
        // or complete immutable file pages). Returned slice is borrow-scoped.
        Ok(unsafe { std::slice::from_raw_parts(self.ptr.as_ptr().add(pos), n) })
    }
    fn write(&mut self, pos: usize, data: &[u8]) -> io::Result<()> {
        bounds(self.bytes, pos, data.len())?;
        // SAFETY: only called for exclusive writable transaction mappings. Safe
        // Rust cannot obtain data from this same mapping while borrowing &mut.
        unsafe {
            std::ptr::copy_nonoverlapping(data.as_ptr(), self.ptr.as_ptr().add(pos), data.len());
        }
        Ok(())
    }
}
impl Drop for Mapping {
    fn drop(&mut self) {
        unsafe {
            munmap(self.ptr.as_ptr().cast(), self.bytes);
        }
    }
}
fn contiguous(a: u64, b: u64, pages: usize) -> bool {
    if a == ZERO {
        b == ZERO
    } else {
        a.checked_add((pages * PAGE) as u64) == Some(b)
    }
}
fn map_all(store: &Store, table: &Table, writable: bool) -> io::Result<(Mapping, usize)> {
    let mut map = Mapping::new(table.pages * PAGE, writable)?;
    let mut i = 0;
    let mut calls = 1;
    while i < table.pages {
        if table.get(i) == ZERO {
            i += 1;
            continue;
        }
        let mut n = 1;
        while i + n < table.pages && contiguous(table.get(i), table.get(i + n), n) {
            n += 1;
        }
        map.bind(store, i, n, table.get(i), writable)?;
        calls += 1;
        i += n;
    }
    Ok((map, calls))
}
struct Dirty {
    ordered: bool,
    bits: Vec<u64>,
    pages: Vec<usize>,
}
impl Dirty {
    fn new(pages: usize) -> Self {
        Self {
            bits: vec![0; pages.div_ceil(64)],
            ordered: true,
            pages: Vec::new(),
        }
    }
    fn mark(&mut self, pos: usize, len: usize) {
        if len == 0 {
            return;
        }
        for p in pos / PAGE..=(pos + len - 1) / PAGE {
            let bit = 1 << (p % 64);
            if self.bits[p / 64] & bit == 0 {
                self.bits[p / 64] |= bit;
                if self.pages.last().is_some_and(|&last| last > p) {
                    self.ordered = false;
                }
                self.pages.push(p);
            }
        }
    }
    fn clear(&mut self) {
        for &p in &self.pages {
            self.bits[p / 64] = 0;
        }
        self.pages.clear();
        self.ordered = true;
    }
}
struct Work {
    iovecs: Vec<IoVec>,
    map: Mapping,
    dirty: Dirty,
}

/// Baseline deliberately reproduces v2's full scan/remap and page-at-a-time I/O.
/// Optimized retains writer mapping and batches adjacent pages. Same semantics.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    Baseline,
    Optimized,
    /// v4: gather scattered pages with pwritev and update metadata by leaf.
    Batched,
}
#[derive(Clone, Copy, Default, Debug)]
pub struct Stats {
    pub dirty_pages: usize,
    pub scanned_pages: usize,
    pub payload_bytes: usize,
    /// Logical write_all_at calls; a short write may cause extra kernel calls.
    pub write_batches: usize,
    pub mapping_calls: usize,
    pub changed_table_leaves: usize,
    pub root_entries_copied: usize,
}
/// Flushes payload bytes only. Even true DOES NOT make an in-memory manifest durable.
#[derive(Clone, Copy, Debug, Default)]
pub struct CommitOptions {
    pub sync_payload: bool,
}

#[derive(Clone)]
pub struct Snapshot {
    store: Arc<Store>,
    table: Table,
    generation: u64,
}
impl Snapshot {
    pub fn generation(&self) -> u64 {
        self.generation
    }
    pub fn bytes(&self) -> usize {
        self.table.pages * PAGE
    }
    pub fn view(&self) -> io::Result<View> {
        let (map, _) = map_all(&self.store, &self.table, false)?;
        Ok(View {
            map,
            _store: self.store.clone(),
        })
    }
    pub fn mapping_runs(&self) -> usize {
        let mut n = 0;
        let mut p = 0;
        while p < self.table.pages {
            if self.table.get(p) == ZERO {
                p += 1;
                continue;
            }
            n += 1;
            let start = p;
            p += 1;
            while p < self.table.pages
                && contiguous(self.table.get(start), self.table.get(p), p - start)
            {
                p += 1;
            }
        }
        n
    }
}
pub struct View {
    map: Mapping,
    _store: Arc<Store>,
}
// SAFETY: View exposes immutable bytes, its backing pages are never overwritten,
// and ownership keeps the mappings/store alive. No mutable API is provided.
unsafe impl Send for View {}
unsafe impl Sync for View {}
impl View {
    pub fn read(&self, pos: usize, n: usize) -> io::Result<&[u8]> {
        self.map.read(pos, n)
    }
    pub fn word(&self, word: usize) -> io::Result<u64> {
        let p = word
            .checked_mul(8)
            .ok_or_else(|| invalid("word overflow"))?;
        Ok(u64::from_le_bytes(self.read(p, 8)?.try_into().unwrap()))
    }
}
/// One writer; snapshots may be read concurrently. Store is private and append-only.
pub struct Engine {
    store: Arc<Store>,
    table: Table,
    generation: u64,
    tail: u64,
    cached: Option<Work>,
    mode: Mode,
    #[cfg(feature = "fault-injection")]
    failure: Option<Failure>,
}
#[cfg(feature = "fault-injection")]
#[derive(Clone, Copy, Debug)]
pub enum Failure {
    BeforeWrite,
    AfterFirstWrite,
    BeforePublish,
    PayloadSync,
}
impl Engine {
    pub fn new(bytes: usize, mode: Mode) -> io::Result<Self> {
        // Linux _SC_PAGESIZE; refuse incompatible host page granularity.
        if unsafe { sysconf(30) } != PAGE as i64 {
            return Err(invalid("requires 4 KiB host pages"));
        }
        if bytes == 0 || !bytes.is_multiple_of(PAGE) || bytes > MAX_BYTES {
            return Err(invalid("segment size must be page-aligned and <=256 MiB"));
        }
        Ok(Self {
            store: Arc::new(Store::new()?),
            table: Table::new(bytes / PAGE),
            generation: 0,
            tail: 0,
            cached: None,
            mode,
            #[cfg(feature = "fault-injection")]
            failure: None,
        })
    }
    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            store: self.store.clone(),
            table: self.table.clone(),
            generation: self.generation,
        }
    }
    pub fn begin(&mut self) -> io::Result<Transaction<'_>> {
        let (work, calls) = if let Some(work) = self.cached.take() {
            (work, 0)
        } else {
            let (map, calls) = map_all(&self.store, &self.table, true)?;
            (
                Work {
                    iovecs: Vec::new(),
                    map,
                    dirty: Dirty::new(self.table.pages),
                },
                calls,
            )
        };
        Ok(Transaction {
            engine: self,
            work: Some(work),
            stats: Stats {
                mapping_calls: calls,
                ..Stats::default()
            },
        })
    }
    /// Explicit bounded maintenance: replace at most `count` logical pages
    /// with their committed file/zero mappings, releasing private writer copies.
    /// Returns mmap call count. Does not alter snapshots or logical values.
    pub fn trim_writer_cache(&mut self, start: usize, count: usize) -> io::Result<usize> {
        let total = self.table.pages;
        if start > total || count > total - start {
            return Err(invalid("trim range"));
        }
        let Some(mut w) = self.cached.take() else {
            return Ok(0);
        };
        let mut p = start;
        let end = start + count;
        let mut calls = 0;
        while p < end {
            let off = self.table.get(p);
            let mut n = 1;
            while p + n < end && contiguous(off, self.table.get(p + n), n) {
                n += 1;
            }
            // On failure the private cache is dropped and rebuilt on next begin.
            w.map.bind(&self.store, p, n, off, true)?;
            calls += 1;
            p += n;
        }
        self.cached = Some(w);
        Ok(calls)
    }
    /// Explicit maintenance: discard the private writer cache. Committed
    /// snapshots remain valid; next begin rebuilds the writable mapping. No
    /// hidden cache flush is imposed on an ordinary transaction commit.
    pub fn release_writer_cache(&mut self) {
        self.cached = None;
    }
    /// Relocate a clean, page-aligned, whole-page UInt64 list. Destination must
    /// be an otherwise unused ZERO range; this prototype has no object allocator.
    /// Only the owner pointer is persisted; body physical pages are shared.
    pub fn move_u64_list(
        &mut self,
        owner_word: usize,
        dst_page: usize,
    ) -> io::Result<(Snapshot, Stats)> {
        let owner_pos = owner_word
            .checked_mul(8)
            .ok_or_else(|| invalid("owner overflow"))?;
        let ptr = {
            let tx = self.begin()?;
            u64::from_le_bytes(tx.read(owner_pos, 8)?.try_into().unwrap())
        };
        if ptr & 3 != 1 || (ptr >> 32) & 7 != 5 {
            return Err(invalid("requires UInt64 list"));
        }
        let src_word = near_target(owner_word as u64, ptr)?;
        let len = (ptr >> 35) as usize;
        if len == 0 || !len.is_multiple_of(PAGE / 8) || !src_word.is_multiple_of(PAGE as u64 / 8) {
            return Err(invalid("requires whole aligned pages"));
        }
        let src = usize::try_from(src_word / (PAGE as u64 / 8))
            .map_err(|_| invalid("source overflow"))?;
        let count = len / (PAGE / 8);
        let total = self.table.pages;
        if src > total || count > total - src || dst_page > total || count > total - dst_page {
            return Err(invalid("relocation range"));
        }
        if src < dst_page + count && dst_page < src + count {
            return Err(invalid("overlap"));
        }
        let owner_page = owner_pos / PAGE;
        if (src..src + count).contains(&owner_page)
            || (dst_page..dst_page + count).contains(&owner_page)
        {
            return Err(invalid("owner in moved range"));
        }
        for p in dst_page..dst_page + count {
            if self.table.get(p) != ZERO {
                return Err(invalid("occupied destination"));
            }
        }
        let new_ptr = near_pointer(
            owner_word as u64,
            (dst_page * PAGE / 8) as u64,
            1,
            (ptr >> 32) as u32,
        )?;
        let saved = self.table.clone();
        let cached = self.cached.take();
        let mut candidate = saved.clone();
        for p in 0..count {
            candidate.set(dst_page + p, saved.get(src + p));
            candidate.set(src + p, ZERO);
        }
        self.table = candidate;
        let result = (|| {
            let mut tx = self.begin()?;
            tx.put_word(owner_word, new_ptr)?;
            tx.commit(CommitOptions::default())
        })();
        if result.is_err() {
            self.table = saved;
            self.cached = cached;
        }
        // Failed appended bytes remain orphaned; tail is never rolled back.
        result
    }
    #[cfg(feature = "fault-injection")]
    pub fn inject_failure(&mut self, failure: Failure) {
        self.failure = Some(failure);
    }
}
/// A mutable byte borrow cannot survive another write:
/// ```compile_fail
/// use eae_pages::*;
/// let mut e=Engine::new(PAGE,Mode::Optimized).unwrap();
/// let mut tx=e.begin().unwrap();
/// let bytes=tx.read(0,8).unwrap();
/// tx.put_word(0,9).unwrap();
/// assert_eq!(bytes,[0;8]);
/// ```
/// Nor can it survive commit/unmapping:
/// ```compile_fail
/// use eae_pages::*;
/// let mut e=Engine::new(PAGE,Mode::Optimized).unwrap();
/// let tx=e.begin().unwrap();
/// let bytes=tx.read(0,8).unwrap();
/// let _=tx.commit(CommitOptions::default());
/// assert_eq!(bytes,[0;8]);
/// ```
pub struct Transaction<'a> {
    engine: &'a mut Engine,
    work: Option<Work>,
    stats: Stats,
}
impl Transaction<'_> {
    pub fn write(&mut self, pos: usize, bytes: &[u8]) -> io::Result<()> {
        let w = self.work.as_mut().unwrap();
        bounds(w.map.bytes, pos, bytes.len())?;
        // No-op writes avoid COW, dirty bookkeeping and commit I/O.
        if self.engine.mode != Mode::Baseline
            && bytes.len() <= 64
            && w.map.read(pos, bytes.len())? == bytes
        {
            return Ok(());
        }
        w.dirty.mark(pos, bytes.len());
        w.map.write(pos, bytes)
    }
    pub fn put_word(&mut self, word: usize, value: u64) -> io::Result<()> {
        self.write(
            word.checked_mul(8)
                .ok_or_else(|| invalid("word overflow"))?,
            &value.to_le_bytes(),
        )
    }
    pub fn read(&self, pos: usize, n: usize) -> io::Result<&[u8]> {
        self.work.as_ref().unwrap().map.read(pos, n)
    }
    pub fn dirty_pages(&self) -> usize {
        self.work.as_ref().unwrap().dirty.pages.len()
    }
    pub fn commit(mut self, options: CommitOptions) -> io::Result<(Snapshot, Stats)> {
        // Move Work out. Any error drops this mapping: engine reconstructs its
        // unchanged committed table next time. Partial appends are orphaned.
        let mut w = self.work.take().unwrap();
        let mut pages = if self.engine.mode == Mode::Baseline {
            self.stats.scanned_pages = self.engine.table.pages;
            (0..self.engine.table.pages)
                .filter(|&p| w.dirty.bits[p / 64] & (1 << (p % 64)) != 0)
                .collect::<Vec<_>>()
        } else {
            std::mem::take(&mut w.dirty.pages)
        };
        if self.engine.mode != Mode::Batched || !w.dirty.ordered {
            pages.sort_unstable();
        }
        self.stats.dirty_pages = pages.len();
        let mut table = self.engine.table.clone();
        #[cfg(feature = "fault-injection")]
        let failure = self.engine.failure.take();
        #[cfg(feature = "fault-injection")]
        if matches!(failure, Some(Failure::BeforeWrite)) {
            return Err(Error::other("injected before write"));
        }
        let mut i = 0;
        let mut last_leaf = None;
        while i < pages.len() {
            let start = pages[i];
            let mut n = 1;
            if self.engine.mode == Mode::Batched {
                n = (pages.len() - i).min(256);
            } else if self.engine.mode == Mode::Optimized {
                while i + n < pages.len() && pages[i + n] == start + n && n < 256 {
                    n += 1;
                }
            }
            let selected = &pages[i..i + n];
            let len = n * PAGE;
            let offset = self.engine.tail;
            self.engine.tail = offset
                .checked_add(len as u64)
                .filter(|x| *x <= i64::MAX as u64)
                .ok_or_else(|| invalid("store overflow"))?;
            if self.engine.mode == Mode::Batched && selected[n - 1] != start + n - 1 {
                w.iovecs.clear();
                let mut j = 0;
                while j < n {
                    let mut run = 1;
                    while j + run < n && selected[j + run] == selected[j] + run {
                        run += 1;
                    }
                    let bytes = w.map.read(selected[j] * PAGE, run * PAGE)?;
                    w.iovecs.push(IoVec {
                        base: bytes.as_ptr(),
                        len: bytes.len(),
                    });
                    j += run;
                }
                vectored_all(&self.engine.store.file, &mut w.iovecs, offset)?;
            } else {
                self.engine
                    .store
                    .file
                    .write_all_at(w.map.read(start * PAGE, len)?, offset)?;
            }
            self.stats.write_batches += 1;
            self.stats.payload_bytes += len;
            for &p in selected {
                if last_leaf != Some(p / LEAF) {
                    self.stats.changed_table_leaves += 1;
                    last_leaf = Some(p / LEAF);
                }
            }
            if self.engine.mode == Mode::Batched {
                table.set_batch(selected, offset);
            } else {
                for (j, &p) in selected.iter().enumerate() {
                    table.set(p, offset + (j * PAGE) as u64);
                }
            }
            i += n;
            #[cfg(feature = "fault-injection")]
            if matches!(failure, Some(Failure::AfterFirstWrite)) {
                return Err(Error::other("injected after write"));
            }
        }
        if !pages.is_empty() {
            self.stats.root_entries_copied = table.root.len();
        }
        if options.sync_payload {
            #[cfg(feature = "fault-injection")]
            if matches!(failure, Some(Failure::PayloadSync)) {
                return Err(Error::other("injected payload sync failure"));
            }
            self.engine.store.file.sync_data()?;
        }
        #[cfg(feature = "fault-injection")]
        if matches!(failure, Some(Failure::BeforePublish)) {
            return Err(Error::other("injected before publish"));
        }
        if self.engine.mode != Mode::Baseline {
            // Keep private writer pages: snapshots map newly appended immutable
            // file pages, never this mutable address space. No remap or new COW
            // fault is needed for a hot page in the following transaction.
            // Restore reusable vector capacity and clear touched bitmap words only.
            w.dirty.pages = pages;
            w.dirty.clear();
            self.engine.cached = Some(w);
        }
        self.engine.table = table;
        if self.stats.dirty_pages != 0 {
            self.engine.generation += 1;
        }
        Ok((self.engine.snapshot(), self.stats))
    }
}
impl Drop for Transaction<'_> {
    fn drop(&mut self) {
        // Abort: restore only modified pages to the old committed generation.
        // A failed restore drops the complete private mapping; committed bytes
        // and the manifest remain untouched.
        if let Some(mut w) = self.work.take() {
            if self.engine.mode == Mode::Baseline {
                return;
            }
            w.dirty.pages.sort_unstable();
            let mut i = 0;
            while i < w.dirty.pages.len() {
                let p = w.dirty.pages[i];
                let off = self.engine.table.get(p);
                let mut n = 1;
                while i + n < w.dirty.pages.len()
                    && w.dirty.pages[i + n] == p + n
                    && contiguous(off, self.engine.table.get(p + n), n)
                {
                    n += 1;
                }
                if w.map.bind(&self.engine.store, p, n, off, true).is_err() {
                    return;
                }
                i += n;
            }
            w.dirty.clear();
            self.engine.cached = Some(w);
        }
    }
}

/// Checked near-pointer helpers, limited to struct/list pointers. No far decoder.
pub fn near_pointer(slot: u64, target: u64, kind: u8, high: u32) -> io::Result<u64> {
    if kind > 1 {
        return Err(invalid("near pointer kind"));
    }
    let off = target as i128 - slot as i128 - 1;
    if !(-(1i128 << 29)..(1i128 << 29)).contains(&off) {
        return Err(invalid("near offset range"));
    }
    Ok(((high as u64) << 32) | (((off as u64) & ((1 << 30) - 1)) << 2) | kind as u64)
}
pub fn near_target(slot: u64, word: u64) -> io::Result<u64> {
    if word & 3 > 1 {
        return Err(invalid("not a near pointer"));
    }
    let raw = ((word >> 2) & ((1 << 30) - 1)) as i64;
    let off = if raw & (1 << 29) != 0 {
        raw - (1 << 30)
    } else {
        raw
    };
    let t = slot as i128 + 1 + off as i128;
    u64::try_from(t).map_err(|_| invalid("target overflow"))
}

#[cfg(test)]
mod vectored_tests {
    use super::*;
    #[test]
    fn short_writes_and_interruptions_preserve_all_bytes_and_offsets() {
        let a = b"abcdef";
        let b = b"GHIJK";
        let mut v = [
            IoVec {
                base: a.as_ptr(),
                len: a.len(),
            },
            IoVec {
                base: b.as_ptr(),
                len: b.len(),
            },
        ];
        let mut collected = Vec::new();
        let mut calls = 0;
        vectored_all_with(&mut v, 123, |vs, offset| {
            calls += 1;
            assert_eq!(offset, 123 + collected.len() as u64);
            if calls == 2 {
                return Err(Error::from(ErrorKind::Interrupted));
            }
            let take = 3.min(vs.iter().map(|x| x.len).sum());
            let mut left = take;
            for v in vs {
                let n = left.min(v.len);
                // SAFETY: vectors refer to a and b, shortened by the helper.
                collected.extend_from_slice(unsafe { std::slice::from_raw_parts(v.base, n) });
                left -= n;
                if left == 0 {
                    break;
                }
            }
            Ok(take)
        })
        .unwrap();
        assert_eq!(collected, b"abcdefGHIJK");
        assert_eq!(calls, 5);
    }
    #[test]
    fn zero_write_is_error() {
        let a = [1];
        let mut v = [IoVec {
            base: a.as_ptr(),
            len: 1,
        }];
        assert_eq!(
            vectored_all_with(&mut v, 0, |_, _| Ok(0))
                .unwrap_err()
                .kind(),
            ErrorKind::WriteZero
        );
    }
    #[test]
    fn error_after_short_write_propagates() {
        let a = [1, 2, 3];
        let mut v = [IoVec {
            base: a.as_ptr(),
            len: 3,
        }];
        let mut calls = 0;
        let e = vectored_all_with(&mut v, 0, |_, _| {
            calls += 1;
            if calls == 1 {
                Ok(1)
            } else {
                Err(Error::from(ErrorKind::Other))
            }
        })
        .unwrap_err();
        assert_eq!(calls, 2);
        assert_eq!(e.kind(), ErrorKind::Other);
    }
    #[test]
    fn empty_vector_skips_syscall() {
        let mut v = [];
        vectored_all_with(&mut v, 0, |_, _| panic!("unexpected call")).unwrap();
    }
}
