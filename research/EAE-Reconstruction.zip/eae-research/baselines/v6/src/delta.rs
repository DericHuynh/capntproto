//! Byte-range redo records plus an exclusively borrowed, in-place mmap writer.
//! No page payload copies on commit. Snapshot opening replays history into RAM.
//! This is not a crash-recoverable log: the publication index is in memory.
use super::*;

struct Record {
    offset: u64,
    len: usize,
    previous: Option<Arc<Record>>,
}
// Long histories must not recursively drop through the process stack.
impl Drop for Record {
    fn drop(&mut self) {
        let mut next = self.previous.take();
        while let Some(node) = next {
            match Arc::try_unwrap(node) {
                Ok(mut node) => next = node.previous.take(),
                Err(_) => break,
            }
        }
    }
}
#[derive(Clone)]
pub struct DeltaSnapshot {
    store: Arc<Store>,
    head: Option<Arc<Record>>,
    bytes: usize,
}
impl DeltaSnapshot {
    /// O(history bytes + record count); keep the resulting View for repeated reads.
    pub fn view(&self) -> io::Result<View> {
        let mut records = Vec::new();
        let mut cursor = self.head.as_deref();
        while let Some(record) = cursor {
            records.push(record);
            cursor = record.previous.as_deref();
        }
        let mut map = Mapping::new(self.bytes, true)?;
        let mut buffer = Vec::new();
        for record in records.into_iter().rev() {
            buffer.resize(record.len, 0);
            self.store.file.read_exact_at(&mut buffer, record.offset)?;
            if buffer.get(..8) != Some(b"EAEdelta") {
                return Err(Error::new(ErrorKind::InvalidData, "delta magic"));
            }
            let count = u64::from_le_bytes(buffer[8..16].try_into().unwrap());
            let mut p = 16;
            for _ in 0..count {
                if buffer.len() - p < 16 {
                    return Err(Error::new(ErrorKind::InvalidData, "delta descriptor"));
                }
                let pos = u64::from_le_bytes(buffer[p..p + 8].try_into().unwrap()) as usize;
                let n = u64::from_le_bytes(buffer[p + 8..p + 16].try_into().unwrap()) as usize;
                p += 16;
                if n > buffer.len() - p {
                    return Err(Error::new(ErrorKind::InvalidData, "delta length"));
                }
                map.write(pos, &buffer[p..p + n])?;
                p += n;
            }
            if p != buffer.len() {
                return Err(Error::new(ErrorKind::InvalidData, "delta trailing bytes"));
            }
        }
        Ok(View {
            map,
            _store: self.store.clone(),
        })
    }
}
#[derive(Debug, Default, Clone, Copy)]
pub struct DeltaStats {
    /// Bytes in the union of submitted, non-no-op write ranges.
    pub payload_bytes: usize,
    /// Includes the 16-byte transaction header and 16 bytes per merged range.
    pub log_bytes: usize,
    pub ranges: usize,
}
pub struct DeltaEngine {
    store: Arc<Store>,
    map: Mapping,
    head: Option<Arc<Record>>,
    tail: u64,
    buffer: Vec<u8>,
    #[cfg(feature = "fault-injection")]
    fail: bool,
}
impl DeltaEngine {
    pub fn new(bytes: usize) -> io::Result<Self> {
        if bytes == 0 || bytes > MAX_BYTES || !bytes.is_multiple_of(PAGE) {
            return Err(invalid("segment size"));
        }
        if unsafe { sysconf(30) } != PAGE as i64 {
            return Err(invalid("requires 4 KiB system pages"));
        }
        Ok(Self {
            store: Arc::new(Store::new()?),
            map: Mapping::new(bytes, true)?,
            head: None,
            tail: 0,
            buffer: Vec::new(),
            #[cfg(feature = "fault-injection")]
            fail: false,
        })
    }
    /// Borrowed latest-version reads do not reconstruct a snapshot.
    ///
    /// ```compile_fail
    /// use eae_pages::{delta::DeltaEngine, PAGE};
    /// let mut e = DeltaEngine::new(PAGE).unwrap();
    /// let bytes = e.read(0, 8).unwrap();
    /// let _tx = e.begin();
    /// println!("{:?}", bytes);
    /// ```
    pub fn read(&self, pos: usize, n: usize) -> io::Result<&[u8]> {
        self.map.read(pos, n)
    }
    pub fn snapshot(&self) -> DeltaSnapshot {
        DeltaSnapshot {
            store: self.store.clone(),
            head: self.head.clone(),
            bytes: self.map.bytes,
        }
    }
    pub fn begin(&mut self) -> DeltaTransaction<'_> {
        DeltaTransaction {
            engine: self,
            undo: Vec::new(),
            committed: false,
        }
    }
    /// Inject a partial record write followed by failure before publication.
    #[cfg(feature = "fault-injection")]
    pub fn fail_next_commit(&mut self) {
        self.fail = true;
    }
}
struct Undo {
    pos: usize,
    bytes: Vec<u8>,
}
pub struct DeltaTransaction<'a> {
    engine: &'a mut DeltaEngine,
    undo: Vec<Undo>,
    committed: bool,
}
impl DeltaTransaction<'_> {
    pub fn write(&mut self, pos: usize, data: &[u8]) -> io::Result<()> {
        let old = self.engine.map.read(pos, data.len())?;
        if data.is_empty() || (data.len() <= 64 && old == data) {
            return Ok(());
        }
        self.undo.push(Undo {
            pos,
            bytes: old.to_vec(),
        });
        self.engine.map.write(pos, data)
    }
    pub fn put_word(&mut self, word: usize, value: u64) -> io::Result<()> {
        let pos = word
            .checked_mul(8)
            .ok_or_else(|| invalid("word overflow"))?;
        self.write(pos, &value.to_le_bytes())
    }
    pub fn commit(mut self, options: CommitOptions) -> io::Result<(DeltaSnapshot, DeltaStats)> {
        let mut ranges: Vec<(usize, usize)> = self
            .undo
            .iter()
            .map(|u| (u.pos, u.pos + u.bytes.len()))
            .collect();
        ranges.sort_unstable();
        let mut count = 0;
        for i in 0..ranges.len() {
            let (start, end) = ranges[i];
            if count > 0 && start <= ranges[count - 1].1 {
                ranges[count - 1].1 = ranges[count - 1].1.max(end);
            } else {
                ranges[count] = (start, end);
                count += 1;
            }
        }
        ranges.truncate(count);
        let mut stats = DeltaStats::default();
        if count != 0 {
            let e = &mut self.engine;
            e.buffer.clear();
            e.buffer.extend_from_slice(b"EAEdelta");
            e.buffer.extend_from_slice(&(count as u64).to_le_bytes());
            for (start, end) in ranges {
                e.buffer.extend_from_slice(&(start as u64).to_le_bytes());
                e.buffer
                    .extend_from_slice(&((end - start) as u64).to_le_bytes());
                e.buffer.extend_from_slice(e.map.read(start, end - start)?);
                stats.payload_bytes += end - start;
            }
            stats.log_bytes = e.buffer.len();
            stats.ranges = count;
            let offset = e.tail;
            e.tail = e
                .tail
                .checked_add(stats.log_bytes as u64)
                .filter(|n| *n <= i64::MAX as u64)
                .ok_or_else(|| invalid("log offset overflow"))?;
            #[cfg(feature = "fault-injection")]
            if std::mem::take(&mut e.fail) {
                e.store
                    .file
                    .write_all_at(&e.buffer[..e.buffer.len() / 2], offset)?;
                return Err(Error::other("injected partial delta write"));
            }
            e.store.file.write_all_at(&e.buffer, offset)?;
            if options.sync_payload {
                e.store.file.sync_data()?;
            }
            e.head = Some(Arc::new(Record {
                offset,
                len: stats.log_bytes,
                previous: e.head.clone(),
            }));
        } else if options.sync_payload {
            self.engine.store.file.sync_data()?;
        }
        self.committed = true;
        Ok((self.engine.snapshot(), stats))
    }
}
impl Drop for DeltaTransaction<'_> {
    fn drop(&mut self) {
        if !self.committed {
            for undo in self.undo.iter().rev() {
                // All ranges were checked before mutation; restoring cannot fail.
                self.engine
                    .map
                    .write(undo.pos, &undo.bytes)
                    .expect("validated undo range");
            }
        }
    }
}
