//! Optional persistent arena adapter; no schema, index, query or consensus policy.
//! Local Linux filesystem, exclusive cooperating writer, checksummed byte redo.
use super::*;
use std::fmt;
use std::path::{Path, PathBuf};

const HEADER: usize = 4096;
const FRAME: usize = 48;
const TRAILER: usize = 16;
const MAX_SEGMENTS: usize = 64;
const FILE_MAGIC: &[u8; 8] = b"EAEARE06";
const TX_MAGIC: &[u8; 8] = b"EAETX006";
const END_MAGIC: &[u8; 8] = b"EAECMIT6";
unsafe extern "C" {
    fn flock(fd: i32, operation: i32) -> i32;
}

const fn crc_table() -> [u32; 256] {
    let mut table = [0; 256];
    let mut i = 0;
    while i < 256 {
        let mut c = i as u32;
        let mut bit = 0;
        while bit < 8 {
            c = (c >> 1) ^ if c & 1 != 0 { 0x82f63b78 } else { 0 };
            bit += 1;
        }
        table[i] = c;
        i += 1;
    }
    table
}
const CRC_TABLE: [u32; 256] = crc_table();
fn checksum_software(bytes: &[u8]) -> u64 {
    let mut c = !0u32;
    for &b in bytes {
        c = CRC_TABLE[((c as u8) ^ b) as usize] ^ (c >> 8);
    }
    (!c) as u64
}
// Hardware CRC32C uses the same Castagnoli polynomial as the portable path.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "sse4.2")]
unsafe fn checksum_hardware(bytes: &[u8]) -> u64 {
    use std::arch::x86_64::{_mm_crc32_u64, _mm_crc32_u8};
    let mut c = !0u32 as u64;
    let mut chunks = bytes.chunks_exact(8);
    for chunk in &mut chunks {
        c = _mm_crc32_u64(c, u64::from_le_bytes(chunk.try_into().unwrap()));
    }
    for &b in chunks.remainder() {
        c = _mm_crc32_u8(c as u32, b) as u64;
    }
    (!(c as u32)) as u64
}
fn checksum(bytes: &[u8]) -> u64 {
    #[cfg(target_arch = "x86_64")]
    if std::is_x86_feature_detected!("sse4.2") {
        // SAFETY: the CPU feature is checked before calling the specialized code.
        return unsafe { checksum_hardware(bytes) };
    }
    checksum_software(bytes)
}
fn get(b: &[u8], at: usize) -> u64 {
    u64::from_le_bytes(b[at..at + 8].try_into().unwrap())
}
fn put(b: &mut [u8], at: usize, v: u64) {
    b[at..at + 8].copy_from_slice(&v.to_le_bytes());
}
fn corrupt(s: &str) -> Error {
    Error::new(ErrorKind::InvalidData, s)
}

#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub max_arena_bytes: usize,
    pub max_record_bytes: usize,
    pub max_undo_bytes: usize,
    /// Commits exceeding this budget are rejected before file I/O. Checkpoint explicitly.
    pub max_log_bytes: u64,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            max_arena_bytes: MAX_BYTES,
            max_record_bytes: 32 * 1024 * 1024,
            max_undo_bytes: 64 * 1024 * 1024,
            max_log_bytes: 64 * 1024 * 1024,
        }
    }
}
impl Limits {
    fn check(self) -> io::Result<()> {
        if self.max_arena_bytes == 0
            || self.max_arena_bytes > MAX_BYTES
            || self.max_record_bytes < FRAME + TRAILER + 17
            || self.max_record_bytes > 2 * MAX_BYTES
            || self.max_undo_bytes > 2 * MAX_BYTES
            || self.max_log_bytes > i64::MAX as u64 - (HEADER + MAX_BYTES) as u64
        {
            return Err(invalid("invalid arena resource limits"));
        }
        Ok(())
    }
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Durability {
    #[default]
    Durable,
    /// Process-visible commit only; may disappear after power loss until flush/checkpoint.
    Buffered,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Outcome {
    Rejected,
    Unknown,
}
#[derive(Debug)]
pub struct CommitError {
    pub outcome: Outcome,
    pub source: io::Error,
}
impl fmt::Display for CommitError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?} commit: {}", self.outcome, self.source)
    }
}
impl std::error::Error for CommitError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(&self.source)
    }
}
fn rejected(source: io::Error) -> CommitError {
    CommitError {
        outcome: Outcome::Rejected,
        source,
    }
}
#[derive(Clone, Copy, Debug)]
pub struct Receipt {
    pub generation: u64,
    pub durable_through: u64,
    pub payload_bytes: usize,
    pub file_bytes: usize,
    pub ranges: usize,
}
#[derive(Clone, Copy, Debug, Default)]
pub struct Recovery {
    pub replayed_transactions: u64,
    pub discarded_tail_bytes: u64,
}
#[derive(Clone, Copy, Debug)]
pub struct Checkpoint {
    pub file_bytes: u64,
    pub reclaimed_log_bytes: u64,
    pub generation: u64,
}

#[derive(Clone)]
struct Layout {
    lengths: Vec<usize>,
    starts: Vec<usize>,
    total: usize,
}
impl Layout {
    fn new(lengths: &[usize], limits: Limits) -> io::Result<Self> {
        limits.check()?;
        if lengths.is_empty() || lengths.len() > MAX_SEGMENTS {
            return Err(invalid("segment count"));
        }
        let mut starts = Vec::new();
        let mut total = 0usize;
        for &n in lengths {
            if n == 0 || !n.is_multiple_of(8) {
                return Err(invalid("segments require nonzero word-aligned lengths"));
            }
            starts.push(total);
            total = total
                .checked_add(n)
                .filter(|&n| n <= limits.max_arena_bytes)
                .ok_or_else(|| invalid("arena size limit"))?;
        }
        Ok(Self {
            lengths: lengths.to_vec(),
            starts,
            total,
        })
    }
    fn pos(&self, segment: usize, offset: usize, n: usize) -> io::Result<usize> {
        let len = *self
            .lengths
            .get(segment)
            .ok_or_else(|| invalid("segment id"))?;
        bounds(len, offset, n)?;
        Ok(self.starts[segment] + offset)
    }
    fn slices<'a>(&self, map: &'a Mapping) -> Vec<&'a [u8]> {
        self.starts
            .iter()
            .zip(&self.lengths)
            .map(|(&p, &n)| map.read(p, n).expect("validated layout"))
            .collect()
    }
}
struct Frozen {
    map: Mapping,
    layout: Layout,
}
// SAFETY: mapping is owned and immutable after construction, with no mutable API.
unsafe impl Send for Frozen {}
unsafe impl Sync for Frozen {}
#[derive(Clone)]
pub struct ArenaSnapshot {
    inner: Arc<Frozen>,
    pub generation: u64,
    pub durable_through: u64,
    pub schema_id: u64,
}
impl ArenaSnapshot {
    pub fn segments(&self) -> Vec<&[u8]> {
        self.inner.layout.slices(&self.inner.map)
    }
}

/// Faults return I/O errors or terminate a child process without destructors.
#[cfg(feature = "fault-injection")]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FaultPoint {
    PartialAppend,
    AfterAppend,
    AfterSync,
    BeforeRename,
    AfterRename,
    AfterDirectorySync,
}
#[cfg(feature = "fault-injection")]
#[derive(Clone, Copy)]
struct Fault {
    point: FaultPoint,
    crash: bool,
}

pub struct Arena {
    dir: PathBuf,
    directory: File,
    _lock: WriterLock,
    file: File,
    map: Mapping,
    layout: Layout,
    schema_id: u64,
    generation: u64,
    durable_through: u64,
    log_start: u64,
    tail: u64,
    limits: Limits,
    recovery: Recovery,
    poisoned: bool,
    active: bool,
    buffer: Vec<u8>,
    #[cfg(feature = "fault-injection")]
    fault: Option<Fault>,
}
struct WriterLock(File);
impl Drop for WriterLock {
    fn drop(&mut self) {
        // Explicit unlock also releases a transient fork-inherited descriptor.
        // The arena must never be used in both branches of a manual fork.
        unsafe {
            flock(self.0.as_raw_fd(), 8);
        }
    }
}
fn locked_directory(path: &Path) -> io::Result<(PathBuf, File, WriterLock)> {
    let dir = path.canonicalize()?;
    let directory = File::open(&dir)?;
    let lock = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(dir.join("LOCK"))?;
    // SAFETY: owned live descriptor; LOCK_EX | LOCK_NB, released on close.
    if unsafe { flock(lock.as_raw_fd(), 2 | 4) } != 0 {
        return Err(Error::last_os_error());
    }
    Ok((dir, directory, WriterLock(lock)))
}
fn image_header(layout: &Layout, schema: u64, generation: u64, bytes: &[u8]) -> [u8; HEADER] {
    let mut h = [0; HEADER];
    h[..8].copy_from_slice(FILE_MAGIC);
    put(&mut h, 8, 1);
    put(&mut h, 16, schema);
    put(&mut h, 24, generation);
    put(&mut h, 32, layout.lengths.len() as u64);
    put(&mut h, 40, layout.total as u64);
    put(&mut h, 48, checksum(bytes));
    for (i, &n) in layout.lengths.iter().enumerate() {
        put(&mut h, 64 + 8 * i, n as u64);
    }
    let c = checksum(&h[..HEADER - 8]);
    put(&mut h, HEADER - 8, c);
    h
}
fn write_image(
    file: &File,
    layout: &Layout,
    schema: u64,
    generation: u64,
    map: &Mapping,
) -> io::Result<()> {
    let bytes = map.read(0, layout.total)?;
    file.write_all_at(&image_header(layout, schema, generation, bytes), 0)?;
    file.write_all_at(bytes, HEADER as u64)?;
    file.sync_all()
}
impl Arena {
    /// Creates a new dedicated directory. Existing paths are never overwritten.
    pub fn create(
        path: impl AsRef<Path>,
        lengths: &[usize],
        schema_id: u64,
        limits: Limits,
    ) -> io::Result<Self> {
        let layout = Layout::new(lengths, limits)?;
        if unsafe { sysconf(30) } != PAGE as i64 {
            return Err(invalid("requires 4 KiB host pages"));
        }
        let path = path.as_ref();
        std::fs::create_dir(path)?;
        let (dir, directory, lock) = locked_directory(path)?;
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create_new(true)
            .open(dir.join("PENDING"))?;
        let map = Mapping::new(layout.total.next_multiple_of(PAGE), true)?;
        write_image(&file, &layout, schema_id, 0, &map)?;
        std::fs::rename(dir.join("PENDING"), dir.join("DATA"))?;
        directory.sync_all()?;
        File::open(dir.parent().ok_or_else(|| invalid("arena parent"))?)?.sync_all()?;
        let tail = (HEADER + layout.total) as u64;
        Ok(Self {
            dir,
            directory,
            _lock: lock,
            file,
            map,
            layout,
            schema_id,
            generation: 0,
            durable_through: 0,
            log_start: tail,
            tail,
            limits,
            recovery: Recovery::default(),
            poisoned: false,
            active: false,
            buffer: Vec::new(),
            #[cfg(feature = "fault-injection")]
            fault: None,
        })
    }
    /// Fails closed on checksum/format corruption; only incomplete EOF records are discarded.
    pub fn open(path: impl AsRef<Path>, schema_id: u64, limits: Limits) -> io::Result<Self> {
        limits.check()?;
        if unsafe { sysconf(30) } != PAGE as i64 {
            return Err(invalid("requires 4 KiB host pages"));
        }
        let (dir, directory, lock) = locked_directory(path.as_ref())?;
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(dir.join("DATA"))?;
        let mut h = [0; HEADER];
        file.read_exact_at(&mut h, 0)?;
        if &h[..8] != FILE_MAGIC
            || get(&h, 8) != 1
            || get(&h, HEADER - 8) != checksum(&h[..HEADER - 8])
        {
            return Err(corrupt("arena header checksum or format"));
        }
        if get(&h, 16) != schema_id {
            return Err(invalid("schema identifier mismatch"));
        }
        let count = get(&h, 32) as usize;
        if count == 0 || count > MAX_SEGMENTS || get(&h, 56) != 0 {
            return Err(corrupt("arena header fields"));
        }
        let lengths: Vec<_> = (0..count).map(|i| get(&h, 64 + 8 * i) as usize).collect();
        let layout = Layout::new(&lengths, limits)?;
        if get(&h, 40) != layout.total as u64 {
            return Err(corrupt("arena layout length"));
        }
        let mut map = Mapping::new(layout.total.next_multiple_of(PAGE), true)?;
        let mut image = vec![0; layout.total];
        file.read_exact_at(&mut image, HEADER as u64)?;
        if checksum(&image) != get(&h, 48) {
            return Err(corrupt("checkpoint checksum"));
        }
        map.write(0, &image)?;
        drop(image);
        let log_start = (HEADER + layout.total) as u64;
        let size = file.metadata()?.len();
        if size < log_start || size - log_start > limits.max_log_bytes {
            return Err(corrupt("log size limit"));
        }
        let mut arena = Self {
            dir,
            directory,
            _lock: lock,
            file,
            map,
            layout,
            schema_id,
            generation: get(&h, 24),
            durable_through: get(&h, 24),
            log_start,
            tail: log_start,
            limits,
            recovery: Recovery::default(),
            poisoned: false,
            active: false,
            buffer: Vec::new(),
            #[cfg(feature = "fault-injection")]
            fault: None,
        };
        while arena.tail < size {
            if size - arena.tail < FRAME as u64 {
                break;
            }
            let mut head = [0; FRAME];
            arena.file.read_exact_at(&mut head, arena.tail)?;
            if &head[..8] != TX_MAGIC || get(&head, 40) != checksum(&head[..40]) {
                return Err(corrupt("transaction header checksum"));
            }
            let len = get(&head, 8) as usize;
            if len < FRAME + TRAILER || len > limits.max_record_bytes {
                return Err(corrupt("transaction length limit"));
            }
            if len as u64 > size - arena.tail {
                break;
            }
            arena.buffer.resize(len, 0);
            arena.file.read_exact_at(&mut arena.buffer, arena.tail)?;
            let expected = arena
                .generation
                .checked_add(1)
                .ok_or_else(|| corrupt("generation overflow"))?;
            let ranges = validate_record(&arena.buffer, expected, arena.layout.total)?;
            for (pos, start, n) in ranges {
                arena.map.write(pos, &arena.buffer[start..start + n])?;
            }
            arena.generation = expected;
            arena.tail += len as u64;
            arena.recovery.replayed_transactions += 1;
        }
        arena.recovery.discarded_tail_bytes = size - arena.tail;
        if arena.tail != size {
            arena.file.set_len(arena.tail)?;
        }
        // Stabilize recovered complete records, including surviving buffered commits.
        arena.file.sync_all()?;
        arena.directory.sync_all()?;
        arena.durable_through = arena.generation;
        match std::fs::remove_file(arena.dir.join("PENDING")) {
            Ok(()) => arena.directory.sync_all()?,
            Err(e) if e.kind() == ErrorKind::NotFound => (),
            Err(e) => return Err(e),
        }
        Ok(arena)
    }
    fn healthy(&self) -> io::Result<()> {
        if self.poisoned || self.active {
            Err(Error::other(
                "arena requires reopen after uncertain I/O or leaked transaction",
            ))
        } else {
            Ok(())
        }
    }
    pub fn generation(&self) -> u64 {
        self.generation
    }
    pub fn durable_through(&self) -> u64 {
        self.durable_through
    }
    pub fn recovery(&self) -> Recovery {
        self.recovery
    }
    pub fn log_bytes(&self) -> u64 {
        self.tail - self.log_start
    }
    pub fn schema_id(&self) -> u64 {
        self.schema_id
    }
    /// Borrowed segment slices are directly usable with Cap'n Proto SegmentArray.
    ///
    /// ```compile_fail
    /// use eae_pages::durable::Arena;
    /// fn alias(arena: &mut Arena) {
    ///     let segments = arena.segments().unwrap();
    ///     let transaction = arena.begin().unwrap();
    ///     println!("{:?}", segments);
    ///     drop(transaction);
    /// }
    /// ```
    pub fn segments(&self) -> io::Result<Vec<&[u8]>> {
        self.healthy()?;
        Ok(self.layout.slices(&self.map))
    }
    /// Eager detached immutable copy; O(arena bytes), O(1) clone thereafter.
    pub fn snapshot(&self) -> io::Result<ArenaSnapshot> {
        self.healthy()?;
        let mut map = Mapping::new(self.map.bytes, true)?;
        map.write(0, self.map.read(0, self.layout.total)?)?;
        Ok(ArenaSnapshot {
            inner: Arc::new(Frozen {
                map,
                layout: self.layout.clone(),
            }),
            generation: self.generation,
            durable_through: self.durable_through,
            schema_id: self.schema_id,
        })
    }
    pub fn begin(&mut self) -> io::Result<ArenaTransaction<'_>> {
        self.healthy()?;
        self.active = true;
        Ok(ArenaTransaction {
            arena: self,
            undo: Vec::new(),
            undo_bytes: 0,
            committed: false,
        })
    }
    /// Optional stale-generation guard for higher-layer read-modify-write operations.
    pub fn begin_at(&mut self, generation: u64) -> io::Result<ArenaTransaction<'_>> {
        if generation != self.generation {
            return Err(invalid("stale generation"));
        }
        self.begin()
    }
    /// Flush all published buffered commits. Failure requires reopening the arena.
    pub fn flush(&mut self) -> io::Result<u64> {
        self.healthy()?;
        if let Err(e) = self.file.sync_all() {
            self.poisoned = true;
            return Err(e);
        }
        self.durable_through = self.generation;
        Ok(self.generation)
    }
    /// Atomically replaces DATA with a synced checkpoint, then syncs the directory.
    /// Reclaims redo history; detached snapshots remain valid. Failure poisons the handle.
    pub fn checkpoint(&mut self) -> io::Result<Checkpoint> {
        self.healthy()?;
        let result = self.checkpoint_inner();
        if result.is_err() {
            self.poisoned = true;
        }
        result
    }
    fn checkpoint_inner(&mut self) -> io::Result<Checkpoint> {
        let new = OpenOptions::new()
            .read(true)
            .write(true)
            .create_new(true)
            .open(self.dir.join("PENDING"))?;
        write_image(
            &new,
            &self.layout,
            self.schema_id,
            self.generation,
            &self.map,
        )?;
        #[cfg(feature = "fault-injection")]
        self.trip(FaultPoint::BeforeRename)?;
        std::fs::rename(self.dir.join("PENDING"), self.dir.join("DATA"))?;
        #[cfg(feature = "fault-injection")]
        self.trip(FaultPoint::AfterRename)?;
        self.directory.sync_all()?;
        #[cfg(feature = "fault-injection")]
        self.trip(FaultPoint::AfterDirectorySync)?;
        let reclaimed_log_bytes = self.log_bytes();
        self.file = new;
        self.tail = self.log_start;
        self.durable_through = self.generation;
        Ok(Checkpoint {
            file_bytes: self.log_start,
            reclaimed_log_bytes,
            generation: self.generation,
        })
    }
    #[cfg(feature = "fault-injection")]
    pub fn inject_fault(&mut self, point: FaultPoint, crash: bool) {
        self.fault = Some(Fault { point, crash });
    }
    #[cfg(feature = "fault-injection")]
    fn trip(&mut self, point: FaultPoint) -> io::Result<()> {
        if self.fault.is_some_and(|f| f.point == point) {
            let fault = self.fault.take().unwrap();
            if fault.crash {
                std::process::exit(86);
            }
            return Err(Error::other(format!("injected {point:?}")));
        }
        Ok(())
    }
}
fn validate_record(
    b: &[u8],
    generation: u64,
    total: usize,
) -> io::Result<Vec<(usize, usize, usize)>> {
    if &b[..8] != TX_MAGIC
        || get(b, 8) != b.len() as u64
        || get(b, 16) != generation
        || get(b, 40) != checksum(&b[..40])
        || &b[b.len() - TRAILER..b.len() - 8] != END_MAGIC
        || get(b, b.len() - 8) != generation
        || get(b, 32) != checksum(&b[FRAME..b.len() - TRAILER])
    {
        return Err(corrupt("transaction checksum, sequence or commit marker"));
    }
    let count = get(b, 24) as usize;
    let end = b.len() - TRAILER;
    if count == 0 || count > (end - FRAME) / 17 {
        return Err(corrupt("range count"));
    }
    let mut ranges = Vec::with_capacity(count);
    let mut p = FRAME;
    let mut last = 0;
    for _ in 0..count {
        if end - p < 16 {
            return Err(corrupt("range descriptor"));
        }
        let pos = get(b, p) as usize;
        let n = get(b, p + 8) as usize;
        p += 16;
        if n == 0 || pos < last || pos > total || n > total - pos || n > end - p {
            return Err(corrupt("range bounds or ordering"));
        }
        ranges.push((pos, p, n));
        p += n;
        last = pos + n;
    }
    if p != end {
        return Err(corrupt("trailing range bytes"));
    }
    Ok(ranges)
}
struct UndoRange {
    pos: usize,
    bytes: Vec<u8>,
}
pub struct ArenaTransaction<'a> {
    arena: &'a mut Arena,
    undo: Vec<UndoRange>,
    undo_bytes: usize,
    committed: bool,
}
impl ArenaTransaction<'_> {
    pub fn segments(&self) -> Vec<&[u8]> {
        self.arena.layout.slices(&self.arena.map)
    }
    pub fn write(&mut self, segment: usize, offset: usize, data: &[u8]) -> io::Result<()> {
        let pos = self.arena.layout.pos(segment, offset, data.len())?;
        let old = self.arena.map.read(pos, data.len())?;
        if data.is_empty() || (data.len() <= 64 && old == data) {
            return Ok(());
        }
        let next = self
            .undo_bytes
            .checked_add(data.len())
            .filter(|&n| n <= self.arena.limits.max_undo_bytes)
            .ok_or_else(|| invalid("transaction undo budget exceeded"))?;
        self.undo.push(UndoRange {
            pos,
            bytes: old.to_vec(),
        });
        self.undo_bytes = next;
        self.arena.map.write(pos, data)
    }
    pub fn put_word(&mut self, segment: usize, word: usize, value: u64) -> io::Result<()> {
        self.write(
            segment,
            word.checked_mul(8)
                .ok_or_else(|| invalid("word offset overflow"))?,
            &value.to_le_bytes(),
        )
    }
    pub fn commit(self, durability: Durability) -> Result<Receipt, CommitError> {
        self.commit_checked(durability, |_| Ok(()))
    }
    /// Validation runs before any log I/O; rejection restores all submitted ranges.
    pub fn commit_checked(
        mut self,
        durability: Durability,
        validate: impl FnOnce(&[&[u8]]) -> io::Result<()>,
    ) -> Result<Receipt, CommitError> {
        validate(&self.segments()).map_err(rejected)?;
        let mut ranges: Vec<(usize, usize)> = self
            .undo
            .iter()
            .map(|u| (u.pos, u.pos + u.bytes.len()))
            .collect();
        ranges.sort_unstable();
        let mut count = 0;
        for i in 0..ranges.len() {
            let (start, end) = ranges[i];
            if count > 0 && start <= ranges[count - 1].1 {
                ranges[count - 1].1 = ranges[count - 1].1.max(end);
            } else {
                ranges[count] = (start, end);
                count += 1;
            }
        }
        ranges.truncate(count);
        let payload: usize = ranges.iter().map(|&(p, e)| e - p).sum();
        let size = if count == 0 {
            0
        } else {
            FRAME + TRAILER + 16 * count + payload
        };
        let e = &mut self.arena;
        if size > e.limits.max_record_bytes
            || size as u64 > e.limits.max_log_bytes.saturating_sub(e.log_bytes())
        {
            return Err(rejected(invalid(
                "record/log budget exceeded; checkpoint or split the transaction",
            )));
        }
        let generation = if count == 0 {
            e.generation
        } else {
            e.generation
                .checked_add(1)
                .ok_or_else(|| rejected(invalid("generation exhausted")))?
        };
        if size != 0 {
            e.buffer.clear();
            e.buffer.resize(FRAME, 0);
            e.buffer[..8].copy_from_slice(TX_MAGIC);
            put(&mut e.buffer, 8, size as u64);
            put(&mut e.buffer, 16, generation);
            put(&mut e.buffer, 24, count as u64);
            for (start, end) in ranges {
                e.buffer.extend_from_slice(&(start as u64).to_le_bytes());
                e.buffer
                    .extend_from_slice(&((end - start) as u64).to_le_bytes());
                e.buffer
                    .extend_from_slice(e.map.read(start, end - start).map_err(rejected)?);
            }
            let c = checksum(&e.buffer[FRAME..]);
            put(&mut e.buffer, 32, c);
            let c = checksum(&e.buffer[..40]);
            put(&mut e.buffer, 40, c);
            e.buffer.extend_from_slice(END_MAGIC);
            e.buffer.extend_from_slice(&generation.to_le_bytes());
        }
        // From the first I/O onward an error cannot promise that the commit was absent.
        let result = (|| -> io::Result<()> {
            if size != 0 {
                #[cfg(feature = "fault-injection")]
                if e.fault
                    .is_some_and(|f| f.point == FaultPoint::PartialAppend)
                {
                    e.file
                        .write_all_at(&e.buffer[..e.buffer.len() / 2], e.tail)?;
                    e.trip(FaultPoint::PartialAppend)?;
                }
                e.file.write_all_at(&e.buffer, e.tail)?;
                #[cfg(feature = "fault-injection")]
                e.trip(FaultPoint::AfterAppend)?;
            }
            if durability == Durability::Durable {
                e.file.sync_all()?;
                #[cfg(feature = "fault-injection")]
                e.trip(FaultPoint::AfterSync)?;
            }
            Ok(())
        })();
        if let Err(source) = result {
            e.poisoned = true;
            return Err(CommitError {
                outcome: Outcome::Unknown,
                source,
            });
        }
        e.tail += size as u64;
        e.generation = generation;
        if durability == Durability::Durable {
            e.durable_through = generation;
        }
        e.active = false;
        self.committed = true;
        Ok(Receipt {
            generation,
            durable_through: e.durable_through,
            payload_bytes: payload,
            file_bytes: size,
            ranges: count,
        })
    }
}
impl Drop for ArenaTransaction<'_> {
    fn drop(&mut self) {
        if !self.committed {
            for u in self.undo.iter().rev() {
                self.arena
                    .map
                    .write(u.pos, &u.bytes)
                    .expect("validated undo");
            }
            self.arena.active = false;
        }
    }
}
#[cfg(test)]
mod checksum_tests {
    use super::*;
    fn record(pos: u64, n: u64, generation: u64) -> Vec<u8> {
        let mut b = vec![0; FRAME + 16 + 8 + TRAILER];
        b[..8].copy_from_slice(TX_MAGIC);
        let len = b.len();
        put(&mut b, 8, len as u64);
        put(&mut b, 16, generation);
        put(&mut b, 24, 1);
        put(&mut b, FRAME, pos);
        put(&mut b, FRAME + 8, n);
        let c = checksum(&b[FRAME..len - TRAILER]);
        put(&mut b, 32, c);
        let c = checksum(&b[..40]);
        put(&mut b, 40, c);
        b[len - TRAILER..len - 8].copy_from_slice(END_MAGIC);
        put(&mut b, len - 8, generation);
        b
    }
    #[test]
    fn valid_checksums_do_not_bypass_range_and_sequence_validation() {
        assert!(validate_record(&record(0, 8, 1), 1, PAGE).is_ok());
        for (pos, n, generation) in [
            (u64::MAX, 8, 1),
            (PAGE as u64, 8, 1),
            (0, u64::MAX, 1),
            (0, 0, 1),
            (0, 9, 1),
            (0, 8, 2),
        ] {
            assert!(validate_record(&record(pos, n, generation), 1, PAGE).is_err());
        }
    }
    #[test]
    fn oversized_count_with_valid_checksum_is_rejected() {
        let mut b = record(0, 8, 1);
        put(&mut b, 24, u64::MAX);
        let c = checksum(&b[..40]);
        put(&mut b, 40, c);
        assert!(validate_record(&b, 1, PAGE).is_err());
    }
    #[test]
    fn hardware_and_portable_checksums_agree_on_unaligned_ranges() {
        let data: Vec<_> = (0..8192).map(|i| ((i * 73 + i / 11) % 256) as u8).collect();
        for offset in 0..8 {
            for n in [0, 1, 7, 8, 9, 31, 32, 1023, 4096] {
                let bytes = &data[offset..offset + n];
                assert_eq!(checksum(bytes), checksum_software(bytes));
            }
        }
    }
    #[test]
    fn crc32c_known_vector() {
        assert_eq!(checksum(b"123456789"), 0xe3069283);
    }
}
