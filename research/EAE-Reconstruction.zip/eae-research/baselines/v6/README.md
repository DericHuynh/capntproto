# Frozen v6 library

This directory preserves the exact pre-optimization library sources and lockfile for reproducible comparison. The arena_perf and arena_compat binary targets use the same benchmark/fixture source files as the current crate. Build both libraries with the same Rust toolchain and release profile, then run rust/run_arena_perf.py and rust/check_arena_compat.py.

This is an evidence baseline, not the recommended implementation. Its snapshot and transaction allocation behavior intentionally remains unchanged.
