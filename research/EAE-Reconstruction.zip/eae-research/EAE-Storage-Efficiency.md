# EAE v7 storage-efficiency benchmark

20 September 2026. Benchmark implementation: `rust/src/bin/storage_efficiency.rs`. The storage engine itself is unchanged.

**Created and ran 270 validated workloads:** 90 configurations repeated three times, each performing 1000 update transactions. The benchmark separates bytes written from space retained, and logical file size from filesystem-allocated blocks.

The main finding: byte-range logging is compact for adjacent/bulk updates, but full-capacity checkpoint images make lightly occupied arenas space-inefficient. Frequent checkpoints can dominate cumulative writes even when individual changes are tiny.

## Workloads and setup

| Dimension | Values |
|---|---|
| Reserved arena capacity | 256 KiB; 8 MiB |
| Live-byte occupancy | 1/64 = 1.5625%; 25%; 100% |
| Updates | Repeated 8-byte field; 32 adjacent fields; 32 spread-out fields; repeated 4 KiB range; identical 8-byte no-op |
| Checkpoint schedule during the interval | None; every 100 transactions; every 1000 transactions |
| Runs per configuration | 3 |
| Transactions per run | 1000 |

The benchmark populates a prefix of the segment with deterministic pseudorandom bytes and declares that prefix to be live application data. It checkpoints setup before measuring updates. All later writes stay within that prefix; live data size is therefore constant while update history grows. Spread-out fields are evenly spaced within the live prefix; at the smallest occupancy they are not necessarily on different pages. All update locations are reused across transactions.

These are raw segment-byte workloads, not schema-specific object layouts. “Live bytes” is an explicit benchmark occupancy, not a count of nonzero bytes and not a claim about Cap’n Proto serialization overhead. No object allocator, index, compression, deletion, graph compaction or growth policy is simulated.

Commits use Buffered mode; state is flushed before filesystem sampling/checkpointing and at the end. This is a storage-size benchmark, not a transaction-latency or durability-throughput benchmark. The test environment is Linux overlayfs. `--base-dir` allows repetition on another mounted filesystem.

## Measurements and accounting

| Metric | Meaning |
|---|---|
| `submitted_bytes` | Total bytes passed to write calls, including identical no-ops |
| `distinct_updated_bytes` | Unique byte positions updated over the run; zero for no-op work |
| `logged_payload_bytes` | Sum of merged payload ranges from successful commit receipts |
| `redo_bytes` | Payload plus all record framing/descriptors/checksums |
| `record_overhead_bytes` | Redo minus logged payload |
| `checkpoint_bytes` | Sum of scheduled checkpoint-image writes during the interval |
| `interval_write_bytes` | Redo plus scheduled checkpoints; excludes setup and final normalization |
| `initialization_write_bytes` | Initial zero image, seed-data redo, and setup checkpoint |
| `normalization_write_bytes` | Optional extra final checkpoint used to compare clean images; zero if no redo remains |
| `whole_run_write_bytes` | Initialization plus interval plus normalization writes |
| `end_data_bytes` | Actual DATA file length before optional final normalization |
| `end_allocated_file_bytes` | Sum of allocated blocks for arena regular files, including LOCK |
| `end_directory_allocated_bytes` | Directory allocation, reported separately |
| `retained_log_bytes` | Redo still present at the interval endpoint |
| `compacted_*` | Measurements after final redo reclamation; this does not pack objects or shrink arena capacity |
| `max_sampled_*` | Maximum sampled single-DATA size / regular-file allocation during updates and normalization |
| `checkpoint_coexist_logical_estimate` | Modeled old-DATA + complete-new-image logical size before rename; includes final normalization if performed |

Filesystem allocation is measured as Linux `st_blocks × 512`, rather than treating file length as allocated disk space. It is not NAND usage or device bytes written. Directory blocks are separate; inode tables, filesystem journals, allocator metadata, SSD internals and RAM are not included. [Linux inode documentation](https://man7.org/linux/man-pages/man7/inode.7.html)

File allocation is sampled after setup, before and after scheduled checkpoints, at the interval end, and after normalization. This is not a continuous high-water trace. The checkpoint coexistence metric is explicitly a logical-size model, not a measured physical peak.

Ratios:

```text
redo amplification             = redo bytes / logged payload bytes
interval write amplification   = (redo + scheduled checkpoints) / submitted bytes
space amplification            = current file bytes / live application bytes
allocated-space amplification  = allocated regular-file bytes / live application bytes
```

The CSV also reports interval amplification relative to logged payload. Ratios with a zero denominator are `NA` (JSON null), not zero or infinity. Repeatedly changing eight bytes produces eight distinct updated positions but 8000 submitted/logged payload bytes over 1000 transactions; the benchmark keeps those concepts separate.

## Per-transaction logging efficiency

| Update | Submitted bytes | Redo bytes | Framing/descriptor overhead | Redo / payload |
|---|---:|---:|---:|---:|
| One 8-byte field | 8 | 88 | 80 | 11× |
| 32 adjacent 8-byte fields | 256 | 336 | 80 | 1.3125× |
| 32 spread-out 8-byte fields | 256 | 832 | 576 | 3.25× |
| One 4 KiB range | 4096 | 4176 | 80 | 1.01953125× |
| Identical 8-byte no-op | 8 | 0 | 0 | N/A: zero logged payload |

Adjacent writes merge into one range. For the same 256 application bytes, adjacency reduces the redo record from 832 to 336 bytes: **59.6% fewer log bytes**. There is still one transaction header/trailer; grouping fields into fewer transactions can amortize it, but that separate batching policy is not tested here.

## Retained space after checkpointing

The measured allocated regular-file space after checkpointing equals capacity plus the 4096-byte format header in every scenario on this filesystem. Unused zero capacity is physically allocated here; it is not being saved as sparse holes.

| Arena | Live bytes | Occupancy | Checkpoint DATA bytes | Allocated file bytes | Allocated space / live bytes |
|---|---:|---:|---:|---:|---:|
| 256 KiB | 4,096 | 1.5625% | 266,240 | 266,240 | 65.000000× |
| 256 KiB | 65,536 | 25% | 266,240 | 266,240 | 4.062500× |
| 256 KiB | 262,144 | 100% | 266,240 | 266,240 | 1.015625× |
| 8 MiB | 131,072 | 1.5625% | 8,392,704 | 8,392,704 | 64.031250× |
| 8 MiB | 2,097,152 | 25% | 8,392,704 | 8,392,704 | 4.001953× |
| 8 MiB | 8,388,608 | 100% | 8,392,704 | 8,392,704 | 1.000488× |

For example, reserving 8 MiB for 128 KiB of live data costs **8,392,704 file bytes**, or **64.03125×** live data, even after all redo is reclaimed. At full 8 MiB occupancy, the same image costs only **1.000488×** live data. The observed directory itself adds 4096 allocated bytes, reported separately.

This demonstrates a capacity-utilization problem, not retained-log leakage. Checkpointing cannot eliminate unused capacity because the current image format writes the entire fixed-size arena.

## Checkpoint-frequency cost

An 8 MiB arena writes an 8,392,704-byte image at each checkpoint. For 1000 update transactions, the interval write amplification is:

| Update | No scheduled checkpoint | Checkpoint every 1000 | Checkpoint every 100 |
|---|---:|---:|---:|
| 8-byte field | 11.000000× | 1060.088000× | 10501.880000× |
| 32 adjacent fields | 1.312500× | 34.096500× | 329.152500× |
| 32 spread-out fields | 3.250000× | 36.034000× | 331.090000× |
| 4 KiB range | 1.019531× | 3.068531× | 21.509531× |

“No scheduled checkpoint” still flushes the log and retains it at the interval endpoint. If a final normalization checkpoint is needed, its 8,392,704 bytes are recorded separately; they are not silently omitted from `whole_run_write_bytes`. Comparing the normalized whole run therefore removes the apparent free checkpoint deferral.

The schedule deliberately requests checkpoints even for no-op transactions. With no updates and no scheduled checkpoint, interval output is zero. With a forced checkpoint every 100 transactions, the no-op workload writes 83,927,040 checkpoint bytes. That measures unconditional maintenance policy, not an intrinsic need to checkpoint unchanged data; a caller can avoid those requests.

## Retained redo and sampled allocation

For an 8 MiB arena, 128 KiB live prefix and 1000 transactions without scheduled checkpoints:

| Update | Retained redo bytes | End DATA length | End allocated file bytes | After checkpoint: DATA bytes |
|---|---:|---:|---:|---:|
| 8-byte field | 88,000 | 8,480,704 | 8,482,816 | 8,392,704 |
| 32 adjacent fields | 336,000 | 8,728,704 | 8,732,672 | 8,392,704 |
| 32 spread-out fields | 832,000 | 9,224,704 | 9,228,288 | 8,392,704 |
| 4 KiB range | 4,176,000 | 12,568,704 | 12,570,624 | 8,392,704 |
| Identical no-op | 0 | 8,392,704 | 8,392,704 | 8,392,704 |

Logical byte counts are deterministic for these workloads. Allocation values above are medians of the three trials; the JSON also includes minima and maxima. Linux block rounding explains why endpoint allocation can exceed the logical length. Reclaiming redo returns the image to its fixed base size; it does not reduce that base to live bytes.

Checkpoint replacement also requires coexistence space. For the 4 KiB workload in this example, old DATA is 12,568,704 bytes and the new image is 8,392,704 bytes, giving a modeled coexistence size of **20,961,408 bytes**, before directory/filesystem overhead. This is not a measured SSD-allocation peak.

## Validation and reproduction

Every run checks exact commit byte counts, segment bounds, checkpoint reclamation, DATA length versus retained log, and the entire final byte image including unused zeros. After optional normalization, each arena is closed and reopened and the full image is compared again. An independent Python summarizer validates accounting equations for every CSV row, uniqueness, and completeness of the 90-configuration matrix. All **270 runs passed**. Strict Clippy and formatting checks pass; no storage-engine implementation was changed.

From `rust/`:

```sh
cargo run --release --locked --bin storage_efficiency -- --trials 3 > storage-efficiency-results.csv
python3 summarize_storage.py
```

To measure a different filesystem, pass an existing base directory. Only newly created, uniquely named benchmark subdirectories are used and removed:

```sh
cargo run --release --locked --bin storage_efficiency --   --trials 3 --transactions 1000 --base-dir /mnt/test-storage   > storage-efficiency-results.csv
```

The CLI accepts 1–10,000 transactions; checkpoint schedules remain none/every-100/every-1000. To compare a partial final checkpoint interval, choose a count such as 1050. Filesystem allocation is environment-dependent; repeat the benchmark on the deployment filesystem rather than treating overlayfs allocation as a universal constant.

Files: `storage_efficiency.rs`, `storage-efficiency-results.csv`, `storage-efficiency-summary.json`, `summarize_storage.py`, and `storage-efficiency-run.txt`. Raw data is preserved without dropping trials. This benchmark does not compare other database engines or claim Cap’n Proto object-level compression efficiency.
