# Persistent arena contract (v7 / unchanged disk format 1)

`durable::Arena` is an optional local persistence adapter at the segment-storage boundary. It does not change Cap’n Proto wire encoding or add a database query API. Legacy `Engine` and `DeltaEngine` do not acquire this contract.

## API and error handling

- `Arena::create(path, lengths, schema_id, limits)` creates a new dedicated directory and initial zero segment image. Existing paths are refused. If creation fails after filesystem I/O, the newly created directory may remain incomplete; creation is not an idempotent open-or-create operation.
- `Arena::open(path, schema_id, limits)` locks, validates and recovers the arena, stabilizes surviving records, and discards only incomplete EOF records. Wrong schema ID is rejected. Lower open-time limits can intentionally reject a previously valid larger arena/log.
- `segments()` borrows aligned segment slices. Safe Rust disallows beginning a mutable transaction while those slices are still in use.
- `begin()` / `begin_at(generation)` borrow the arena exclusively. `write(segment, byte_offset, bytes)` and `put_word(segment, word_index, value)` track undo and dirty ranges. Failed individual writes leave earlier successful writes in that transaction available; drop the transaction to abort all of them.
- `commit(Durability::Durable)` appends and syncs before success. `Buffered` is explicitly weaker. Receipts contain generation, durable watermark, payload and record byte counts, and merged range count. An empty commit does not advance generation; an empty Durable commit still flushes preceding buffered commits.
- `commit_checked(mode, validator)` checks caller invariants before any commit I/O. The validator sees borrowed segment slices. A returned error or unwind restores memory.
- `Outcome::Rejected` means no commit file I/O was attempted. `Outcome::Unknown` means the record may be present; the arena refuses further reads/writes until dropped and reopened. Do not blindly retry non-idempotent application operations after Unknown.
- `flush()` synchronizes all published commits. `checkpoint()` synchronizes a replacement image and its directory entry. Any error from either poisons the handle conservatively.
- `snapshot()` first copies the current arena into detached immutable memory. If a snapshot of the same generation is still alive, subsequent calls share its bytes through a weak cache. A successful nonempty commit invalidates that cache; existing snapshots remain immutable. The cache itself retains no mapping after the last snapshot drops. A fresh snapshot still costs O(arena bytes); cloning or a cache hit costs O(1). Each returned handle records the current durability watermark, which may advance independently of cached bytes. No durable historical-version registration is created.

The API keeps snapshots free of writer references. A deliberately leaked transaction is detected by an active flag and requires reopen. Durable acknowledgements depend on the filesystem/device honoring sync and rename semantics. Store application request IDs in the same transaction if acknowledgement retries need deduplication.

## Persistent byte layout

All integers are little-endian u64 slots, including CRC32C values (upper 32 bits zero). Magic strings are literal eight-byte arrays.

DATA header: 4096 bytes.

| Offset | Value |
|---:|---|
| 0 | `EAEARE06` magic |
| 8 | Disk format version = 1 |
| 16 | Caller-selected schema identifier |
| 24 | Checkpoint generation |
| 32 | Segment count, 1–64 |
| 40 | Total logical segment bytes |
| 48 | CRC32C of the full checkpoint image |
| 56 | Reserved zero |
| 64 onward | Segment byte lengths, one u64 per segment |
| 4088 | CRC32C of header bytes 0–4087 |

The complete concatenated segment image immediately follows the header, then redo frames. Every segment length is a positive multiple of eight; lengths sum to the stored total. The working mmap rounds its private virtual allocation to host page size, but that padding is not a segment or checkpoint payload.

Transaction frame:

| Offset | Value |
|---:|---|
| 0 | `EAETX006` magic |
| 8 | Complete frame length including trailer |
| 16 | Generation, exactly prior generation + 1 |
| 24 | Number of merged ranges |
| 32 | CRC32C of descriptors plus payload |
| 40 | CRC32C of frame header bytes 0–39 |
| 48 onward | Repeated `(flat logical offset, length, exact payload)` |
| Final 16 bytes | `EAECMIT6`, then generation |

Descriptors are sorted and non-overlapping. Bounds are checked against the logical arena, not mmap padding. Recovery validates all descriptors and checksums before mutating recovered state. Resource limits are applied before allocating record payloads. CRC32C is accidental-corruption detection, not a cryptographic MAC.

A short EOF header or a checksummed header whose frame extends beyond EOF is an incomplete tail. A full corrupted frame/header is an error. Recovery does not automatically salvage a torn full-sized record. Full-suffix removal and checksum collisions are not detectable with certainty from this file alone.

## Checkpoint ordering

1. Under the stable LOCK, create PENDING exclusively.
2. Write the format header and complete current image; sync PENDING.
3. Rename PENDING over DATA in the same directory.
4. Sync that directory; publish the replacement handle and durable watermark.
5. Old DATA loses its writer handle; no detached snapshot depends on its inode.

A crash before replacement leaves the old image plus WAL. After replacement, the image contains the same current state. A successful reopen cleans an unused PENDING file. Creation additionally syncs the parent directory. LOCK must remain at the same path and is never replaced by checkpointing.

## Resource limits and reuse

Defaults: at most 256 MiB of logical segments, 32 MiB per redo record, 64 MiB of undo data per transaction, and 64 MiB of redo since checkpoint. Upper limits prevent excessive allocations; log budget exhaustion rejects commits until an explicit checkpoint. Transaction undo bytes, descriptors and serialization/range buffers retain their high-water allocation capacity for reuse. `scratch_bytes()` reports that capacity and `release_scratch()` releases it between transactions without changing data. Budgets still bound each transaction and record. Snapshot copies and the number of open arenas are controlled by the caller; there is no global memory admission controller.

Segments are fixed in number and capacity. The adapter does not allocate Cap’n Proto objects, compact pointer-bearing graphs, grow segments, or track free blocks. A builder allocator can keep its own allocation metadata inside reserved segment bytes and update metadata, object bytes and owner pointers in the same transaction. It must enforce exclusive ownership, zero initialization and pointer validity when reusing space. Raw byte bounds checks do not establish those object invariants.

## Above this layer

Schema migration, full graph validation with traversal limits, capability-pointer policy, encryption/authentication, replication, cross-arena transactions, request deduplication, database indexes, queries, access control, and backup retention remain outside the adapter. Detached snapshots expose consistent segment bytes that a backup/export layer can serialize. No separate persistent backup catalogue or read-only multi-process open mode is implemented.

Target: 64-bit Linux with 4 KiB pages, trusted directory, cooperating single writer, local filesystem with working fsync/rename/advisory locks and preservation of unrelated file bytes. Do not manually fork and continue using an arena in both processes. Parent/child normal process-spawn locking is tested. Hardware power-loss testing and production qualification remain required.

## v7 implementation changes, unchanged persistence contract

Undo payloads use a pooled contiguous byte buffer with range descriptors; rollback still applies descriptors in reverse mutation order. Ordered writes avoid sorting; unsorted writes sort before unioning ranges. Unchecked `commit` avoids constructing validator segment slices; `commit_checked` still invokes the validator before I/O.

Open reads checkpoint bytes directly into the new writable anonymous mapping and validates before exposing it, avoiding an intermediate image allocation/copy. A 64 KiB buffered reader supplies redo headers/bodies without rereading each header. Descriptor scratch space is reused, but each full record is still validated before any of its ranges is applied.

The format, byte counts, generation sequence, checksums, flush ordering, poisoning, locking and checkpoint publication protocol remain unchanged. The frozen v6 reader and v7 reader can open each other's fixtures.
