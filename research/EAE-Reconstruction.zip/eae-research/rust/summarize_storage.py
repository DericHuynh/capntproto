"""Validate independent byte-accounting equations and summarize all filesystem trials."""
import csv, json, statistics
from pathlib import Path
root=Path(__file__).resolve().parent
rows=list(csv.DictReader((root/'storage-efficiency-results.csv').open()))
keys=['arena_bytes','live_bytes','workload','checkpoint_every','transactions']
shapes={'hot_word':(8,8,88),'adjacent32':(256,256,336),'spread32':(256,256,832),'block4k':(4096,4096,4176),'noop_word':(8,0,0)}
seen=set()
for r in rows:
 assert None not in r and all(v is not None for v in r.values()),'malformed CSV row'
 identity=tuple(r[k] for k in ['trial']+keys); assert identity not in seen;seen.add(identity)
 n=int(r['transactions']);cadence=int(r['checkpoint_every']);base=int(r['arena_bytes'])+4096
 submitted,payload,record=shapes[r['workload']];checkpoints=n//cadence if cadence else 0
 retained=(n%cadence if cadence else n)*record
 expected={
  'submitted_bytes':n*submitted,'distinct_updated_bytes':payload,'logged_payload_bytes':n*payload,
  'redo_bytes':n*record,'record_overhead_bytes':n*(record-payload),'scheduled_checkpoints':checkpoints,
  'checkpoint_bytes':checkpoints*base,'interval_write_bytes':n*record+checkpoints*base,
  'initialization_write_bytes':2*base+int(r['live_bytes'])+80,
  'normalization_write_bytes':base if retained else 0,'base_data_bytes':base,
  'end_data_bytes':base+retained,'retained_log_bytes':retained,'compacted_data_bytes':base,
 }
 for k,v in expected.items():assert int(r[k])==v,(identity,k,r[k],v)
 assert int(r['whole_run_write_bytes'])==int(r['initialization_write_bytes'])+int(r['interval_write_bytes'])+int(r['normalization_write_bytes'])
 assert int(r['max_sampled_data_bytes'])>=int(r['end_data_bytes'])
 for k in ['setup_allocated_file_bytes','end_allocated_file_bytes','compacted_allocated_file_bytes']:
  assert int(r[k])%512==0
trials={r['trial'] for r in rows}
assert all(sum(r['trial']==t for r in rows)==90 for t in trials),'incomplete matrix'
summary=[]
for identity in dict.fromkeys(tuple(r[k] for k in keys) for r in rows):
 group=[r for r in rows if tuple(r[k] for k in keys)==identity]
 item=dict(zip(keys,identity));item['trials']=len(group)
 for k in rows[0]:
  if k in keys or k=='trial':continue
  values=[None if r[k]=='NA' else float(r[k]) for r in group]
  assert all(v is None for v in values) or all(v is not None for v in values)
  item[k]=None if values[0] is None else statistics.median(values)
  if 'allocated' in k:
   item[k+'_min']=min(values);item[k+'_max']=max(values)
 summary.append(item)
(root/'storage-efficiency-summary.json').write_text(json.dumps({'runs':len(rows),'scenarios':len(summary),'trials':len(trials),'cases':summary},indent=2)+'\n')
print(f'{len(rows)} runs validated; {len(summary)} scenarios; {len(trials)} filesystem trials.')
for w in shapes:
 g=next(r for r in summary if r['arena_bytes']=='8388608' and r['live_bytes']=='131072' and r['workload']==w and r['checkpoint_every']=='0')
 print(w,'redo amplification',g['redo_amplification'],'end data bytes',g['end_data_bytes'],'allocated',g['end_allocated_file_bytes'])
