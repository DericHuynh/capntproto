"""Summarize all three trials without discarding outliers. Run beside the CSV."""
import csv, json, statistics
from pathlib import Path
root = Path(__file__).parent
rows = list(csv.DictReader((root / 'delta-throughput-results.csv').open()))
summary = []
for workload in dict.fromkeys(r['workload'] for r in rows):
    for mode in ['v4_pages', 'v5_delta']:
        group = [r for r in rows if r['workload'] == workload and r['mode'] == mode]
        item = {'workload': workload, 'mode': mode}
        for key in group[0]:
            if key not in ['workload', 'mode', 'trial']:
                item[key] = statistics.median(float(r[key]) for r in group)
        summary.append(item)
(root / 'delta-throughput-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for r in summary:
    print(r['workload'], r['mode'], r['application_MB_s'], r['p50_us'], r['snapshot_open_us'])
