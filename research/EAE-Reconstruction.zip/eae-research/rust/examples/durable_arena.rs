//! Run with an unused directory path: cargo run --example durable_arena -- /tmp/my-arena
use eae_pages::{durable::*, near_pointer, PAGE};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let path = std::env::args_os()
        .nth(1)
        .ok_or("provide an unused arena directory path")?;
    let schema_id = 0x8d9b_3e02_a45c_7101;
    let mut arena = Arena::create(&path, &[PAGE], schema_id, Limits::default())?;
    let mut tx = arena.begin()?;
    // A Cap'n Proto struct root with one data word, located at segment word 1.
    tx.put_word(0, 0, near_pointer(0, 1, 0, 1)?)?;
    tx.put_word(0, 1, 42)?;
    let receipt = tx.commit(Durability::Durable)?;
    let snapshot = arena.snapshot()?;
    arena.checkpoint()?;
    drop(arena);
    let recovered = Arena::open(&path, schema_id, Limits::default())?;
    assert_eq!(snapshot.segments(), recovered.segments()?);
    println!(
        "Recovered generation {}; durable through {}; {} payload bytes in {} record bytes",
        recovered.generation(),
        receipt.durable_through,
        receipt.payload_bytes,
        receipt.file_bytes
    );
    Ok(())
}
