# EAE Pages 0.7: durable arena performance improvements

A runnable Rust implementation of page-versioned virtual segments, with reusable private writer mappings. Linux, 64-bit, 4 KiB host pages. Rust 1.90 or later. The core uses only the standard library and a small mmap FFI wrapper; `capnp 0.21.7` is a development dependency for independent reader tests. Cargo.lock pins dependencies.

This is a research prototype. In the legacy page/delta engines, version metadata is process-local and the backing file is temporary and append-only. Those legacy APIs are not reopenable databases. The durable adapter described below supports reopening; none is a complete Cap’n Proto builder. `sync_payload: true` flushes payload bytes, including for an empty transaction, but does not persist a recoverable version manifest.

## Run

```sh
cargo test --all-features --locked
cargo test --release --all-features --locked
cargo clippy --all-targets --all-features --locked -- -D warnings
cargo fmt --check
cargo run --release --locked --bin latency > latency-results.csv
cargo run --release --locked --bin latency -- --reverse > latency-reversed.csv
```

The first build needs registry access for development dependencies. Once cached, add `--offline`. No schema compiler is required: stock-reader tests use built-in generated schema types and generic list readers.

## New in v7: measured optimization of the durable adapter

Transactions reuse undo bytes, undo descriptors and range scratch. Ordered writes avoid sorting; ordinary commits avoid constructing a no-op validator's segment vector. Checkpoint loading reads directly into the writable mmap, and recovery uses a 64 KiB buffered reader with reused descriptors.

`snapshot()` shares an existing live snapshot of the current generation through a weak cache. Fresh snapshots still copy the complete arena. Successful nonempty commits invalidate the cache, while previous snapshots stay immutable. New handles report the latest durability watermark, even when sharing older cached bytes.

`scratch_bytes()` reports retained buffer capacity; `release_scratch()` frees it between transactions. The disk format and durability protocol are unchanged. The complete suite now executes 110 cases with all features.

Frozen baseline source: `../baselines/v6/`. Paired benchmark (five trials, six workloads, two modes, 120 runs):

```sh
cargo build --release --locked --bins
cargo build --release --locked --manifest-path ../baselines/v6/Cargo.toml --bins
python3 run_arena_perf.py --trials 5
python3 check_arena_compat.py
```

See the main report for all results, including buffered single-word and 1 MiB regressions, fresh-snapshot costs, checkpoint amplification, and overlayfs limitations. Do not interpret container sync timings as hardware persistence performance.

## New in v6: optional persistent arena adapter

`durable::Arena` adds persistent multi-segment transactions, sync-before-acknowledgement, checksummed recovery, exclusive writer locking, detached snapshots, atomic checkpoint replacement and redo reclamation. `Durability::Buffered` is explicitly weaker. Ambiguous I/O errors poison the handle and require reopening. Resource limits bound transaction and log growth; checkpoints are scheduled explicitly.

The adapter operates on Cap’n Proto-compatible segment bytes. It has no database dependency, SQL, index, identity or consensus policy. Segment layouts are fixed; builder/allocator integration still owns object allocation and graph correctness. Read `STORAGE-CONTRACT.md` for format, supported assumptions and limitations. The older APIs retain their older guarantees.

```sh
cargo run --example durable_arena -- /tmp/new-arena-directory
cargo run --release --locked --bin durable_throughput > durable-throughput-results.csv
python3 summarize_durable.py
```

The v6 suite executed 106 cases with all features, including child-process interruption at commit/checkpoint boundaries. Container fsync benchmarks do not establish physical-media power-loss durability. Checkpoint and metadata writes count toward amplification.

## New in v5: byte-range commits

`delta::DeltaEngine` mutates its live anonymous mmap in place and logs exact merged byte ranges. An 8-byte edit emits 8 payload bytes plus 32 metadata bytes, instead of a 4096-byte page. Snapshots reconstruct separate mappings by replaying history. Live borrowed reads need no replay. This removes page-payload amplification; it does not eliminate record metadata or filesystem/device amplification.

Small edits improve in the measured workload; full-buffer writes and snapshot opening regress. Historical views replay the entire committed history, with no checkpointing or GC. This is an explicit alternative to `Mode::Batched`, not an automatic hybrid or a durable in-place disk database. The v5 suite executed 86 cases with all features.

```rust
use eae_pages::{delta::DeltaEngine, CommitOptions, PAGE};
fn main() -> std::io::Result<()> {
let mut engine = DeltaEngine::new(PAGE)?;
let mut tx = engine.begin();
tx.put_word(2, 42)?;
let (snapshot, stats) = tx.commit(CommitOptions::default())?;
assert_eq!(stats.payload_bytes, 8);
assert_eq!(stats.log_bytes, 40);
assert_eq!(snapshot.view()?.word(2)?, 42);
Ok(())
}
```

```sh
cargo run --release --locked --bin delta_throughput > delta-throughput-results.csv
python3 summarize_delta.py
```

## New in v4

`Mode::Batched` gathers scattered pages with positional vectored writes, reuses vector storage, updates metadata by leaf and skips sorting already ordered dirty pages. `Mode::Optimized` preserves v3 for comparison.

```sh
cargo run --release --locked --bin throughput > throughput-results.csv
```

The benchmark reports decimal application MB/s separately from whole-page output MB/s across three alternating-order trials, without fsync or durable publication. The v4 suite executes 76 cases, including the shared regression suite in both modes, vectored-I/O tests, gather tests, independent reader tests and borrowing checks.

## Retained changes from v2

- Keep writer mappings and private page copies across commits. Reader views use separate mappings of immutable appended file pages.
- Deduplicate dirty pages using a bitmap and reusable touched-page vector; no full-page-table commit scan.
- Coalesce adjacent writes into at most 1 MiB batches.
- Share version-table roots; copy only modified 256-entry leaves and the root directory.
- Skip identical writes of at most 64 bytes. Larger buffers avoid an extra comparison pass.
- Offer explicit bounded `trim_writer_cache(start_page, count)` and full `release_writer_cache()` maintenance. No automatic threshold pause is hidden inside commit.
- Consume transactions on commit. Abort restores touched pages or drops the private cache on restoration failure.

`Mode::Baseline` is a Rust reference path using a fresh mapping each transaction, a full dirty-page scan and one payload write per page. Both modes share the same persistent in-memory table implementation. It is not the old C++ binary, the stock Cap’n Proto builder, or an optimized database competitor.

## Small example

```rust
use eae_pages::{Engine, Mode, CommitOptions, PAGE};
fn main() -> std::io::Result<()> {
let mut e = Engine::new(64 * PAGE, Mode::Batched)?;
let mut tx = e.begin()?;
tx.put_word(0, 123)?; // raw payload API; caller controls the wire layout
let (old, _) = tx.commit(CommitOptions::default())?;
let mut tx = e.begin()?;
tx.put_word(0, 456)?;
let (new, _) = tx.commit(CommitOptions::default())?;
assert_eq!(old.view()?.word(0)?, 123);
assert_eq!(new.view()?.word(0)?, 456);
Ok(())
}
```

The raw write API does not enforce an object graph. `move_u64_list` is intentionally limited to clean, aligned, whole-page UInt64 lists and caller-owned unused destination ranges. It is not a generic pointer-bearing relocation API.

## Evidence

- `tests/common/regressions.rs`, executed in both v3 and v4 modes: isolation, range checks, abort/unwind, dirty-page boundaries, batching, metadata sharing, relocation, cache retention/trimming, concurrent immutable views and randomized model comparison.
- `tests/stock_reader.rs`: independent decoding of struct/Text, scalar and pointer lists, composite snapshots, handcrafted far/double-far layouts, malformed composite rejection, canonical comparison with a stock-built object.
- Library doctests ensure borrowed bytes cannot survive mutation or commit.
- `fault-injection` exposes deterministic write/publication/flush failure points. These are process-level failure tests, not power-loss simulation.
- CSV files record two final latency runs and the earlier remap-on-commit experiment that regressed on multi-page edits.

Unsafe code is restricted to mappings and slice construction; mapping ownership and immutable backing pages underpin safety. Miri/ThreadSanitizer and hardware fault testing have not been run. Tests do not establish complete Cap’n Proto conformance, recovery correctness or portable ABI support.

## Storage-efficiency benchmark

`storage_efficiency` measures cumulative redo/checkpoint writes separately from logical file size and filesystem-allocated blocks. The default matrix covers 270 runs: two capacities, three occupancies, five update shapes and three checkpoint schedules, repeated three times. Every run validates bytes and reopens the final image.

```sh
cargo run --release --locked --bin storage_efficiency -- --trials 3 > storage-efficiency-results.csv
python3 summarize_storage.py
```

Use `--base-dir EXISTING_DIRECTORY` to test a deployment filesystem and `--transactions 1050` to test an incomplete checkpoint interval. See `../EAE-Storage-Efficiency.md` for metric definitions, full accounting and measured results. This measures raw segment storage; it does not simulate an object allocator or compare schema encodings.
