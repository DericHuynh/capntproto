"""Compute per-workload medians; no trial exclusions. Run from any directory."""
import csv, json, statistics
from pathlib import Path
root = Path(__file__).parent
rows = list(csv.DictReader((root / 'durable-throughput-results.csv').open()))
summary = []
for workload in dict.fromkeys(r['workload'] for r in rows):
    for mode in ['Buffered', 'Durable']:
        group = [r for r in rows if r['workload'] == workload and r['mode'] == mode]
        item = {'workload': workload, 'mode': mode}
        for key in group[0]:
            if key not in ['workload', 'mode', 'trial']:
                item[key] = statistics.median(float(r[key]) for r in group)
        summary.append(item)
(root / 'durable-throughput-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for r in summary:
    print(r['workload'],r['mode'],r['application_MB_s'],r['MB_s_including_checkpoint'],r['p50_us'],r['checkpoint_us'])
