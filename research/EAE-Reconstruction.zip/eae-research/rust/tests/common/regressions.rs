use eae_pages::*;
use std::sync::Arc;
fn engine() -> Engine {
    Engine::new(64 * PAGE, ACTIVE).unwrap()
}
fn commit_word(e: &mut Engine, w: usize, v: u64) -> Snapshot {
    let mut t = e.begin().unwrap();
    t.put_word(w, v).unwrap();
    t.commit(CommitOptions::default()).unwrap().0
}
fn list_pointer(slot: u64, body: u64, n: u32, code: u32) -> u64 {
    near_pointer(slot, body, 1, (n << 3) | code).unwrap()
}

#[test]
fn rejects_invalid_segment_sizes() {
    for n in [0, 1, PAGE - 1, PAGE + 1, usize::MAX, 512 * 1024 * 1024] {
        assert!(Engine::new(n, ACTIVE).is_err());
    }
}
#[test]
fn zero_segment_and_end_empty_read() {
    let e = engine();
    let v = e.snapshot().view().unwrap();
    assert!(v.read(0, 64 * PAGE).unwrap().iter().all(|&b| b == 0));
    assert_eq!(v.read(64 * PAGE, 0).unwrap(), b"");
}
#[test]
fn bounds_and_overflow_do_not_dirty() {
    let mut e = engine();
    let mut t = e.begin().unwrap();
    assert!(t.write(usize::MAX, &[1]).is_err());
    assert!(t.write(64 * PAGE, &[1]).is_err());
    assert!(t.put_word(usize::MAX, 3).is_err());
    assert_eq!(t.dirty_pages(), 0);
}
#[test]
fn empty_transaction_does_not_advance() {
    let mut e = engine();
    let (s, stats) = e.begin().unwrap().commit(CommitOptions::default()).unwrap();
    assert_eq!(s.generation(), 0);
    assert_eq!(stats.payload_bytes, 0);
}
#[test]
fn repeated_writes_emit_one_page() {
    let mut e = engine();
    let mut t = e.begin().unwrap();
    for x in 1..1000 {
        t.put_word(1, x).unwrap();
    }
    assert_eq!(t.dirty_pages(), 1);
    let (s, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.payload_bytes, PAGE);
    assert_eq!(s.view().unwrap().word(1).unwrap(), 999);
}
#[test]
fn same_value_skips_cow_and_io() {
    let mut e = engine();
    let old = commit_word(&mut e, 4, 99);
    let mut t = e.begin().unwrap();
    t.put_word(4, 99).unwrap();
    let (s, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.dirty_pages, 0);
    assert_eq!(st.write_batches, 0);
    assert_eq!(old.generation(), s.generation());
}
#[test]
fn crossing_page_write_marks_both() {
    let mut e = engine();
    let mut t = e.begin().unwrap();
    t.write(PAGE - 3, &[1; 9]).unwrap();
    let (s, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.dirty_pages, 2);
    assert_eq!(st.write_batches, 1);
    assert_eq!(s.view().unwrap().read(PAGE - 3, 9).unwrap(), [1; 9]);
}
#[test]
fn adjacent_pages_batch_but_holes_do_not() {
    let mut e = engine();
    let mut t = e.begin().unwrap();
    for p in [5, 2, 3, 9, 4] {
        t.put_word(p * PAGE / 8, 1).unwrap();
    }
    let (_, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.write_batches, if ACTIVE==Mode::Batched {1} else {2});
    assert_eq!(st.scanned_pages, 0);
}
#[test]
fn warm_writer_uses_no_mapping_syscalls() {
    let mut e = engine();
    commit_word(&mut e, 1, 1);
    let mut t = e.begin().unwrap();
    t.put_word(1, 2).unwrap();
    let (_, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.mapping_calls, 0);
}
#[test]
fn old_snapshot_survives_and_outlives_engine() {
    let old;
    {
        let mut e = engine();
        old = commit_word(&mut e, 0, 7);
        commit_word(&mut e, 0, 8);
    }
    assert_eq!(old.view().unwrap().word(0).unwrap(), 7);
}
#[test]
fn abort_restores_existing_and_zero_pages() {
    let mut e = engine();
    commit_word(&mut e, 1, 7);
    {
        let mut t = e.begin().unwrap();
        t.put_word(1, 8).unwrap();
        t.put_word(PAGE / 8, 9).unwrap();
    }
    let t = e.begin().unwrap();
    assert_eq!(t.read(8, 8).unwrap(), 7u64.to_le_bytes());
    assert_eq!(t.read(PAGE, 8).unwrap(), [0; 8]);
}
#[test]
fn panic_unwind_aborts() {
    let mut e = engine();
    commit_word(&mut e, 0, 5);
    let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let mut t = e.begin().unwrap();
        t.put_word(0, 6).unwrap();
        panic!("rollback");
    }));
    assert!(r.is_err());
    assert_eq!(e.snapshot().view().unwrap().word(0).unwrap(), 5);
    assert_eq!(e.begin().unwrap().read(0, 8).unwrap(), 5u64.to_le_bytes());
}
#[test]
fn baseline_and_optimized_have_equal_values() {
    for mode in [Mode::Baseline, ACTIVE] {
        let mut e = Engine::new(64 * PAGE, mode).unwrap();
        for n in 1..30 {
            let mut t = e.begin().unwrap();
            t.put_word(n * 512, n as u64).unwrap();
            t.commit(CommitOptions::default()).unwrap();
        }
        let v = e.snapshot().view().unwrap();
        for n in 1..30 {
            assert_eq!(v.word(n * 512).unwrap(), n as u64);
        }
    }
}
#[test]
fn leaf_boundary_snapshot_isolation() {
    let mut e = Engine::new(1024 * PAGE, ACTIVE).unwrap();
    let old = e.snapshot();
    let mut t = e.begin().unwrap();
    for p in [0, 255, 256, 511, 512, 1023] {
        t.put_word(p * 512, 44).unwrap();
    }
    let (s, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.changed_table_leaves, 4);
    assert_eq!(st.root_entries_copied, 4);
    let a = old.view().unwrap();
    let b = s.view().unwrap();
    for p in [0, 255, 256, 511, 512, 1023] {
        assert_eq!(a.word(p * 512).unwrap(), 0);
        assert_eq!(b.word(p * 512).unwrap(), 44);
    }
}
#[test]
fn batch_size_is_bounded() {
    let mut e = Engine::new(300 * PAGE, ACTIVE).unwrap();
    let mut t = e.begin().unwrap();
    t.write(0, &vec![1; 300 * PAGE]).unwrap();
    let (_, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.write_batches, 2);
}
#[test]
fn text_append_preserves_old_terminator() {
    let mut e = engine();
    let mut t = e.begin().unwrap();
    t.put_word(0, near_pointer(0, 1, 0, 1 << 16).unwrap())
        .unwrap();
    t.put_word(1, list_pointer(1, 512, 3, 2)).unwrap();
    t.write(PAGE, b"ab\0").unwrap();
    let old = t.commit(CommitOptions::default()).unwrap().0;
    let mut t = e.begin().unwrap();
    t.write(PAGE + 2, b"c\0").unwrap();
    t.put_word(1, list_pointer(1, 512, 4, 2)).unwrap();
    let new = t.commit(CommitOptions::default()).unwrap().0;
    assert_eq!(old.view().unwrap().read(PAGE, 3).unwrap(), b"ab\0");
    assert_eq!(new.view().unwrap().read(PAGE, 4).unwrap(), b"abc\0");
}
#[test]
fn composite_tag_and_pointer_change_together() {
    let mut e = engine();
    let mut t = e.begin().unwrap();
    t.put_word(0, near_pointer(0, 1, 0, 1 << 16).unwrap())
        .unwrap();
    t.put_word(1, list_pointer(1, 512, 2, 7)).unwrap();
    t.put_word(512, (1 << 32) | (2 << 2)).unwrap();
    let old = t.commit(CommitOptions::default()).unwrap().0;
    let mut t = e.begin().unwrap();
    t.put_word(515, 99).unwrap();
    t.put_word(512, (1 << 32) | (3 << 2)).unwrap();
    t.put_word(1, list_pointer(1, 512, 3, 7)).unwrap();
    let new = t.commit(CommitOptions::default()).unwrap().0;
    for (s, n) in [(old, 2), (new, 3)] {
        let v = s.view().unwrap();
        assert_eq!(v.word(1).unwrap() >> 35, n);
        assert_eq!((v.word(512).unwrap() >> 2) & ((1 << 30) - 1), n);
    }
}
#[test]
fn near_boundaries_and_negative_offsets() {
    let slot = 1u64 << 32;
    for off in [-(1i64 << 29), -1, 0, (1 << 29) - 1] {
        let target = (slot as i64 + 1 + off) as u64;
        let p = near_pointer(slot, target, 1, 123).unwrap();
        assert_eq!(near_target(slot, p).unwrap(), target);
    }
    assert!(near_pointer(slot, slot + 1 + (1 << 29), 0, 0).is_err());
    assert!(near_pointer(slot, slot - (1 << 29), 0, 0).is_err());
}
#[test]
fn near_invalid_kinds_and_target_overflow() {
    assert!(near_pointer(0, 0, 2, 0).is_err());
    assert!(near_target(0, 2).is_err());
    assert!(near_target(0, 3).is_err());
    assert!(near_target(u64::MAX, 0).is_err());
    let p = near_pointer(8, 0, 0, 1).unwrap();
    assert!(near_target(0, p).is_err());
}
fn seeded_list(e: &mut Engine) -> Snapshot {
    let mut t = e.begin().unwrap();
    t.put_word(0, near_pointer(0, 1, 0, 1 << 16).unwrap())
        .unwrap();
    t.put_word(1, list_pointer(1, 512, 1024, 5)).unwrap();
    t.write(PAGE, &vec![42; 2 * PAGE]).unwrap();
    t.commit(CommitOptions::default()).unwrap().0
}
#[test]
fn scalar_relocation_reuses_body_pages() {
    let mut e = engine();
    let old = seeded_list(&mut e);
    let (new, st) = e.move_u64_list(1, 8).unwrap();
    assert_eq!(st.payload_bytes, PAGE);
    let a = old.view().unwrap();
    let b = new.view().unwrap();
    assert_eq!(
        a.read(PAGE, 2 * PAGE).unwrap(),
        b.read(8 * PAGE, 2 * PAGE).unwrap()
    );
    assert!(b.read(PAGE, 2 * PAGE).unwrap().iter().all(|&b| b == 0));
    assert_eq!(near_target(1, b.word(1).unwrap()).unwrap(), 4096);
}
#[test]
fn relocation_rejects_overlap_and_occupied_range() {
    let mut e = engine();
    seeded_list(&mut e);
    assert!(e.move_u64_list(1, 2).is_err());
    commit_word(&mut e, 8 * 512, 1);
    assert!(e.move_u64_list(1, 8).is_err());
    assert!(e.move_u64_list(1, usize::MAX).is_err());
}
#[test]
fn relocation_rejects_pointer_and_partial_lists() {
    let mut e = engine();
    for (n, kind) in [(512, 6), (511, 5), (0, 5)] {
        commit_word(&mut e, 1, list_pointer(1, 512, n, kind));
        assert!(e.move_u64_list(1, 8).is_err());
    }
}
#[test]
fn shared_snapshot_readers_during_commits() {
    let mut e = engine();
    let old = commit_word(&mut e, 0, 77);
    let v = Arc::new(old.view().unwrap());
    let mut threads = Vec::new();
    for _ in 0..4 {
        let v = v.clone();
        threads.push(std::thread::spawn(move || {
            for _ in 0..10000 {
                assert_eq!(v.word(0).unwrap(), 77);
            }
        }));
    }
    for x in 100..150 {
        commit_word(&mut e, 0, x);
    }
    for t in threads {
        t.join().unwrap();
    }
}
#[test]
fn randomized_model_and_pinned_snapshots() {
    for seed in 1..=12 {
        let mut rng = seed as u64;
        let mut e = Engine::new(16 * PAGE, ACTIVE).unwrap();
        let mut model = vec![0u8; 16 * PAGE];
        let mut pins = Vec::new();
        for tx in 0..80 {
            let mut t = e.begin().unwrap();
            let mut next = model.clone();
            for _ in 0..24 {
                rng ^= rng << 13;
                rng ^= rng >> 7;
                rng ^= rng << 17;
                let pos = (rng as usize) % (next.len() - 16);
                let data = rng.to_le_bytes();
                t.write(pos, &data).unwrap();
                next[pos..pos + 8].copy_from_slice(&data);
            }
            if tx % 7 == 0 {
                drop(t);
            } else {
                let (s, _) = t.commit(CommitOptions::default()).unwrap();
                model = next;
                if tx % 16 == 0 {
                    pins.push((s, model.clone()));
                }
            }
            assert_eq!(
                e.snapshot().view().unwrap().read(0, model.len()).unwrap(),
                model
            );
            for (s, m) in &pins {
                assert_eq!(s.view().unwrap().read(0, m.len()).unwrap(), m);
            }
        }
    }
}
#[test]
fn payload_flush_option_preserves_values() {
    let mut e = engine();
    let mut t = e.begin().unwrap();
    t.put_word(3, 9).unwrap();
    let (s, _) = t.commit(CommitOptions { sync_payload: true }).unwrap();
    assert_eq!(s.view().unwrap().word(3).unwrap(), 9);
}

#[cfg(feature = "fault-injection")]
#[test]
fn failed_commits_do_not_publish_and_writer_recovers() {
    for f in [
        Failure::BeforeWrite,
        Failure::AfterFirstWrite,
        Failure::BeforePublish,
        Failure::PayloadSync,
    ] {
        let mut e = engine();
        let old = commit_word(&mut e, 0, 7);
        e.inject_failure(f);
        let mut t = e.begin().unwrap();
        t.put_word(0, 8).unwrap();
        t.put_word(4 * 512, 99).unwrap();
        assert!(t
            .commit(CommitOptions {
                sync_payload: matches!(f, Failure::PayloadSync)
            })
            .is_err());
        assert_eq!(e.snapshot().generation(), old.generation());
        assert_eq!(e.snapshot().view().unwrap().word(0).unwrap(), 7);
        assert_eq!(
            commit_word(&mut e, 0, 9).view().unwrap().word(0).unwrap(),
            9
        );
        assert_eq!(old.view().unwrap().word(0).unwrap(), 7);
    }
}
#[cfg(feature = "fault-injection")]
#[test]
fn failed_relocation_restores_original_manifest() {
    let mut e = engine();
    let old = seeded_list(&mut e);
    e.inject_failure(Failure::BeforePublish);
    assert!(e.move_u64_list(1, 8).is_err());
    let v = e.snapshot().view().unwrap();
    assert_eq!(v.word(1).unwrap(), old.view().unwrap().word(1).unwrap());
    assert_eq!(v.read(PAGE, 8).unwrap(), [42; 8]);
    assert!(v.read(8 * PAGE, 8).unwrap().iter().all(|&x| x == 0));
    assert!(e.move_u64_list(1, 8).is_ok());
}

#[test]
fn released_writer_cache_rebuilds_correctly() {
    let mut e = engine();
    let old = commit_word(&mut e, 2, 8);
    commit_word(&mut e, 2, 9);
    e.release_writer_cache();
    let t = e.begin().unwrap();
    assert_eq!(t.read(16, 8).unwrap(), 9u64.to_le_bytes());
    drop(t);
    assert_eq!(old.view().unwrap().word(2).unwrap(), 8);
}
#[test]
fn abort_does_not_revert_earlier_private_commits() {
    let mut e = engine();
    commit_word(&mut e, 0, 1);
    commit_word(&mut e, 512, 2);
    {
        let mut t = e.begin().unwrap();
        t.put_word(0, 99).unwrap();
    }
    let t = e.begin().unwrap();
    assert_eq!(t.read(0, 8).unwrap(), 1u64.to_le_bytes());
    assert_eq!(t.read(PAGE, 8).unwrap(), 2u64.to_le_bytes());
}

#[test]
fn bounded_cache_trim_preserves_values_and_snapshots() {
    let mut e = engine();
    let old = commit_word(&mut e, 0, 1);
    commit_word(&mut e, 512, 2);
    assert_eq!(e.trim_writer_cache(0, 1).unwrap(), 1);
    assert!(e.trim_writer_cache(usize::MAX, 1).is_err());
    let t = e.begin().unwrap();
    assert_eq!(t.read(0, 8).unwrap(), 1u64.to_le_bytes());
    assert_eq!(t.read(PAGE, 8).unwrap(), 2u64.to_le_bytes());
    drop(t);
    assert_eq!(old.view().unwrap().word(512).unwrap(), 0);
    assert_eq!(e.trim_writer_cache(64, 0).unwrap(), 0);
}

#[cfg(feature = "fault-injection")]
#[test]
fn empty_payload_sync_failure_is_not_ignored() {
    let mut e = engine();
    e.inject_failure(Failure::PayloadSync);
    let t = e.begin().unwrap();
    assert!(t.commit(CommitOptions { sync_payload: true }).is_err());
    assert_eq!(e.snapshot().generation(), 0);
}
