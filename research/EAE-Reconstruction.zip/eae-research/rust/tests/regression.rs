const ACTIVE: eae_pages::Mode = eae_pages::Mode::Optimized;
include!("common/regressions.rs");
