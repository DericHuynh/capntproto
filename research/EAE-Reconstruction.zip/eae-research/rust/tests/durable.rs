use eae_pages::{durable::*, near_pointer, PAGE};
use std::{
    fs,
    io::{self, Write},
    path::PathBuf,
    sync::atomic::{AtomicU64, Ordering},
};
static NEXT: AtomicU64 = AtomicU64::new(0);
struct Place(PathBuf);
impl Place {
    fn new() -> Self {
        Self(std::env::temp_dir().join(format!(
            "eae-durable-test-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        )))
    }
    fn arena(&self) -> Arena {
        Arena::create(&self.0, &[PAGE, PAGE], 77, Limits::default()).unwrap()
    }
    fn open(&self) -> io::Result<Arena> {
        Arena::open(&self.0, 77, Limits::default())
    }
    fn raw(&self, bytes: &[u8]) {
        fs::create_dir(&self.0).unwrap();
        fs::File::create(self.0.join("DATA"))
            .unwrap()
            .write_all(bytes)
            .unwrap();
    }
}
impl Drop for Place {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn value(a: &Arena, segment: usize) -> u64 {
    u64::from_le_bytes(a.segments().unwrap()[segment][..8].try_into().unwrap())
}
fn set(a: &mut Arena, x: u64, y: u64, d: Durability) -> Receipt {
    let mut t = a.begin().unwrap();
    t.put_word(0, 0, x).unwrap();
    t.put_word(1, 0, y).unwrap();
    t.commit(d).unwrap()
}
#[test]
fn durable_multisegment_reopen_and_receipt() {
    let p = Place::new();
    let mut a = p.arena();
    let r = set(&mut a, 11, 22, Durability::Durable);
    assert_eq!(
        (
            r.generation,
            r.durable_through,
            r.payload_bytes,
            r.file_bytes,
            r.ranges
        ),
        (1, 1, 16, 112, 2)
    );
    drop(a);
    let a = p.open().unwrap();
    assert_eq!((value(&a, 0), value(&a, 1)), (11, 22));
    assert_eq!(a.recovery().replayed_transactions, 1);
    assert_eq!(a.durable_through(), 1);
}
#[test]
fn buffered_flush_and_empty_durable_commit() {
    let p = Place::new();
    let mut a = p.arena();
    let r = set(&mut a, 1, 2, Durability::Buffered);
    assert_eq!(r.durable_through, 0);
    let r = a.begin().unwrap().commit(Durability::Durable).unwrap();
    assert_eq!((r.generation, r.durable_through, r.file_bytes), (1, 1, 0));
    set(&mut a, 3, 4, Durability::Buffered);
    assert_eq!(a.flush().unwrap(), 2);
    drop(a);
    let a = p.open().unwrap();
    assert_eq!((value(&a, 0), value(&a, 1)), (3, 4));
}
#[test]
fn abort_overlap_unwind_and_validation_rejection() {
    let p = Place::new();
    let mut a = p.arena();
    set(&mut a, 7, 8, Durability::Durable);
    {
        let mut t = a.begin().unwrap();
        t.write(0, 0, &[1; 20]).unwrap();
        t.write(0, 4, &[2; 20]).unwrap();
    }
    assert_eq!(value(&a, 0), 7);
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let mut t = a.begin().unwrap();
        t.put_word(0, 0, 99).unwrap();
        panic!("abort");
    }));
    assert!(result.is_err());
    assert_eq!(value(&a, 0), 7);
    let mut t = a.begin().unwrap();
    t.put_word(0, 0, 99).unwrap();
    let e = t
        .commit_checked(Durability::Durable, |_| {
            Err(io::Error::other("schema validation failed"))
        })
        .unwrap_err();
    assert_eq!(e.outcome, Outcome::Rejected);
    assert_eq!(value(&a, 0), 7);
    assert_eq!(a.generation(), 1);
}
#[test]
fn leak_is_detected_and_cannot_publish_partial_state() {
    let p = Place::new();
    let mut a = p.arena();
    let mut t = a.begin().unwrap();
    t.put_word(0, 0, 12).unwrap();
    std::mem::forget(t);
    assert!(a.begin().is_err());
    assert!(a.segments().is_err());
    assert!(a.snapshot().is_err());
    assert!(a.checkpoint().is_err());
    drop(a);
    assert_eq!(value(&p.open().unwrap(), 0), 0);
}
#[test]
fn limits_bounds_schema_and_stale_generation() {
    let p = Place::new();
    let mut a = Arena::create(
        &p.0,
        &[PAGE, PAGE],
        77,
        Limits {
            max_undo_bytes: 8,
            max_log_bytes: 88,
            ..Limits::default()
        },
    )
    .unwrap();
    let mut t = a.begin().unwrap();
    assert!(t.write(2, 0, &[1]).is_err());
    assert!(t.write(0, PAGE, &[1]).is_err());
    assert!(t.put_word(0, usize::MAX, 1).is_err());
    t.put_word(0, 0, 1).unwrap();
    assert!(t.put_word(1, 0, 2).is_err());
    t.commit(Durability::Durable).unwrap();
    assert!(a.begin_at(0).is_err());
    let mut t = a.begin_at(1).unwrap();
    t.put_word(0, 0, 2).unwrap();
    assert_eq!(
        t.commit(Durability::Durable).unwrap_err().outcome,
        Outcome::Rejected
    );
    assert_eq!(value(&a, 0), 1);
    a.checkpoint().unwrap();
    let mut t = a.begin().unwrap();
    t.put_word(0, 0, 2).unwrap();
    t.commit(Durability::Durable).unwrap();
    drop(a);
    assert!(Arena::open(&p.0, 88, Limits::default()).is_err());
    assert_eq!(value(&p.open().unwrap(), 0), 2);
    let bad = Place::new();
    assert!(Arena::create(&bad.0, &[7], 77, Limits::default()).is_err());
    assert!(!bad.0.exists());
}
#[test]
fn snapshot_survives_checkpoint_engine_and_threads() {
    let p = Place::new();
    let mut a = p.arena();
    set(&mut a, 11, 22, Durability::Durable);
    let old = a.snapshot().unwrap();
    set(&mut a, 33, 44, Durability::Durable);
    let before = fs::metadata(p.0.join("DATA")).unwrap().len();
    let cp = a.checkpoint().unwrap();
    assert_eq!(cp.reclaimed_log_bytes, 224);
    assert_eq!(cp.file_bytes, before - 224);
    assert_eq!(a.log_bytes(), 0);
    drop(a);
    let a = p.open().unwrap();
    assert_eq!(a.recovery().replayed_transactions, 0);
    assert_eq!(a.generation(), 2);
    assert_eq!((value(&a, 0), value(&a, 1)), (33, 44));
    std::thread::spawn(move || {
        assert_eq!(old.generation, 1);
        assert_eq!(&old.segments()[0][..8], &11u64.to_le_bytes());
    })
    .join()
    .unwrap();
}
#[test]
fn every_truncated_record_suffix_recovers_only_whole_transactions() {
    let p = Place::new();
    let mut a = p.arena();
    set(&mut a, 11, 22, Durability::Durable);
    let before = fs::metadata(p.0.join("DATA")).unwrap().len() as usize;
    set(&mut a, 33, 44, Durability::Durable);
    drop(a);
    let full = fs::read(p.0.join("DATA")).unwrap();
    for cut in 0..=full.len() - before {
        let q = Place::new();
        q.raw(&full[..before + cut]);
        let a = q.open().unwrap();
        if before + cut == full.len() {
            assert_eq!((value(&a, 0), value(&a, 1)), (33, 44));
        } else {
            assert_eq!((value(&a, 0), value(&a, 1)), (11, 22));
            assert_eq!(a.recovery().discarded_tail_bytes, cut as u64);
        }
    }
}
#[test]
fn corrupt_complete_records_and_checkpoint_fail_closed_without_truncation() {
    let p = Place::new();
    let mut a = p.arena();
    set(&mut a, 11, 22, Durability::Durable);
    drop(a);
    let full = fs::read(p.0.join("DATA")).unwrap();
    let start = 4096 + 2 * PAGE;
    for at in [
        0,
        8,
        16,
        4096,
        start,
        start + 8,
        start + 16,
        start + 32,
        start + 40,
        start + 48,
        start + 64,
        full.len() - 1,
    ] {
        let mut bad = full.clone();
        bad[at] ^= 1;
        let q = Place::new();
        q.raw(&bad);
        assert!(q.open().is_err(), "offset {at}");
        assert_eq!(fs::read(q.0.join("DATA")).unwrap(), bad);
    }
}
#[test]
fn stock_capnp_far_pointer_and_validation_hook() {
    use capnp::message::{Reader, ReaderOptions, SegmentArray};
    let p = Place::new();
    let mut a = p.arena();
    let mut t = a.begin().unwrap();
    t.put_word(0, 0, (1u64 << 32) | 2).unwrap(); // root points to segment 1 landing pad
    t.put_word(1, 0, near_pointer(0, 1, 0, 1).unwrap()).unwrap();
    t.put_word(1, 1, 123).unwrap();
    t.commit_checked(Durability::Durable, |segments| {
        let r = Reader::new(SegmentArray::new(segments), ReaderOptions::new());
        let root = r
            .get_root::<capnp::schema_capnp::enumerant::Reader>()
            .map_err(io::Error::other)?;
        if root.get_code_order() != 123 {
            return Err(io::Error::other("field invariant"));
        }
        Ok(())
    })
    .unwrap();
    drop(a);
    let a = p.open().unwrap();
    let segments = a.segments().unwrap();
    let r = Reader::new(SegmentArray::new(&segments), ReaderOptions::new());
    assert_eq!(
        r.get_root::<capnp::schema_capnp::enumerant::Reader>()
            .unwrap()
            .get_code_order(),
        123
    );
}
#[test]
fn randomized_reopen_checkpoint_abort_model() {
    let p = Place::new();
    let mut a = p.arena();
    let mut model = vec![vec![0; PAGE]; 2];
    let mut rng = 123u64;
    for round in 0..160 {
        let mut next = model.clone();
        let mut t = a.begin().unwrap();
        for _ in 0..12 {
            rng ^= rng << 13;
            rng ^= rng >> 7;
            rng ^= rng << 17;
            let seg = rng as usize % 2;
            let n = (rng >> 8) as usize % 64 + 1;
            let pos = (rng >> 16) as usize % (PAGE - n);
            let data = vec![rng as u8; n];
            t.write(seg, pos, &data).unwrap();
            next[seg][pos..pos + n].copy_from_slice(&data);
        }
        if round % 7 == 0 {
            drop(t);
        } else {
            t.commit(Durability::Durable).unwrap();
            model = next;
        }
        if round % 13 == 0 {
            a.checkpoint().unwrap();
        }
        if round % 11 == 0 {
            drop(a);
            a = p.open().unwrap();
        }
        assert_eq!(
            a.segments().unwrap(),
            model.iter().map(Vec::as_slice).collect::<Vec<_>>()
        );
    }
}
#[cfg(feature = "fault-injection")]
#[test]
fn uncertain_commit_poison_and_recovery_outcome() {
    for point in [
        FaultPoint::PartialAppend,
        FaultPoint::AfterAppend,
        FaultPoint::AfterSync,
    ] {
        let p = Place::new();
        let mut a = p.arena();
        set(&mut a, 11, 22, Durability::Durable);
        a.inject_fault(point, false);
        let mut t = a.begin().unwrap();
        t.put_word(0, 0, 33).unwrap();
        t.put_word(1, 0, 44).unwrap();
        assert_eq!(
            t.commit(Durability::Durable).unwrap_err().outcome,
            Outcome::Unknown
        );
        assert!(a.segments().is_err());
        assert!(a.begin().is_err());
        drop(a);
        let a = p.open().unwrap();
        let expected = if point == FaultPoint::PartialAppend {
            (11, 22)
        } else {
            (33, 44)
        };
        assert_eq!((value(&a, 0), value(&a, 1)), expected);
    }
}
#[cfg(feature = "fault-injection")]
#[test]
fn checkpoint_errors_require_reopen_and_preserve_state() {
    for point in [
        FaultPoint::BeforeRename,
        FaultPoint::AfterRename,
        FaultPoint::AfterDirectorySync,
    ] {
        let p = Place::new();
        let mut a = p.arena();
        set(&mut a, 11, 22, Durability::Durable);
        a.inject_fault(point, false);
        assert!(a.checkpoint().is_err());
        assert!(a.begin().is_err());
        drop(a);
        let mut a = p.open().unwrap();
        assert_eq!((value(&a, 0), value(&a, 1)), (11, 22));
        a.checkpoint().unwrap();
    }
}
#[cfg(feature = "fault-injection")]
fn child(p: &Place, scenario: &str) -> std::process::ExitStatus {
    std::process::Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "crash_worker", "--nocapture"])
        .env("EAE_TEST_PATH", &p.0)
        .env("EAE_TEST_SCENARIO", scenario)
        .stdout(std::process::Stdio::null())
        .status()
        .unwrap()
}
#[cfg(feature = "fault-injection")]
#[test]
fn process_death_at_commit_and_checkpoint_boundaries() {
    for scenario in [
        "uncommitted",
        "partial",
        "append",
        "sync",
        "before_rename",
        "after_rename",
        "directory_sync",
    ] {
        let p = Place::new();
        let mut a = p.arena();
        set(&mut a, 11, 22, Durability::Durable);
        drop(a);
        assert_eq!(child(&p, scenario).code(), Some(86));
        let a = p.open().unwrap();
        let expected = if ["uncommitted", "partial"].contains(&scenario) {
            (11, 22)
        } else {
            (33, 44)
        };
        assert_eq!((value(&a, 0), value(&a, 1)), expected, "{scenario}");
    }
}
#[test]
fn exclusive_writer_lock_and_no_overwrite_create() {
    let p = Place::new();
    let mut a = p.arena();
    set(&mut a, 11, 22, Durability::Durable);
    assert!(p.open().is_err());
    assert!(Arena::create(&p.0, &[PAGE], 77, Limits::default()).is_err());
    #[cfg(feature = "fault-injection")]
    assert!(child(&p, "lock").success());
    drop(a);
    assert_eq!(value(&p.open().unwrap(), 0), 11);
}
#[cfg(feature = "fault-injection")]
#[test]
fn crash_worker() {
    let Ok(path) = std::env::var("EAE_TEST_PATH") else {
        return;
    };
    let scenario = std::env::var("EAE_TEST_SCENARIO").unwrap();
    if scenario == "lock" {
        assert!(Arena::open(path, 77, Limits::default()).is_err());
        return;
    }
    let mut a = Arena::open(path, 77, Limits::default()).unwrap();
    if scenario == "uncommitted" {
        let mut t = a.begin().unwrap();
        t.put_word(0, 0, 33).unwrap();
        std::process::exit(86);
    }
    let commit_point = match scenario.as_str() {
        "partial" => Some(FaultPoint::PartialAppend),
        "append" => Some(FaultPoint::AfterAppend),
        "sync" => Some(FaultPoint::AfterSync),
        _ => None,
    };
    if let Some(point) = commit_point {
        a.inject_fault(point, true);
        set(&mut a, 33, 44, Durability::Durable);
    } else {
        set(&mut a, 33, 44, Durability::Durable);
        let point = match scenario.as_str() {
            "before_rename" => FaultPoint::BeforeRename,
            "after_rename" => FaultPoint::AfterRename,
            "directory_sync" => FaultPoint::AfterDirectorySync,
            _ => panic!("scenario"),
        };
        a.inject_fault(point, true);
        a.checkpoint().unwrap();
    }
    panic!("fault did not terminate process");
}

#[test]
fn shared_snapshot_cache_isolation_and_durability_watermark() {
    let p = Place::new();
    let mut a = p.arena();
    set(&mut a, 11, 22, Durability::Buffered);
    let first = a.snapshot().unwrap();
    let second = a.snapshot().unwrap();
    assert_eq!(first.segments()[0].as_ptr(), second.segments()[0].as_ptr());
    assert_eq!(first.durable_through, 0);
    a.flush().unwrap();
    let flushed = a.snapshot().unwrap();
    assert_eq!(flushed.segments()[0].as_ptr(), first.segments()[0].as_ptr());
    assert_eq!(flushed.durable_through, 1);
    assert_eq!(first.durable_through, 0);
    {
        let mut t = a.begin().unwrap();
        t.put_word(0, 0, 99).unwrap();
    }
    let after_abort = a.snapshot().unwrap();
    assert_eq!(
        after_abort.segments()[0].as_ptr(),
        first.segments()[0].as_ptr()
    );
    set(&mut a, 33, 44, Durability::Durable);
    let new = a.snapshot().unwrap();
    assert_ne!(new.segments()[0].as_ptr(), first.segments()[0].as_ptr());
    assert_eq!(&first.segments()[0][..8], &11u64.to_le_bytes());
    assert_eq!(&new.segments()[0][..8], &33u64.to_le_bytes());
}
#[test]
fn scratch_release_preserves_state_and_future_abort() {
    let p = Place::new();
    let mut a = p.arena();
    set(&mut a, 11, 22, Durability::Durable);
    let old = a.snapshot().unwrap();
    assert!(a.scratch_bytes() > 0);
    let before = a.scratch_bytes();
    assert_eq!(a.release_scratch().unwrap(), before);
    assert_eq!(a.scratch_bytes(), 0);
    {
        let mut t = a.begin().unwrap();
        t.write(0, 0, &[9; 80]).unwrap();
        t.write(0, 4, &[8; 20]).unwrap();
    }
    assert_eq!((value(&a, 0), value(&a, 1)), (11, 22));
    set(&mut a, 55, 66, Durability::Durable);
    assert_eq!(&old.segments()[0][..8], &11u64.to_le_bytes());
    drop(a);
    let a = p.open().unwrap();
    assert_eq!((value(&a, 0), value(&a, 1)), (55, 66));
}
#[test]
fn pooled_undo_rejection_then_overlapping_commits() {
    let p = Place::new();
    let mut a = p.arena();
    for i in 1..=100u8 {
        let before = a.segments().unwrap()[0].to_vec();
        let mut t = a.begin().unwrap();
        t.write(0, 64, &[i; 64]).unwrap();
        t.write(0, 32, &[i + 1; 64]).unwrap();
        if i % 3 == 0 {
            assert_eq!(
                t.commit_checked(Durability::Buffered, |_| Err(io::Error::other("rejected")))
                    .unwrap_err()
                    .outcome,
                Outcome::Rejected
            );
            assert_eq!(a.segments().unwrap()[0], before);
        } else {
            let r = t.commit(Durability::Buffered).unwrap();
            assert_eq!(r.payload_bytes, 96);
            assert_eq!(&a.segments().unwrap()[0][32..96], &[i + 1; 64]);
            assert_eq!(&a.segments().unwrap()[0][96..128], &[i; 32]);
        }
    }
    a.flush().unwrap();
    let before = a.snapshot().unwrap();
    drop(a);
    let a = p.open().unwrap();
    assert_eq!(before.segments(), a.segments().unwrap());
}
#[test]
fn recovery_records_cross_buffer_boundaries_and_large_record() {
    let p = Place::new();
    let mut a = Arena::create(&p.0, &[256 * 1024], 77, Limits::default()).unwrap();
    for i in 1..=1700u64 {
        let mut t = a.begin().unwrap();
        t.put_word(0, 0, i).unwrap();
        t.commit(Durability::Buffered).unwrap();
    }
    let bytes = vec![0x51; 128 * 1024 + 7];
    let mut t = a.begin().unwrap();
    t.write(0, 24, &bytes).unwrap();
    t.commit(Durability::Durable).unwrap();
    let expected = a.snapshot().unwrap();
    drop(a);
    let a = p.open().unwrap();
    assert_eq!(a.recovery().replayed_transactions, 1701);
    assert_eq!(expected.segments(), a.segments().unwrap());
}
