const ACTIVE: eae_pages::Mode = eae_pages::Mode::Batched;
include!("common/regressions.rs");
