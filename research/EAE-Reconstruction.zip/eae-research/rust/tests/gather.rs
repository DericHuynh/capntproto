use eae_pages::*;
#[test]
fn out_of_order_sparse_pages_gather_and_decode_correctly() {
    let mut e = Engine::new(1024 * PAGE, Mode::Batched).unwrap();
    let old = e.snapshot();
    let mut tx = e.begin().unwrap();
    let pages = [700, 1, 256, 63, 999, 4, 512];
    for &p in &pages {
        tx.write(p * PAGE, &vec![(p % 251 + 1) as u8; PAGE])
            .unwrap();
    }
    let (s, stats) = tx.commit(CommitOptions::default()).unwrap();
    assert_eq!(stats.write_batches, 1);
    assert_eq!(stats.payload_bytes, pages.len() * PAGE);
    let v = s.view().unwrap();
    let o = old.view().unwrap();
    for p in 0..1024 {
        let expected = if pages.contains(&p) {
            (p % 251 + 1) as u8
        } else {
            0
        };
        assert!(v
            .read(p * PAGE, PAGE)
            .unwrap()
            .iter()
            .all(|&x| x == expected));
        assert!(o.read(p * PAGE, PAGE).unwrap().iter().all(|&x| x == 0));
    }
}
#[test]
fn gather_batch_boundary_preserves_physical_order() {
    let mut e = Engine::new(1024 * PAGE, Mode::Batched).unwrap();
    let mut t = e.begin().unwrap();
    for p in (0..300).rev() {
        t.put_word((p * 3) * 512, p as u64 + 1).unwrap();
    }
    let (s, st) = t.commit(CommitOptions::default()).unwrap();
    assert_eq!(st.write_batches, 2);
    let v = s.view().unwrap();
    for p in 0..300 {
        assert_eq!(v.word(p * 3 * 512).unwrap(), p as u64 + 1);
        assert_eq!(v.word((p * 3 + 1) * 512).unwrap(), 0);
    }
}
