//! Independent decoding and canonical comparison using capnp 0.21.x.
use capnp::message::{Reader, ReaderOptions, SegmentArray};
use eae_pages::*;
fn list(slot: u64, body: u64, n: u32, kind: u32) -> u64 {
    near_pointer(slot, body, 1, (n << 3) | kind).unwrap()
}
fn publish(t: Transaction<'_>) -> Snapshot {
    t.commit(CommitOptions::default()).unwrap().0
}

#[test]
fn stock_struct_text_and_canonical_model() {
    let mut e = Engine::new(8 * PAGE, Mode::Batched).unwrap();
    let mut t = e.begin().unwrap();
    t.put_word(0, near_pointer(0, 1, 0, 1 | (1 << 16)).unwrap())
        .unwrap();
    t.put_word(1, 7).unwrap();
    t.put_word(2, list(2, 512, 4, 2)).unwrap();
    t.write(PAGE, b"abc\0").unwrap();
    let s = publish(t);
    let v = s.view().unwrap();
    let segments = [v.read(0, s.bytes()).unwrap()];
    let r = Reader::new(SegmentArray::new(&segments), ReaderOptions::new());
    let root = r
        .get_root::<capnp::schema_capnp::enumerant::Reader>()
        .unwrap();
    assert_eq!(root.get_code_order(), 7);
    assert_eq!(root.get_name().unwrap().to_str().unwrap(), "abc");
    let mut expected = capnp::message::Builder::new_default();
    {
        let mut root = expected.init_root::<capnp::schema_capnp::enumerant::Builder>();
        root.set_code_order(7);
        root.set_name("abc");
    }
    let er = Reader::new(expected, ReaderOptions::new());
    assert_eq!(r.canonicalize().unwrap(), er.canonicalize().unwrap());
}
#[test]
fn stock_scalar_list_after_page_rebinding() {
    let mut e = Engine::new(16 * PAGE, Mode::Batched).unwrap();
    let mut t = e.begin().unwrap();
    t.put_word(0, list(0, 512, 512, 5)).unwrap();
    for i in 0..512 {
        t.put_word(512 + i, i as u64 + 1).unwrap();
    }
    let old = publish(t);
    let (new, _) = e.move_u64_list(0, 8).unwrap();
    for s in [old, new] {
        let v = s.view().unwrap();
        let seg = [v.read(0, s.bytes()).unwrap()];
        let r = Reader::new(SegmentArray::new(&seg), ReaderOptions::new());
        let values = r.get_root::<capnp::primitive_list::Reader<u64>>().unwrap();
        assert_eq!(values.len(), 512);
        for i in 0..512 {
            assert_eq!(values.get(i), i as u64 + 1);
        }
    }
}
#[test]
fn stock_pointer_list_with_backward_near_edge() {
    let mut e = Engine::new(8 * PAGE, Mode::Batched).unwrap();
    let mut t = e.begin().unwrap();
    t.put_word(0, list(0, 512, 2, 6)).unwrap();
    t.put_word(512, list(512, 1024, 6, 2)).unwrap();
    t.put_word(513, list(513, 8, 5, 2)).unwrap();
    t.write(2 * PAGE, b"alpha\0").unwrap();
    t.write(64, b"beta\0").unwrap();
    let s = publish(t);
    let v = s.view().unwrap();
    let seg = [v.read(0, s.bytes()).unwrap()];
    let r = Reader::new(SegmentArray::new(&seg), ReaderOptions::new());
    let values = r.get_root::<capnp::text_list::Reader>().unwrap();
    assert_eq!(values.get(0).unwrap().to_str().unwrap(), "alpha");
    assert_eq!(values.get(1).unwrap().to_str().unwrap(), "beta");
}
#[test]
fn stock_composite_old_and_new_versions() {
    let mut e = Engine::new(8 * PAGE, Mode::Batched).unwrap();
    let mut t = e.begin().unwrap();
    t.put_word(0, list(0, 512, 2, 7)).unwrap();
    t.put_word(512, (1 << 32) | (2 << 2)).unwrap();
    t.put_word(513, 7).unwrap();
    t.put_word(514, 8).unwrap();
    let old = publish(t);
    let mut t = e.begin().unwrap();
    t.put_word(0, list(0, 512, 3, 7)).unwrap();
    t.put_word(512, (1 << 32) | (3 << 2)).unwrap();
    t.put_word(515, 9).unwrap();
    let new = publish(t);
    for (s, n) in [(old, 2), (new, 3)] {
        let v = s.view().unwrap();
        let seg = [v.read(0, s.bytes()).unwrap()];
        let r = Reader::new(SegmentArray::new(&seg), ReaderOptions::new());
        let values = r
            .get_root::<capnp::struct_list::Reader<capnp::schema_capnp::enumerant::Owned>>()
            .unwrap();
        assert_eq!(values.len(), n);
        for i in 0..n {
            assert_eq!(values.get(i).get_code_order(), 7 + i as u16);
        }
    }
}
#[test]
fn stock_far_and_double_far_segments() {
    for double in [false, true] {
        let mut a = Engine::new(PAGE, Mode::Batched).unwrap();
        let mut b = Engine::new(PAGE, Mode::Batched).unwrap();
        let mut t = a.begin().unwrap();
        t.put_word(0, (1u64 << 32) | 2 | if double { 4 } else { 0 })
            .unwrap();
        let sa = publish(t);
        let mut t = b.begin().unwrap();
        if double {
            t.put_word(0, (1u64 << 32) | (2 << 3) | 2).unwrap();
            t.put_word(1, 1 << 32).unwrap();
            t.put_word(2, 123).unwrap();
        } else {
            t.put_word(0, near_pointer(0, 1, 0, 1).unwrap()).unwrap();
            t.put_word(1, 123).unwrap();
        }
        let sb = publish(t);
        let va = sa.view().unwrap();
        let vb = sb.view().unwrap();
        let segments = [va.read(0, PAGE).unwrap(), vb.read(0, PAGE).unwrap()];
        let r = Reader::new(SegmentArray::new(&segments), ReaderOptions::new());
        assert_eq!(
            r.get_root::<capnp::schema_capnp::enumerant::Reader>()
                .unwrap()
                .get_code_order(),
            123
        );
    }
}
#[test]
fn stock_rejects_inconsistent_composite_tag() {
    let mut e = Engine::new(2 * PAGE, Mode::Batched).unwrap();
    let mut t = e.begin().unwrap();
    t.put_word(0, list(0, 512, 1, 7)).unwrap();
    t.put_word(512, (1 << 32) | (2 << 2)).unwrap();
    let s = publish(t);
    let v = s.view().unwrap();
    let seg = [v.read(0, s.bytes()).unwrap()];
    let r = Reader::new(SegmentArray::new(&seg), ReaderOptions::new());
    assert!(r
        .get_root::<capnp::struct_list::Reader<capnp::schema_capnp::enumerant::Owned>>()
        .is_err());
}
