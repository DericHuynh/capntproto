use eae_pages::{delta::*, *};
fn commit(t: DeltaTransaction<'_>) -> (DeltaSnapshot, DeltaStats) {
    t.commit(CommitOptions::default()).unwrap()
}
#[test]
fn exact_byte_accounting_and_old_snapshot() {
    let mut e = DeltaEngine::new(2 * PAGE).unwrap();
    let zero = e.snapshot();
    let mut t = e.begin();
    t.put_word(2, 17).unwrap();
    let (old, stats) = commit(t);
    assert_eq!(
        (stats.payload_bytes, stats.log_bytes, stats.ranges),
        (8, 40, 1)
    );
    let old_view = old.view().unwrap();
    let mut t = e.begin();
    t.put_word(2, 99).unwrap();
    commit(t);
    assert_eq!(zero.view().unwrap().word(2).unwrap(), 0);
    assert_eq!(old.view().unwrap().word(2).unwrap(), 17);
    assert_eq!(old_view.word(2).unwrap(), 17);
    assert_eq!(e.read(16, 8).unwrap(), 99u64.to_le_bytes());
}
#[test]
fn overlapping_adjacent_and_cross_page_ranges() {
    let mut e = DeltaEngine::new(2 * PAGE).unwrap();
    let mut t = e.begin();
    t.write(PAGE - 3, &[1; 8]).unwrap();
    t.write(PAGE, &[2; 8]).unwrap();
    t.write(PAGE + 8, &[3; 2]).unwrap();
    let (s, stats) = commit(t);
    assert_eq!(
        (stats.payload_bytes, stats.log_bytes, stats.ranges),
        (13, 45, 1)
    );
    assert_eq!(
        s.view().unwrap().read(PAGE - 3, 13).unwrap(),
        &[1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3]
    );
}
#[test]
fn abort_restores_overlaps_in_reverse_order() {
    let mut e = DeltaEngine::new(PAGE).unwrap();
    let mut t = e.begin();
    t.write(0, &[4; 32]).unwrap();
    commit(t);
    {
        let mut t = e.begin();
        t.write(0, &[5; 20]).unwrap();
        t.write(10, &[6; 20]).unwrap();
    }
    assert_eq!(e.read(0, 32).unwrap(), &[4; 32]);
}
#[test]
fn empty_noop_bounds_and_overflow() {
    assert!(DeltaEngine::new(0).is_err());
    assert!(DeltaEngine::new(PAGE - 1).is_err());
    let mut e = DeltaEngine::new(PAGE).unwrap();
    let mut t = e.begin();
    t.write(PAGE, &[]).unwrap();
    t.put_word(0, 0).unwrap();
    assert!(t.write(PAGE, &[1]).is_err());
    assert!(t.put_word(usize::MAX, 1).is_err());
    assert_eq!(commit(t).1.log_bytes, 0);
}
#[test]
fn snapshot_survives_engine_and_is_thread_readable() {
    let s = {
        let mut e = DeltaEngine::new(PAGE).unwrap();
        let mut t = e.begin();
        t.put_word(0, 42).unwrap();
        commit(t).0
    };
    let s2 = s.clone();
    std::thread::spawn(move || assert_eq!(s2.view().unwrap().word(0).unwrap(), 42))
        .join()
        .unwrap();
    assert_eq!(s.view().unwrap().word(0).unwrap(), 42);
}
#[cfg(feature = "fault-injection")]
#[test]
fn partial_write_failure_restores_writer_and_skips_orphan() {
    let mut e = DeltaEngine::new(PAGE).unwrap();
    let mut t = e.begin();
    t.put_word(0, 10).unwrap();
    let old = commit(t).0;
    e.fail_next_commit();
    let mut t = e.begin();
    t.put_word(0, 20).unwrap();
    assert!(t.commit(CommitOptions::default()).is_err());
    assert_eq!(e.read(0, 8).unwrap(), 10u64.to_le_bytes());
    let mut t = e.begin();
    t.put_word(1, 30).unwrap();
    let new = commit(t).0;
    assert_eq!(old.view().unwrap().word(0).unwrap(), 10);
    let v = new.view().unwrap();
    assert_eq!(v.word(0).unwrap(), 10);
    assert_eq!(v.word(1).unwrap(), 30);
}
#[test]
fn randomized_model_pinned_versions_and_aborts() {
    for seed in 1..=8 {
        let mut rng = seed;
        let mut e = DeltaEngine::new(3 * PAGE).unwrap();
        let mut model = vec![0; 3 * PAGE];
        let mut pinned = Vec::new();
        for tx in 0..100 {
            let mut candidate = model.clone();
            let mut t = e.begin();
            for _ in 0..20 {
                rng ^= rng << 13;
                rng ^= rng >> 7;
                rng ^= rng << 17;
                let n = (rng as usize % 80) + 1;
                let pos = ((rng >> 12) as usize) % (model.len() - n);
                let data = vec![rng as u8; n];
                t.write(pos, &data).unwrap();
                candidate[pos..pos + n].copy_from_slice(&data);
            }
            if tx % 7 == 0 {
                drop(t);
            } else {
                let s = commit(t).0;
                model = candidate;
                if tx % 13 == 0 {
                    pinned.push((s, model.clone()));
                }
            }
            assert_eq!(e.read(0, model.len()).unwrap(), model);
        }
        for (s, expected) in pinned {
            assert_eq!(s.view().unwrap().read(0, expected.len()).unwrap(), expected);
        }
        assert_eq!(
            e.snapshot().view().unwrap().read(0, model.len()).unwrap(),
            model
        );
    }
}
#[test]
fn stock_capnp_reads_live_and_reconstructed_versions() {
    use capnp::message::{Reader, ReaderOptions, SegmentArray};
    let mut e = DeltaEngine::new(2 * PAGE).unwrap();
    let mut t = e.begin();
    t.put_word(0, near_pointer(0, 1, 0, 1 | (1 << 16)).unwrap())
        .unwrap();
    t.put_word(1, 7).unwrap();
    t.put_word(2, near_pointer(2, 512, 1, (4 << 3) | 2).unwrap())
        .unwrap();
    t.write(PAGE, b"abc\0").unwrap();
    let old = commit(t).0;
    let mut t = e.begin();
    t.write(PAGE, b"xyz").unwrap();
    t.put_word(1, 9).unwrap();
    commit(t);
    let old_view = old.view().unwrap();
    for (bytes, code, name) in [
        (old_view.read(0, 2 * PAGE).unwrap(), 7, "abc"),
        (e.read(0, 2 * PAGE).unwrap(), 9, "xyz"),
    ] {
        let segments = [bytes];
        let r = Reader::new(SegmentArray::new(&segments), ReaderOptions::new());
        let root = r
            .get_root::<capnp::schema_capnp::enumerant::Reader>()
            .unwrap();
        assert_eq!(root.get_code_order(), code);
        assert_eq!(root.get_name().unwrap().to_str().unwrap(), name);
    }
}
#[test]
fn long_history_drops_iteratively() {
    let mut e = DeltaEngine::new(PAGE).unwrap();
    for i in 1..=20000 {
        let mut t = e.begin();
        t.put_word(0, i).unwrap();
        commit(t);
    }
    let s = e.snapshot();
    drop(e);
    drop(s);
}
