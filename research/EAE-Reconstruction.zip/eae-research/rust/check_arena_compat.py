"""Cross-open current/frozen fixtures and compare exact DATA file bytes."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parent
old=root.parent/'baselines/v6/target/release/arena_compat'; new=root/'target/release/arena_compat'
with tempfile.TemporaryDirectory(prefix='eae-compat-') as tmp:
 a=Path(tmp)/'v6'; b=Path(tmp)/'v7'
 for binary,mode,path in [(old,'write',a),(new,'read',a),(new,'write',b),(old,'read',b)]:
  subprocess.run([str(binary),mode,str(path)],check=True)
 assert (a/'DATA').read_bytes()==(b/'DATA').read_bytes()
 print('Both cross-version reopen checks passed; checkpoint plus redo bytes are identical.')
