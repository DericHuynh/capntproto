"""Run frozen/current executables sequentially with balanced ordering; no outlier removal."""
import argparse, csv, json, statistics, subprocess
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--baseline-only',action='store_true');p.add_argument('--trials',type=int,default=5)
a=p.parse_args(); root=Path(__file__).resolve().parent
bins={'v6':root.parent/'baselines/v6/target/release/arena_perf','v7':root/'target/release/arena_perf'}
fields='version,trial,workload,mode,transactions,app_bytes_per_tx,record_bytes_per_tx,timed_seconds,application_MB_s,p50_us,p99_us,fresh_snapshot_us,repeated_snapshot_us,replay_open_us,clean_open_us,checkpoint_us,MB_s_including_checkpoint,write_amplification_including_checkpoint'.split(',')
name='arena-perf-baseline.csv' if a.baseline_only else 'arena-perf-results.csv'
with (root/name).open('w') as f:
 f.write(','.join(fields)+'\n')
 for wi,w in enumerate(['word','scatter32','reverse32','4KiB','64KiB','1MiB']):
  for trial in range(a.trials):
   for mi,mode in enumerate(['Buffered','Durable']):
    versions=['v6'] if a.baseline_only else (['v6','v7'] if (trial+wi+mi)%2==0 else ['v7','v6'])
    for v in versions:
     result=subprocess.run([str(bins[v]),v,str(trial),w,mode],capture_output=True,text=True,check=True,timeout=60)
     f.write(result.stdout); f.flush()
  print(f'{w} completed',flush=True)
rows=list(csv.DictReader((root/name).open()));summary=[]
for w in dict.fromkeys(r['workload'] for r in rows):
 for mode in ['Buffered','Durable']:
  for version in (['v6'] if a.baseline_only else ['v6','v7']):
   group=[r for r in rows if r['workload']==w and r['mode']==mode and r['version']==version]
   item={'workload':w,'mode':mode,'version':version}
   for key in fields:
    if key not in ['workload','mode','version','trial']:
     item[key]=statistics.median(float(r[key]) for r in group)
   item['throughput_min']=min(float(r['application_MB_s']) for r in group)
   item['throughput_max']=max(float(r['application_MB_s']) for r in group)
   summary.append(item)
(root/name.replace('.csv','-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
