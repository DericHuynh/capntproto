// Derived from the v1 scalar allocator experiment; counters are not storage I/O.
// Native allocator/list-growth experiment. Not a Cap'n Proto implementation.
// Fixed backing arena avoids measuring vector reallocation of the arena itself.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <map>
#include <random>
#include <stdexcept>
#include <vector>
#include <sys/mman.h>
#include <unistd.h>
using U=uint64_t; using S=size_t;
struct Heap {
 U* w; S arena_words; bool scrub; std::map<S,S> address; std::multimap<S,S> sizes;
 S copied=0,zeroed=0,moves=0,high=0;
 Heap(S n,bool clear):arena_words(n),scrub(clear){w=(U*)mmap(nullptr,n*8,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(w==MAP_FAILED)throw std::bad_alloc();add(0,n);}
 ~Heap(){munmap(w,arena_words*8);}
 void add(S a,S n){address[a]=n;sizes.emplace(n,a);}
 void remove(S a){S n=address.at(a);auto [b,e]=sizes.equal_range(n);for(;b!=e;++b)if(b->second==a){sizes.erase(b);break;}address.erase(a);}
 S alloc(S n){auto it=sizes.lower_bound(n);if(it==sizes.end())throw std::bad_alloc();S a=it->second,s=it->first;remove(a);if(s>n)add(a+n,s-n);high=std::max(high,a+n);return a;}
 void free(S a,S n){if(scrub){std::memset(w+a,0,n*8);zeroed+=n;}auto it=address.lower_bound(a);if(it!=address.end()&&a+n==it->first){S x=it->first,s=it->second;remove(x);n+=s;}it=address.lower_bound(a);if(it!=address.begin()){--it;if(it->first+it->second==a){S x=it->first,s=it->second;remove(x);a=x;n+=s;}}add(a,n);}
 bool extend(S end,S extra){auto it=address.find(end);if(it==address.end()||it->second<extra)return false;S s=it->second;remove(end);if(s>extra)add(end+extra,s-extra);high=std::max(high,end+extra);return true;}
};
struct List {S a=0,n=0,cap=0;};
void append(Heap& h,List& l,U value,bool adjacent=true){
 if(l.n==l.cap){S cap=std::max(S(1),l.cap*2);if(l.cap&&adjacent&&h.extend(l.a+l.cap,cap-l.cap))l.cap=cap;
 else {S a=h.alloc(cap);if(l.n){std::memcpy(&h.w[a],&h.w[l.a],l.n*8);h.copied+=l.n;}if(l.cap)h.free(l.a,l.cap);l.a=a;l.cap=cap;h.moves++;}}
 h.w[l.a+l.n++]=value;
}

volatile U sink=0;
S resident(void* p,S bytes){std::vector<unsigned char> v(bytes/4096);if(mincore(p,bytes,v.data()))throw std::runtime_error("mincore");S pages=0;for(auto x:v)pages+=bool(x&1);return pages;}
int main(){
 if(sysconf(_SC_PAGESIZE)!=4096)return 2;
 std::cout<<"mode,appends,median_ms,copy_words,clear_words,resident_pages,logical_extent_words\n";
 const S total=1000000,count=64,lane_words=131072,arena_words=count*lane_words;
 for(int mode=0;mode<3;++mode){std::vector<double> times;S copied=0,cleared=0,pages=0,extent=0;
  for(int rep=0;rep<7;++rep){Heap h(arena_words,mode==0);std::vector<List> lists(count);
   auto start=std::chrono::steady_clock::now();
   for(S i=0;i<total;++i){S j=i%count;if(mode<2)append(h,lists[j],i);else{auto& l=lists[j];if(l.n==lane_words)throw std::runtime_error("reservation exhausted");l.a=j*lane_words;h.w[l.a+l.n++]=i;}}
   auto end=std::chrono::steady_clock::now();times.push_back(std::chrono::duration<double,std::milli>(end-start).count());
   U check=0;for(S j=0;j<count;++j)for(S k=0;k<lists[j].n;++k){U want=k*count+j;if(h.w[lists[j].a+k]!=want)throw std::runtime_error("bad value");check+=want;}sink=check;
   copied=h.copied;cleared=h.zeroed;pages=resident(h.w,arena_words*8);extent=mode==2?arena_words:h.high;
  }
  std::sort(times.begin(),times.end());const char* names[]={"v1_eager_clear","v2_lazy_clear","v2_reserved_large_lists"};
  std::cout<<names[mode]<<','<<total<<','<<times[3]<<','<<copied<<','<<cleared<<','<<pages<<','<<extent<<'\n';
 }
}
