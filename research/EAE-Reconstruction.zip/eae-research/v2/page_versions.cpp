// Linux/x86-64 research prototype: immutable backing pages, contiguous virtual
// Cap'n Proto segment views, explicit write-set tracking, process-local manifests.
// NOT a complete Cap'n Proto reader, allocator, or crash-safe database.
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <chrono>
#include <algorithm>
#include <iostream>
#include <memory>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using U=uint64_t; using S=size_t;
static S PS;
void require(bool b,const char* what){if(!b)throw std::runtime_error(what);}
void write_all(int fd,const void* p,S n,off_t pos){auto b=(const char*)p;while(n){ssize_t r=pwrite(fd,b,n,pos);if(r<0&&errno==EINTR)continue;if(r<=0)throw std::runtime_error("pwrite");b+=r;n-=r;pos+=r;}}
struct Store{
 int fd;off_t tail=0;U written=0;
 Store(){char path[]="/tmp/eae-pages-XXXXXX";fd=mkstemp(path);require(fd>=0,"mkstemp");unlink(path);}
 ~Store(){close(fd);}
 off_t append(const void* p){off_t a=tail;write_all(fd,p,PS,a);tail+=PS;written+=PS;return a;}
};
struct Version{std::vector<off_t> map;};
struct View{
 Store& store;Version v;unsigned char* base;S bytes,runs=0;bool writable;std::vector<bool> dirty;
 View(Store& s,const Version& version,bool rw):store(s),v(version),bytes(v.map.size()*PS),writable(rw),dirty(v.map.size(),false){
  int prot=PROT_READ|(rw?PROT_WRITE:0);
  void* b=mmap(nullptr,bytes,prot,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);require(b!=MAP_FAILED,"reserve");base=(unsigned char*)b;
  for(S i=0;i<v.map.size();){if(v.map[i]<0){++i;continue;}S n=1;while(i+n<v.map.size()&&v.map[i+n]==v.map[i]+off_t(n*PS))++n;
   void* q=mmap(base+i*PS,n*PS,prot,MAP_PRIVATE|MAP_FIXED,s.fd,v.map[i]);require(q!=MAP_FAILED,"map run");++runs;i+=n;}
 }
 ~View(){munmap(base,bytes);}
 View(const View&)=delete;View& operator=(const View&)=delete;
 void mark(S pos,S n){require(writable&&pos<=bytes&&n<=bytes-pos,"write bounds");if(n)for(S p=pos/PS;p<=(pos+n-1)/PS;++p)dirty[p]=true;}
 void put(S word,U value){require(word<bytes/8,"word bounds");mark(word*8,8);std::memcpy(base+word*8,&value,8);}
 U get(S word)const{require(word<bytes/8,"read bounds");U n;std::memcpy(&n,base+word*8,8);return n;}
 void bytes_put(S pos,const void* p,S n){mark(pos,n);std::memcpy(base+pos,p,n);}
 S dirty_count()const{return std::count(dirty.begin(),dirty.end(),true);}
 Version commit(bool flush=false){require(writable,"commit readonly");Version out=v;for(S p=0;p<dirty.size();++p)if(dirty[p])out.map[p]=store.append(base+p*PS);if(flush)require(fdatasync(store.fd)==0,"fdatasync");return out;}
};
U nearptr(S slot,S target,unsigned kind,U high){int64_t off=int64_t(target)-int64_t(slot)-1;require(off>=-(1LL<<29)&&off<(1LL<<29),"near range");return (high<<32)|((U(off)&((1ULL<<30)-1))<<2)|kind;}
S target(S slot,U w){int64_t off=(w>>2)&((1ULL<<30)-1);if(off&(1LL<<29))off-=1LL<<30;int64_t t=int64_t(slot)+1+off;require(t>=0,"negative target");return S(t);}
U listptr(S slot,S body,S count,unsigned element){return nearptr(slot,body,1,(U(count)<<3)|element);}
void root(View& t){t.put(0,nearptr(0,1,0,U(3)<<16));} // root has 3 pointer fields
void check_list(const View& v,S n,S changed,U val){U p=v.get(1);require((p&3)==1&&p>>35==n,"list shape");S a=target(1,p);require(v.get(a+changed)==val,"list value");}
int main(){try{
 PS=sysconf(_SC_PAGESIZE);require(PS==4096,"experiment requires 4 KiB pages");
 Store s;Version empty{std::vector<off_t>((32*1024*1024)/PS,-1)};
 const S body=PS/8,n=(8*1024*1024)/8,textword=16*1024*1024/8,composite=20*1024*1024/8;
 Version initial;{View t(s,empty,true);root(t);t.put(1,listptr(1,body,n,5));for(S i=0;i<n;++i)t.put(body+i,i);
 t.put(2,listptr(2,textword,3,2));t.bytes_put(textword*8,"ab\0",3);
 t.put(3,listptr(3,composite,2,7));t.put(composite,(U(1)<<32)|(U(2)<<2));t.put(composite+1,11);t.put(composite+2,22);initial=t.commit(true);}
 View old(s,initial,false);U before=s.written;Version scalar;S scalar_dirty;
 {View t(s,initial,true);t.put(body+12345,99999);scalar_dirty=t.dirty_count();scalar=t.commit(true);}
 View newer(s,scalar,false);check_list(old,n,12345,12345);check_list(newer,n,12345,99999);
 require(old.get(0)==newer.get(0)&&old.get(1)==newer.get(1),"unchanged pointers");
 U scalar_written=s.written-before;
 Version grown;S text_dirty,composite_dirty;
 {View t(s,scalar,true);t.bytes_put(textword*8+2,"c\0",2);t.put(2,listptr(2,textword,4,2));text_dirty=t.dirty_count();grown=t.commit();}
 View textview(s,grown,false);require(old.base[textword*8+2]==0&&textview.base[textword*8+2]=='c',"text snapshot");
 {View t(s,grown,true);t.put(composite+3,33);t.put(composite,(U(1)<<32)|(U(3)<<2));t.put(3,listptr(3,composite,3,7));composite_dirty=t.dirty_count();grown=t.commit();}
 View compview(s,grown,false);require((old.get(3)>>35)==2&&((old.get(composite)>>2)&((1U<<30)-1))==2,"old composite");require((compview.get(3)>>35)==3&&((compview.get(composite)>>2)&((1U<<30)-1))==3,"new composite");
 // Relocate the clean, page-aligned scalar list by rebinding physical pages.
 // Only its owner pointer needs new payload bytes; current logical old range is zero.
 const S moved_body=24*1024*1024/8;
 Version alias=scalar;
 for(S p=0;p<n*8/PS;++p){alias.map[moved_body*8/PS+p]=scalar.map[body*8/PS+p];alias.map[body*8/PS+p]=-1;}
 U alias_before=s.written;S alias_dirty;
 {View t(s,alias,true);t.put(1,listptr(1,moved_body,n,5));alias_dirty=t.dirty_count();alias=t.commit();}
 View aliasview(s,alias,false);check_list(aliasview,n,12345,99999);
 require(aliasview.get(body)==0&&old.get(body+12345)==12345,"alias relocation snapshot");
 for(S i=0;i<n;++i)require(aliasview.get(moved_body+i)==newer.get(body+i),"alias payload mismatch");
 U alias_written=s.written-alias_before;
 // Random transactions; retained snapshots checked after later writes.
 Version current=grown;std::vector<U> model(n);for(S i=0;i<n;++i)model[i]=i;model[12345]=99999;
 std::mt19937_64 rng(7741);std::vector<std::unique_ptr<View>> pins;std::vector<std::vector<std::pair<S,U>>> checks;S edits=0;
 for(S tx=0;tx<100;++tx){View t(s,current,true);for(S j=0;j<32;++j){S at=rng()%n;U v=rng();t.put(body+at,v);model[at]=v;++edits;}current=t.commit();
  if(tx%10==0){pins.emplace_back(new View(s,current,false));checks.emplace_back();for(S j=0;j<100;++j){S at=rng()%n;checks.back().push_back({at,model[at]});}}
  for(S k=0;k<pins.size();++k)for(auto [at,v]:checks[k])require(pins[k]->get(body+at)==v,"pinned version changed");
 }
 View final(s,current,false);for(S i=0;i<n;++i)require(final.get(body+i)==model[i],"final model mismatch");check_list(old,n,12345,12345);
 // Abort must not modify committed backing bytes.
 {View aborted(s,current,true);aborted.put(body,123);}
 View after_abort(s,current,false);require(after_abort.get(body)==model[0],"abort changed committed data");
 // Physical repacking changes file offsets only; wire words are unchanged.
 Version repacked=current;for(S p=0;p<current.map.size();++p)if(current.map[p]>=0)repacked.map[p]=s.append(final.base+p*PS);
 View packed(s,repacked,false);require(std::memcmp(packed.base,final.base,final.bytes)==0,"repack changed wire bytes");
 std::cout<<"{\n  \"page_bytes\": "<<PS<<",\n  \"alias_relocation_dirty_pages\": "<<alias_dirty<<",\n  \"alias_relocation_payload_bytes_written\": "<<alias_written<<",\n  \"list_payload_bytes\": "<<n*8<<",\n  \"scalar_dirty_pages\": "<<scalar_dirty<<",\n  \"scalar_payload_bytes_written\": "<<scalar_written<<",\n  \"text_append_dirty_pages\": "<<text_dirty<<",\n  \"composite_append_dirty_pages\": "<<composite_dirty<<",\n  \"random_transactions\": 100,\n  \"random_edits\": "<<edits<<",\n  \"pinned_snapshots\": "<<pins.size()<<",\n  \"final_mapping_runs\": "<<final.runs<<",\n  \"repacked_mapping_runs\": "<<packed.runs<<",\n  \"snapshot_abort_repack_checks\": \"passed\"\n}\n";
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
