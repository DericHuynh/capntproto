# EAE v3: Rust implementation and reduced transaction latency

20 September 2026. The v1 and v2 reports remain in this package as historical design records.

**Outcome:** implemented the page-versioned core in Rust, removed repeated mapping/COW work from the warm writer path, added independent Cap’n Proto decoding tests, and measured a substantial reduction in warm transaction latency against a Rust reference path that uses v2's transaction strategy.

The result is an executable research crate, not a finished database. The implementation uses real mmap and file writes. Generation metadata remains in memory; no crash-safe persistent manifest, reopen protocol or physical page garbage collector is implemented.

## 1. The latency problem and the final fix

V2 rebuilt a writable segment mapping on every transaction, scanned all logical pages to find dirty ones, and wrote dirty pages individually. An initial Rust optimization retained the mapping but rebound every modified page to the newly written file offset on commit. This improved hot scalar edits but regressed on 32-page transactions.

The key correction is to **retain the writer's private page copies after commit**.

A committed snapshot maps immutable file pages at separate virtual addresses. It does not reference the writer's private memory. Once a page's bytes have been appended to the store, the writer can continue using its private copy for later transactions. Neither immediate remapping nor another COW fault is necessary for that hot page. A snapshot created earlier still sees its own immutable backing pages.

```text
begin:
    take the cached writable view, or build one on a cold start
    reuse empty dirty bitmap/vector storage

write(range):
    validate bounds
    skip identical small writes
    mark each affected page once
    change bytes in the private writer mapping

commit:
    sort the touched-page vector
    coalesce adjacent pages into bounded output batches
    append complete page images to immutable physical storage
    clone/update only changed page-table leaves and the root directory
    optionally flush payload bytes
    publish the new in-memory generation
    clear dirty markers, retain private writer pages for reuse

abort:
    restore touched pages from the old committed page map
    retain untouched private pages from earlier successful commits
    discard the whole private view if restoration fails
```

No reader sees the mutable writer mapping. The safe Rust API prevents a transaction byte slice from surviving mutation or commit. Two compile-fail doctests exercise those borrowing constraints.

On commit failure, the committed manifest remains unchanged. Any partially appended storage is orphaned and never reused in this prototype. A subsequent transaction reconstructs the old committed view if its cache was discarded. This is process-level exception safety, not crash recovery.

## 2. Implemented optimizations

| Change | Effect | Remaining cost |
|---|---|---|
| Retained private writer pages | Warm edits avoid remap syscalls and repeated COW faults | Private copies consume memory until trimmed/dropped |
| Bitmap plus reusable touched-page vector | Unique-page tracking; no full dirty-table scan | Sorting D touched pages costs O(D log D) |
| Adjacent-page batching | 32 adjacent dirty pages become one logical file-write call | Scattered pages still require separate batches |
| Shared table root and 256-entry COW leaves | Snapshot handles clone a root Arc; unchanged metadata is shared | Changed root directory and leaf arrays still allocate/copy |
| Identical-write suppression up to 64 bytes | No COW, dirty entry or I/O for unchanged small values | Reads/comparison; intentionally not applied to large buffers |
| Explicit cache maintenance | Bound a trim call by its requested page range | Trimming causes later faults; full cache release makes next begin cold |

The page table is two-level and bounded to a 256 MiB segment: at 4 KiB pages, the root has at most 256 entries and each leaf has 256 physical offsets. It is an in-memory structure, not the persistent page-map tree proposed in v2.

Output batching is capped at 256 pages (1 MiB) per `write_all_at` invocation. That caps one batch's size; it does not bound an entire transaction's latency. The standard Rust method handles short writes and interrupted calls. [Rust FileExt documentation](https://doc.rust-lang.org/std/os/unix/fs/trait.FileExt.html)

The writer cache has no automatic eviction pause. `trim_writer_cache(start_page, count)` remaps at most that many logical pages to their committed images. `release_writer_cache()` drops the full private view. Applications must schedule maintenance and impose their own memory/backpressure policy. The current prototype does not track an exact resident-private-byte budget.

## 3. Measured latency

The benchmark runs the same Rust engine in two modes:

- **Baseline:** rebuild mappings per transaction, scan the complete logical page table for dirty pages, write one page per logical output call, discard the writer mapping.
- **Optimized:** retain private writer memory, traverse only touched pages, batch adjacent writes and skip unchanged small values.

Both modes use the same shared in-memory page-table implementation, so this comparison does not separately measure its improvement over v2's flat vectors. The baseline is a controlled reference path, not stock Cap’n Proto and not a production database competitor.

Measurement: Rust 1.90.0, release build, 64-bit Linux, 4 KiB pages, shared host, one writer, 30 warm-up transactions and 400 measured transactions per case. A second run reversed the mode order to check for a simple ordering bias. Measured time includes begin, edits and commit. Reader-view opening, durable manifest publication and fsync are excluded. Temporary backing files use the host filesystem/page cache; these numbers are not device durability latency.

| Workload | Baseline p50 µs | Optimized p50 µs | Baseline p99 µs | Optimized p99 µs |
|---|---:|---:|---:|---:|
| Hot word, sparse 256 MiB segment | 229.9–237.1 | 7.0–7.1 | 417.9–486.2 | 9.3–59.4 |
| Hot word, fragmented 32 MiB segment | 1,156.0–1,174.2 | 3.0–3.1 | 2,115.4–2,396.6 | 5.2–18.2 |
| 32 adjacent modified pages | 668.8–677.9 | 26.5–37.6 | 2,733.4–2,776.6 | 89.5–356.2 |
| 32 scattered modified pages | 876.8–915.8 | 72.2–77.6 | 1,343.0–2,412.3 | 158.7–228.7 |

Each range spans the two runs, not a confidence interval. P99 is noisy on this host; the trend survives reversing the comparison order, but these observations are not a service-level guarantee.

The mechanism is visible in counters. Fragmented hot-word edits reduced mapping calls per transaction from 428 to zero. Adjacent 32-page edits reduced logical write calls from 32 to one. Optimized commits scanned zero untouched page-table entries. All modified-page cases wrote the same payload byte count in both modes: latency was reduced by removing overhead, not by silently omitting changed data or durability work from just one side.

An additional unchanged-value workload made no writes or mapping calls in optimized mode, with about 0.14 µs median local time. It should not be confused with a modifying transaction. An explicit payload-sync request still performs synchronization even for an otherwise empty transaction.

Opening a new immutable reader view is still O(logical pages + mapping runs) in this prototype. Retaining a writer view does not remove reader cold-open costs, storage fragmentation, or future durable-commit costs. No concurrent-reader throughput benchmark is claimed.

## 4. Rust verification

Final suite: **31 regression tests, six stock-reader integration tests and two compile-fail borrowing tests**. The runtime tests passed in debug and release profiles; the borrowing tests passed under rustdoc. Strict Clippy (`-D warnings`) and formatting checks are part of the supplied commands.

Regression coverage includes:

- Invalid segment sizes, checked bounds and arithmetic, empty reads and writes, signed near-pointer boundaries and invalid kinds.
- Dirty-page deduplication, cross-page writes, leaf boundaries, bounded output batching, no-op suppression and empty-transaction generation behavior.
- Old snapshots outliving the writer, concurrent immutable reader threads during commits, old Text terminators and coherent composite tags/lengths.
- Abort, panic unwind, restoring untouched previously committed private pages, cache release and bounded cache trimming.
- Whole-page UInt64 relocation, overlapping/occupied/out-of-bounds destinations, and rejection of pointer-bearing or partial-page lists.
- Injected failures before writes, after the first output batch, before publication and during payload synchronization; failed relocation rollback and successful subsequent transactions.
- Independent byte-vector comparison after every transaction across 12 seeds, 960 transactions and 23,040 attempted randomized writes, including scheduled aborts and fully compared retained snapshots.

The stock `capnp 0.21.7` reader independently checks struct/Text layouts, scalar-list page rebinding, a pointer list with a backward edge, composite-list versions, handcrafted single/double-far layouts across two segments, and rejection of an inconsistent composite tag. A stock-built struct is also canonicalized and compared with the mapped representation.

This closes part of v2's interoperability gap. It does **not** implement generic far-pointer editing, all schema evolution cases or a hardened importer. The handcrafted far-pointer tests demonstrate decoding compatibility of those mapped layouts, not a complete far-pointer allocator.

The `fault-injection` feature provides deterministic process-level failure points. It does not simulate torn sectors, OS crashes, disk exhaustion, or every possible short-write interleaving. Rust's standard positional write method handles short writes; our tests cover failures around complete batch operations.

## 5. Safety and operational limits

The implementation owns each mmap reservation and exposes only borrow-scoped slices. Mutable access requires a transaction. Immutable `View` values can be shared between reader threads because their backing pages never change; the backing file is private to the engine and kept alive by shared ownership. The small unsafe FFI layer has documented invariants. Passing tests and Clippy is not a formal proof of that unsafe code.

A raw transaction write can create an invalid Cap’n Proto message. The engine validates memory ranges, not application object ownership. `move_u64_list` verifies the supported layout and physical zero destination pages, but the caller must ensure the destination is not logically reserved by another object. A full allocator with durable ownership metadata is still required.

The physical store is append-only and the version table is process-local. There is no reopenable file, persistent root publication, page reclamation or bounded total file growth. `CommitOptions::sync_payload` flushes payload bytes only, including on an empty transaction. It cannot make the in-memory version table recoverable. Benchmarks use `sync_payload: false` for both modes.

Writer-private memory can grow with the working set. Explicit trimming bounds the requested maintenance range, but the prototype does not implement automatic cache sizing, background scheduling, or an overall memory budget. A cold transaction after dropping the cache still pays mapping and page-fault costs. Large transactions still incur large writes and metadata work.

No Miri, ThreadSanitizer, Loom model, persistent-storage crash testing or non-Linux ABI validation was run. Linux, 64-bit pointers and 4 KiB host pages are enforced. Rust 1.90 is the tested compiler; the core has no external runtime dependencies, while stock-reader tests use a pinned development dependency.

## 6. Files and reproduction

The current implementation is in `rust/`:

- `src/lib.rs`: mmap ownership, snapshot/page-table sharing, cached transactions, failure handling, scalar relocation and maintenance APIs.
- `src/bin/latency.rs`: controlled baseline/optimized benchmark with reversed-order option.
- `tests/regression.rs` and `tests/stock_reader.rs`: regression and independent compatibility tests.
- `Cargo.toml` and `Cargo.lock`: build configuration and pinned test dependencies.
- Test/Clippy logs and latency CSV files: captured execution evidence.

From that directory:

```sh
cargo test --all-features --locked
cargo test --release --all-features --locked
cargo clippy --all-targets --all-features --locked -- -D warnings
cargo fmt --check
cargo run --release --locked --bin latency
cargo run --release --locked --bin latency -- --reverse
```

The initial build downloads development dependencies; subsequent builds can use Cargo's offline cache. No external schema compiler is needed. V1/V2 C++/Python prototypes and their reports remain in the archive for comparison. Build outputs and the temporary toolchain are excluded from the deliverable.

**Current recommendation:** use the retained private writer cache and sparse dirty tracking as the transaction foundation. Keep snapshots on immutable physical pages. Add durable metadata publication and reclamation next, measure their p99 costs explicitly, and retain bounded cache maintenance instead of reinstating unconditional remapping on every commit.
