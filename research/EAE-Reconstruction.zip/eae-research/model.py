"""Executable, single-segment EAE specification; NOT a production runtime.
Python list-based free index intentionally favors auditability over speed.
Supported graph: root struct -> pointer lists -> one-word leaf structs.
Actual near-pointer wire words, reparenting, parent/list relocation, reusable
extents and permanent geometric reservations. No mmap, far pointers or RPC.
"""
import random, json, struct
from pathlib import Path
MASK=(1<<30)-1

def pointer(slot, target, kind, hi):
    off=target-slot-1
    if not -(1<<29)<=off<(1<<29): raise OverflowError(off)
    return (hi<<32)|((off&MASK)<<2)|kind

def target(slot,w):
    off=(w>>2)&MASK
    if off&(1<<29): off-=1<<30
    return slot+1+off

class Arena:
    def __init__(self, size=32768):
        self.w=[0]*size; self.free=[(1,size-1)]; self.o={}; self.next_id=1
        self.moved=0; self.copied=0
    def alloc(self,n):
        n=max(n,1)
        candidates=[(s,a,i) for i,(a,s) in enumerate(self.free) if s>=n]
        if not candidates: raise MemoryError()
        s,a,i=min(candidates)
        if s==n: self.free.pop(i)
        else: self.free[i]=(a+n,s-n)
        assert not any(self.w[a:a+n])
        return a
    def release(self,a,n):
        self.w[a:a+n]=[0]*n
        self.free.append((a,n)); self.free.sort()
        out=[]
        for a,n in self.free:
            if out and out[-1][0]+out[-1][1]==a:
                x,s=out[-1]; out[-1]=(x,s+n)
            else: out.append((a,n))
        self.free=out
    def slots(self,o):
        return range(o['a'],o['a']+o['n']) if o['kind'] in ('root','list') else ()
    def publish(self,i):
        o=self.o[i]; k=o['kind']; n=o['n']
        hi=(n<<16) if k=='root' else ((n<<3)|6) if k=='list' else 1
        self.w[o['owner']]=pointer(o['owner'],o['a'],1 if k=='list' else 0,hi)
    def create(self,kind,n,owner,value=0):
        cap=max(1,n); a=self.alloc(cap); i=self.next_id; self.next_id+=1
        self.o[i]=dict(a=a,n=n,cap=cap,owner=owner,kind=kind)
        if kind=='leaf': self.w[a]=value
        self.publish(i); return i
    def relocate(self,i,cap):
        o=self.o[i]; old=o['a']; oc=o['cap']; n=o['n']; new=self.alloc(cap)
        self.w[new:new+n]=self.w[old:old+n]
        by_address={v['a']:j for j,v in self.o.items()}
        for s in self.slots(o):
            w=self.w[s]
            if w:
                child=by_address[target(s,w)]; ns=new+s-old
                self.o[child]['owner']=ns
                self.w[ns]=pointer(ns,self.o[child]['a'],w&3,w>>32)
        o['a']=new; o['cap']=cap; self.publish(i)
        self.release(old,oc); self.moved+=1; self.copied+=n
    def ensure(self,i,n):
        o=self.o[i]
        if n<=o['cap']: return
        cap=max(n,2*o['cap']); end=o['a']+o['cap']; extra=cap-o['cap']
        for idx,(a,s) in enumerate(self.free):
            if a==end and s>=extra:
                if s==extra: self.free.pop(idx)
                else: self.free[idx]=(a+extra,s-extra)
                o['cap']=cap; return
        self.relocate(i,cap)
    def insert(self,i,idx,value):
        o=self.o[i]; assert 0<=idx<=o['n']; self.ensure(i,o['n']+1)
        a=o['a']; n=o['n']; by_addr={v['a']:j for j,v in self.o.items()}
        # Backward movement keeps each unread source intact.
        for s in range(a+n-1,a+idx-1,-1):
            w=self.w[s]
            if w:
                child=by_addr[target(s,w)]; self.o[child]['owner']=s+1
                self.w[s+1]=pointer(s+1,self.o[child]['a'],w&3,w>>32)
            else: self.w[s+1]=0
        self.w[a+idx]=0; o['n']+=1; self.publish(i)
        self.create('leaf',1,a+idx,value)
    def erase(self,i,idx):
        o=self.o[i]; a=o['a']; assert 0<=idx<o['n']
        by_addr={v['a']:j for j,v in self.o.items()}
        child=by_addr[target(a+idx,self.w[a+idx])]; c=self.o.pop(child)
        self.release(c['a'],c['cap'])
        for s in range(a+idx+1,a+o['n']):
            w=self.w[s]; child=by_addr[target(s,w)]; self.o[child]['owner']=s-1
            self.w[s-1]=pointer(s-1,self.o[child]['a'],w&3,w>>32)
        self.w[a+o['n']-1]=0; o['n']-=1; self.publish(i)
    def swap(self,i,j):
        # Swap two disjoint root children; two stores, exclusive operation.
        self.o[i]['owner'],self.o[j]['owner']=self.o[j]['owner'],self.o[i]['owner']
        self.publish(i); self.publish(j)
    def decode(self):
        # Read through wire words only, without consulting editor metadata.
        r=self.w[0]; a=target(0,r); result=[]
        for s in range(a,a+(r>>48)):
            p=self.w[s]; b=target(s,p); n=p>>35; values=[]
            assert p&3==1 and ((p>>32)&7)==6
            for q in range(b,b+n):
                leaf=self.w[q]; assert leaf&3==0 and leaf>>32==1
                values.append(self.w[target(q,leaf)])
            result.append(values)
        return result
    def check(self):
        occupied={0}; slots={0}
        for i,o in self.o.items():
            a=o['a']; n=o['n']; cap=o['cap']
            assert 0<=n<=cap and 0<a and a+cap<=len(self.w)
            extent=set(range(a,a+cap)); assert not occupied&extent; occupied|=extent
            assert not any(self.w[a+n:a+cap]); slots.update(self.slots(o))
            assert target(o['owner'],self.w[o['owner']])==a
        owners=[o['owner'] for o in self.o.values()]
        assert len(set(owners))==len(owners) and set(owners)<=slots
        for a,n in self.free:
            extent=set(range(a,a+n)); assert not occupied&extent; occupied|=extent
            assert not any(self.w[a:a+n])
        assert len(occupied)==len(self.w)
    def export(self,path):
        Path(path).write_bytes(struct.pack('<II',0,len(self.w))+struct.pack('<'+'Q'*len(self.w),*self.w))

def counterexamples():
    # Reader caches old pointer length, writer expands both words, reader reads new tag.
    old_words=4; new_count=5; stride=1
    assert new_count*stride>old_words
    # Append overwrites the old Text terminator, even if its pointer is unchanged.
    text=bytearray(b'ab\0\0'); old_size=3; text[2]=ord('c')
    assert text[old_size-1]!=0
    # Constant slack + adversarial reservation stealing yields quadratic copying.
    n=10000
    return dict(composite_mixed_version_rejected=True,old_text_terminator_destroyed=True,
                stolen_reservation_copy_words=n*(n-1)//2,
                old_root_sees_changed_child='root identity alone cannot freeze descendants')

def run():
    edits=0; moves=0; copies=0
    for seed in range(30):
        rng=random.Random(seed); a=Arena(8192); root=a.create('root',8,0)
        ids=[a.create('list',0,a.o[root]['a']+k) for k in range(8)]; model=[[] for _ in ids]
        for step in range(1000):
            k=rng.randrange(8); op=rng.randrange(6)
            if op<3 and len(model[k])<32:
                at=rng.randrange(len(model[k])+1); value=rng.randrange(1<<32)
                a.insert(ids[k],at,value); model[k].insert(at,value)
            elif op==3 and model[k]:
                at=rng.randrange(len(model[k])); a.erase(ids[k],at); model[k].pop(at)
            elif op==4:
                j=rng.randrange(8); a.swap(ids[k],ids[j]); ids[k],ids[j]=ids[j],ids[k]; model[k],model[j]=model[j],model[k]
            else:
                i=root if rng.randrange(2) else ids[k]; a.relocate(i,a.o[i]['cap'])
            a.check(); assert a.decode()==model; edits+=1
        moves+=a.moved; copies+=a.copied
        if seed==0: a.export(Path(__file__).with_name('sample.capnp.bin'))
    # Boundary arithmetic without allocating multi-gigabyte buffers.
    for off in (-(1<<29),-1,0,(1<<29)-1):
        s=1<<30; t=s+1+off; assert target(s,pointer(s,t,0,1))==t
    for off in (-(1<<29)-1,1<<29):
        try: pointer(1,2+off,0,1)
        except OverflowError: pass
        else: raise AssertionError('overflow accepted')
    result=dict(seeds=30,operations_checked=edits,relocations=moves,words_copied=copies,
                near_offset_boundaries='passed',counterexamples=counterexamples())
    print(json.dumps(result,indent=2))
if __name__=='__main__': run()
