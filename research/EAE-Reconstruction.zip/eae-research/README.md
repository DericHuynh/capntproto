# EAE v7 research package

Current report: EAE-Research-and-Reconstruction.md.
Current Rust implementation and 110 executed test cases: rust/.
Frozen pre-optimization library: baselines/v6/.

V7 pools transaction memory, reduces recovery reads/copies and shares still-live same-generation snapshots. Disk format and durability protocol remain unchanged. Fresh snapshots still copy the arena; pooled scratch has an explicit release API.

The paired benchmark uses one harness against both versions, five trials across six workloads in buffered and sync-per-commit modes. All 120 runs, including regressions, are in rust/arena-perf-results.csv. Reproduction and compatibility instructions are in rust/README.md. The storage-layer boundary and assumptions are in rust/STORAGE-CONTRACT.md.

Historical v1–v6 reports and measurements remain. This is a research storage adapter, not a production-qualified database. Container fsync measurements do not establish physical-media durability latency.

Storage-efficiency study: EAE-Storage-Efficiency.md. The new benchmark covers 270 runs across capacity, occupancy, update shape and checkpoint cadence, with logical/allocated space and full write accounting. Source and results are in rust/.
