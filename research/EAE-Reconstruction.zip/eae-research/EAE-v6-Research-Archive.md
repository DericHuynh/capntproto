# EAE v6: a recoverable Cap’n Proto segment arena

20 September 2026. Rust crate 0.6.0. The earlier v1–v5 designs and results remain in the package.

**Implemented:** an optional `durable::Arena` adapter around mutable, mmap-backed segment bytes. It adds persistent files, transactions spanning multiple segments, durable commit acknowledgements, checksummed recovery, exclusive writer locking, detached immutable snapshots, atomic checkpoints, log reclamation, and resource limits. The ordinary serialization/reader path acquires no database dependency.

This is a tested storage-layer prototype, not a production database or a claim of exhaustive crash correctness. The new guarantees apply to `durable::Arena`; the previous `Engine` and `DeltaEngine` remain experimental temporary-file implementations.

## Layer boundary

| Responsibility | Owner |
|---|---|
| Cap’n Proto wire encoding, typed readers/builders, pointer interpretation | Cap’n Proto runtime/generated code |
| Stable segment IDs, byte ranges, transaction isolation, durable publication, recovery | This optional arena adapter |
| Object allocation/reuse, root layout, schema-specific invariants | Builder/allocator integration using arena transactions |
| Record identity, indexes, queries, constraints, authorization, distributed transactions, replication | Database above the arena |

The adapter supports up to 64 fixed-size segments, each a nonzero multiple of eight bytes, within a configurable total capacity (hard ceiling 256 MiB). It exposes borrowed segment slices directly to a normal Cap’n Proto `SegmentArray`. Segment-relative pointers and far pointers retain their wire meaning. The persistent container includes its own recovery metadata and is **not** a stock Cap’n Proto framed message. [Cap’n Proto encoding specification](https://capnproto.org/encoding.html)

No SQL, key/value API, object identity scheme or consensus algorithm was added. A database can update records and its own index bytes in one transaction if they reside in the same arena. Atomicity across separate arenas requires a higher-layer protocol.

## Guarantees and their scope

| Added behavior | Contract |
|---|---|
| Atomic multi-segment commit | Recovery validates the complete record before applying any of its ranges; accepts all ranges or none. Borrowed live reads cannot overlap mutation in safe Rust. |
| Durable acknowledgement | `Durability::Durable` synchronizes the data file before returning success. `Durability::default()` is Durable; callers explicitly select a mode at commit. |
| Explicit buffered mode | `Buffered` publishes process-visible state; `durable_through` records the last confirmed durable generation. `flush()`, a later durable commit, or a successful checkpoint makes the prefix durable. |
| Error outcomes | Pre-I/O rejection returns `Rejected` and restores memory. An error once commit I/O starts returns `Unknown` and poisons the handle; reopen before using it again. A fully written but unacknowledged record may recover as committed. |
| Recovery | Validates version, schema identifier, layout, checksums, bounds, record ordering and generation continuity; replays complete transactions. Truncates an incomplete EOF record and syncs the retained prefix. |
| Corruption handling | Complete malformed/checksum-invalid records fail open rather than silently rolling back to an older state. CRC32C detects accidental errors probabilistically; it is not authentication or repair. |
| Writer exclusion | Nonblocking advisory `flock` on a stable sidecar lock, held for the lifetime of the arena handle, including across checkpoint replacement. Cooperating writers cannot open the same directory concurrently. |
| Immutable snapshots | Copies the current arena into a detached mapping; clones share it. It remains readable across commits, checkpoints, engine drop and threads. Snapshot creation is O(arena bytes). |
| Checkpoint/reclamation | Writes and syncs a complete replacement image, renames it over DATA, then syncs the directory. On success, old redo history is reclaimed and reopen needs no earlier redo. Existing detached snapshots are independent. |
| Bounded work | Limits for segment capacity, transaction undo bytes, record bytes and log growth. A full log rejects new writes before I/O; callers schedule checkpointing explicitly. |
| Schema/invariant hooks | Caller-selected schema ID is persisted and checked at open. `commit_checked` runs a caller validator before log I/O; rejection rolls back the transaction. |
| Stale updates | `begin_at(generation)` rejects a stale arena generation, useful when updating from a detached snapshot. |
| Aborts and leaked transactions | Drop/unwind restores overlapping undo ranges in reverse order. A deliberately forgotten transaction leaves the arena unavailable until reopened, preventing accidental publication of its partial memory state. |

These contracts assume a trusted, dedicated directory on a local Linux filesystem that honors synchronization, atomic same-directory rename, and writes that do not damage unrelated file bytes. Do not delete/replace LOCK, externally mutate DATA, or use the same arena in both branches of a manual fork. Network filesystems and malicious concurrent access are outside the contract. Like other storage engines, software cannot compensate for a device falsely acknowledging persistence. [Linux flock](https://man7.org/linux/man-pages/man2/flock.2.html), [SQLite storage assumptions](https://www.sqlite.org/atomiccommit.html)

The lock is explicitly released before descriptor close so a transient fork-inherited descriptor during process spawning cannot unexpectedly extend the lock lifetime. Child-process tests exposed this case during development.

## Commit and recovery design

The working image is an anonymous mmap. Open eagerly loads the checkpoint and replays redo into that mapping; this is not a zero-copy file-backed open. Subsequent Cap’n Proto reads borrow the loaded bytes without deserialization. Transactions modify exact byte ranges in place and retain old bytes for abort. Committing sorts and merges overlapping/adjacent ranges, serializes their final contents, appends a framed redo record, and synchronizes it when requested. Only then does the API publish the new generation.

Each record contains:

- A 48-byte header: magic, complete record length, generation, range count, CRC32C of the body, and CRC32C of the header fields.
- A 16-byte `(logical offset, length)` descriptor per merged range, followed by that range’s payload.
- A 16-byte final marker containing commit magic and generation.

All integer fields are explicitly little-endian. Payload length is not rounded to a page. CRC32C uses runtime-detected SSE4.2 on x86-64 with a portable table-based fallback; both implementations are tested against the known vector and each other on unaligned lengths.

Recovery reads the checkpoint, verifies its full-image checksum, then scans redo in order. It first validates each complete record and every descriptor, then applies the record. It does not search past corruption or guess a replacement state. A valid header followed by insufficient EOF bytes, or an EOF shorter than a header, is treated as an interrupted append. A fully sized but torn/checksum-invalid record fails closed; automatic recovery is deliberately conservative.

A valid record may survive without an acknowledgement. Conversely, the file format cannot detect removal of an entire valid suffix by an external actor without a separately trusted watermark. The database above this layer should store any request-deduplication or consensus position inside the same transaction if needed.

## Checkpoint and space behavior

Each arena is a dedicated directory containing `DATA`, persistent `LOCK`, and a temporary `PENDING` during replacement. DATA begins with a 4096-byte checksummed format header and a complete segment image, followed by redo records. The header stores layout, schema identifier, checkpoint generation and image checksum.

Checkpoint sequence: write PENDING → sync PENDING → rename PENDING to DATA → sync the arena directory → switch the writer handle. Creation also synchronizes the parent directory. File synchronization alone does not establish durability of the renamed directory entry. [Linux fsync documentation](https://man7.org/linux/man-pages/man2/fsync.2.html)

On interruption, DATA refers to either the old checkpoint plus redo, or the new complete checkpoint. Successful reopen removes an unused PENDING file under the lock. A checkpoint failure poisons the handle until reopen; no subsequent writes target an uncertain file generation.

This reclaims log history but does not compact or move logical Cap’n Proto objects. Segment sizes are fixed. The builder/allocator must manage object reuse and zeroing through transactions. No persistent historical-version catalogue is retained after checkpointing; snapshots retained by the process are detached byte copies.

## Write amplification: full accounting

| Transaction | Application payload | Redo record bytes | Record/application |
|---|---:|---:|---:|
| One 8-byte field | 8 | 88 | 11× |
| 32 separate 8-byte fields | 256 | 832 | 3.25× |
| One 4 KiB range | 4096 | 4176 | 1.019531× |

Payload amplification remains **1× for these submitted ranges**, rather than page rounding. Framing/integrity metadata and checkpoints still consume bytes. Overlapping submitted ranges are merged; there is no full byte-level diff, so submitting a whole page still logs that page and change-then-revert writes may still generate a record.

In the benchmark’s deliberately frequent checkpoint schedule, a 256 KiB arena produces a 266,240-byte checkpoint including its header. Total submitted file bytes over the measured interval, including one final checkpoint, are **44.28×** application bytes for 1000 single-word commits, **4.29×** for 1000 scattered-word commits, and **1.279531×** for 250 full-4-KiB commits. Initial creation/warm-up is excluded from those interval ratios. Filesystem metadata, journal and physical-device amplification are not measured.

Thus this design avoids per-update page rewrites but does not claim zero total amplification. Checkpoint cadence should be chosen by the database according to recovery and write budgets. This implementation uses explicit checkpoints and a hard redo budget, without hidden checkpoint pauses inside ordinary commits.

## Measurements with the new guarantees

Intel Xeon Platinum 8370C, Linux container on overlayfs, three trials with alternating mode order. Decimal MB/s; reported numbers are medians of trial throughputs. Warm-up: 10 transactions followed by a checkpoint. Arena: 256 KiB. Input generation, snapshot copying and reopen are outside commit timing.

| Workload | Buffered MB/s | Sync-per-commit MB/s | Sync p50 µs | Sync MB/s including final checkpoint |
|---|---:|---:|---:|---:|
| One 8-byte field, 1000 commits | 9.104 | 7.814 | 0.917 | 6.356 |
| 32 scattered fields, 1000 commits | 65.925 | 64.616 | 3.419 | 59.903 |
| One 4 KiB range, 250 commits | 1141.270 | 1084.870 | 3.436 | 792.994 |

The sync-per-commit measurements execute `sync_all()` for every transaction. **The roughly microsecond timings reflect this container, not demonstrated physical-media persistence latency. Do not use them to predict production SSD fsync performance.** The intended syscall ordering is tested; actual power-loss durability must be validated on the target storage stack.

Median final checkpoints took about 0.21–0.32 ms across the sync cases. Detached 256 KiB snapshots took about 1.08–1.15 ms; reopening a checkpointed arena took about 1.17–1.21 ms. These are short, shared-host measurements with no confidence interval. The raw CSV retains all trials. Unlike v5, snapshot creation copies current state instead of replaying unbounded history.

The initial portable-checksum experiment is retained in `durable-throughput-software-crc.csv`. Hardware CRC32C materially reduced checksum overhead, especially for 4 KiB ranges. No claim is made that the new durable path is faster than the previous, weaker v5 path across all workloads.

## Tests and evidence

**106 executed cases pass in debug and release** with all features. Strict Clippy and formatting checks pass. This includes the existing 86 cases and 20 added cases: 15 arena integration/harness cases, 4 checksum/parser cases and 1 compile-fail borrowing test. The child worker is a harness entry; it is exercised by parent tests and is not an independent storage scenario.

New evidence includes:

- Durable reopen across two segments; byte/metadata accounting; buffered durability watermarks, explicit flush and empty durable commit.
- Overlapping abort, unwind and validator rejection; bounds, budgets, stale-generation rejection and forgotten-transaction detection.
- Detached snapshots surviving checkpoint, engine drop and cross-thread reads; checkpoint truncation and generation preservation.
- Every byte cut of the final 112-byte two-range transaction; a prior committed transaction remains unchanged until the final record is complete.
- Corruption of checkpoint/header/body/footer fields fails closed without mutating the corrupted file. Valid checksums do not bypass descriptor/sequence/resource checks.
- Child-process termination before commit, during partial append, after append, after sync, before checkpoint rename, after rename and after directory sync; reopening checks both segment values together.
- Injected ordinary errors at append/publication/checkpoint boundaries, poisoned-handle rejection and reopen behavior.
- OS writer exclusion in the same process and a child; randomized checkpoint/reopen/abort comparison over 1920 writes; independent stock Cap’n Proto far-pointer decoding across persisted segments.

This is not exhaustive fault enumeration, real power-cut testing, filesystem write-reordering simulation, fuzzing, Miri, or a race-detector result. The implementation should undergo those checks and external review before holding irreplaceable production data.

## Use and reproduce

New API: `rust/src/durable.rs`. Runnable example: `rust/examples/durable_arena.rs`. Full boundary and format reference: `rust/STORAGE-CONTRACT.md`.

```sh
cd rust
cargo test --all-features --locked
cargo test --release --all-features --locked
cargo clippy --all-targets --all-features --locked -- -D warnings
cargo fmt --check
cargo run --example durable_arena -- /tmp/new-arena-directory
cargo run --release --locked --bin durable_throughput > durable-throughput-results.csv
python3 summarize_durable.py
```

The example refuses an existing directory. Read operations return ordinary Cap’n Proto segment bytes. Application state and any application-level invariant metadata must be updated together inside the same arena transaction. The adapter does not automatically traverse the complete pointer graph, enforce a schema, forbid capability pointers, or migrate objects; a builder or validator must supply those policies with bounded traversal.
