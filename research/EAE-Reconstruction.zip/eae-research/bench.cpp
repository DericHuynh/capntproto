// Native allocator/list-growth experiment. Not a Cap'n Proto implementation.
// Fixed backing arena avoids measuring vector reallocation of the arena itself.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <map>
#include <random>
#include <stdexcept>
#include <vector>
using U=uint64_t; using S=size_t;
struct Heap {
 std::vector<U> w; std::map<S,S> address; std::multimap<S,S> sizes;
 S copied=0,zeroed=0,moves=0,high=0;
 Heap(S n):w(n,0){add(0,n);}
 void add(S a,S n){address[a]=n;sizes.emplace(n,a);}
 void remove(S a){S n=address.at(a);auto [b,e]=sizes.equal_range(n);for(;b!=e;++b)if(b->second==a){sizes.erase(b);break;}address.erase(a);}
 S alloc(S n){auto it=sizes.lower_bound(n);if(it==sizes.end())throw std::bad_alloc();S a=it->second,s=it->first;remove(a);if(s>n)add(a+n,s-n);high=std::max(high,a+n);return a;}
 void free(S a,S n){std::fill(w.begin()+a,w.begin()+a+n,0);zeroed+=n;auto it=address.lower_bound(a);if(it!=address.end()&&a+n==it->first){S x=it->first,s=it->second;remove(x);n+=s;}it=address.lower_bound(a);if(it!=address.begin()){--it;if(it->first+it->second==a){S x=it->first,s=it->second;remove(x);a=x;n+=s;}}add(a,n);}
 bool extend(S end,S extra){auto it=address.find(end);if(it==address.end()||it->second<extra)return false;S s=it->second;remove(end);if(s>extra)add(end+extra,s-extra);high=std::max(high,end+extra);return true;}
};
struct List {S a=0,n=0,cap=0;};
void append(Heap& h,List& l,U value,bool adjacent=true){
 if(l.n==l.cap){S cap=std::max(S(1),l.cap*2);if(l.cap&&adjacent&&h.extend(l.a+l.cap,cap-l.cap))l.cap=cap;
 else {S a=h.alloc(cap);if(l.n){std::memcpy(&h.w[a],&h.w[l.a],l.n*8);h.copied+=l.n;}if(l.cap)h.free(l.a,l.cap);l.a=a;l.cap=cap;h.moves++;}}
 h.w[l.a+l.n++]=value;
}
volatile U sink=0;
int main(){
 std::cout<<"workload,n,median_ms,copied_words,zeroed_words,allocations_or_moves,arena_high_words\n";
 for(auto mode:{0,1,2,3}){
  S n=mode==3?20000:1000000;std::vector<double> times;S copied=0,zeroed=0,moves=0,high=0;
  for(int rep=0;rep<7;++rep){
   Heap h(8*1024*1024);std::vector<List> ls(mode==1?64:1);std::vector<U> baseline; if(mode==2)baseline.reserve(n);
   auto start=std::chrono::steady_clock::now();
   if(mode==2){for(S i=0;i<n;++i)baseline.push_back(i);sink=baseline[n-1];}
   else if(mode==3){List l;for(S i=0;i<n;++i){S a=h.alloc(i+1);if(i){std::memcpy(&h.w[a],&h.w[l.a],i*8);h.copied+=i;h.free(l.a,i);}l={a,i+1,i+1};h.w[a+i]=i;h.moves++;}sink=h.w[l.a+l.n-1];}
   else {for(S i=0;i<n;++i)append(h,ls[i%ls.size()],i);U check=0;for(S j=0;j<ls.size();++j){auto l=ls[j];for(S k=0;k<l.n;++k){U want=k*ls.size()+j;if(h.w[l.a+k]!=want)throw std::runtime_error("bad contents");check+=want;}}sink=check;}
   auto stop=std::chrono::steady_clock::now();times.push_back(std::chrono::duration<double,std::milli>(stop-start).count());
   copied=h.copied;zeroed=h.zeroed;moves=h.moves;high=h.high;
  }
  std::sort(times.begin(),times.end());
  const char* names[]={"eae_single","eae_interleaved64","std_vector_reserved","exact_relocate_each_append"};
  std::cout<<names[mode]<<','<<n<<','<<times[3]<<','<<copied<<','<<zeroed<<','<<moves<<','<<high<<'\n';
 }
}
