# EAE v7: measured durable-arena performance improvements

20 September 2026. Rust 0.7.0. Persistent disk format remains version 1 and is byte-compatible with v6. The frozen v6 library is included alongside the current code for reproducible comparison.

**Implemented and measured:** pooled transaction buffers, conditional range sorting, a validator-free ordinary commit path, direct checkpoint loading into mmap, buffered redo recovery, and sharing of still-live snapshots from an unchanged generation. Atomicity, checksum checks, lock behavior, durable acknowledgement ordering, and checkpoint publication remain unchanged.

The most consistent gains are scattered edits and reopening. Bulk-write throughput is largely unchanged, and two buffered workload medians regress. The results below include those regressions and every trial.

## What changed

| Change | Work removed | Constraint retained |
|---|---|---|
| Pooled undo bytes and descriptors | A fresh payload allocation per write and repeated descriptor allocation | Undo ranges retain mutation order and roll back in reverse order |
| Reused range scratch; skip sorting ordered input | Per-commit range allocation and unnecessary sorting | Reverse/unsorted writes still sort and merge correctly |
| Separate ordinary commit implementation | Constructing a segment-slice vector for a no-op validator | `commit_checked` still validates before file I/O |
| Direct checkpoint read into the new anonymous mmap | A full temporary image allocation, initialization and copy | Checksum validation finishes before the arena is exposed |
| 64 KiB buffered redo reader; reusable descriptor scratch | Two positional reads per small record, duplicate header reads and per-record descriptor allocations | Entire record validates before any range is applied |
| Weak snapshot cache | Repeated full-arena copies while a snapshot of the same generation remains alive | Fresh snapshots still copy; successful nonempty commits invalidate the cache |

Transaction buffers now retain their high-water capacity. `scratch_bytes()` reports retained scratch capacity; `release_scratch()` explicitly releases it between transactions. This trades allocation churn for retained memory, without changing data. The weak snapshot cache does not keep a mapping alive after its last snapshot handle drops. A newly returned cached snapshot gets the current durability watermark even if an older handle was created before a flush.

## Controlled comparison

Both versions use the same `arena_perf.rs` benchmark source, the same release profile, Rust 1.90, and the same inputs. The v6 library sources and lockfile were frozen before editing. Final runs alternate v6/v7 ordering across **five trials for each of six workloads and two commit modes: 120 process runs**. Preliminary baseline measurements are saved separately and are not mixed into final medians.

Environment: Intel Xeon Platinum 8370C, 64-bit Linux, 4 KiB host pages, overlayfs container. Measurements are warm, short, shared-host microbenchmarks. The unusually fast `sync_all()` calls in this environment do **not** establish real SSD durability latency or hardware power-loss behavior.

- Each case uses an 8 MiB segment and 20 warm-up transactions, followed by a checkpoint outside measured commit time.
- Transactions per trial: 5000 single-word, 2000 scattered/reverse-word, 2000 4 KiB, 500 64 KiB, or 80 1 MiB.
- Scattered offsets are two pages apart. Reverse-order work writes the same locations in descending order.
- Commit timing includes begin, writes, undo, sorting/merging, CRC32C, file output, requested sync, publication and transaction cleanup. Input generation and validation are excluded.
- MB means 1,000,000 bytes. Application throughput is submitted application bytes divided by summed measured commit seconds. It is not computed from p50.
- Table entries are medians of five per-trial results; percentiles are medians of per-trial percentiles. No outlier is discarded and no confidence interval is claimed.
- Snapshots, replay, clean reopen and checkpoint are timed separately. Full-image comparisons after opening check changed bytes and unchanged holes. Benchmark/test compilation and test execution did not run concurrently with the final benchmark.

## Application throughput: MB/s

| Workload | Buffered v6 | Buffered v7 | Sync-per-commit v6 | Sync-per-commit v7 |
|---|---:|---:|---:|---:|
| One 8-byte field | 8.971 | 7.968 | 7.539 | 8.271 |
| 32 scattered 8-byte fields | 68.756 | 110.904 | 71.467 | 105.226 |
| Same 32 fields, reverse order | 72.261 | 106.124 | 72.605 | 98.259 |
| One 4 KiB range | 980.966 | 998.683 | 864.521 | 948.688 |
| One 64 KiB range | 1,610.260 | 1,713.784 | 1,617.865 | 1,643.365 |
| One 1 MiB range | 1,548.507 | 1,441.178 | 1,552.740 | 1,551.947 |

Scattered fields improve **1.61× buffered and 1.47× with sync requested per commit**. Reverse-order scattered fields improve **1.47× and 1.35×** respectively, so the benefit is not restricted to already sorted writes.

Single-word buffered throughput falls **11.2%**, despite lower typical latency; buffered 1 MiB throughput falls **6.9%**. Single-word buffered trial ranges overlap: v6 7.325–9.358 MB/s, v7 6.740–10.533 MB/s. Tail/outlier effects matter, and a lower p50 alone does not establish higher total throughput. Large contiguous workloads show no broad, reliable speedup. The implementation should be selected for its measured scattered-edit/recovery gains, not a claim that every write is faster.

## Sync-per-commit latency

These runs actually call `sync_all()` per transaction. Their physical-storage interpretation is limited by the container environment described above.

| Workload | v6 p50 µs | v7 p50 µs | v6 p99 µs | v7 p99 µs |
|---|---:|---:|---:|---:|
| One 8-byte field | 0.950 | 0.804 | 3.342 | 3.209 |
| 32 scattered 8-byte fields | 2.793 | 1.842 | 7.835 | 6.213 |
| Same 32 fields, reverse order | 2.890 | 1.934 | 7.110 | 6.233 |
| One 4 KiB range | 3.906 | 3.784 | 19.230 | 8.640 |
| One 64 KiB range | 35.887 | 35.399 | 139.147 | 162.501 |
| One 1 MiB range | 659.303 | 638.733 | 1097.490 | 1059.122 |

## Reopening and snapshots

Reopen includes checksum validation, replay and the existing recovery synchronization. These are warm-cache reopen measurements, not cold-storage startup bandwidth. Results below use the sync-per-commit cases.

| Workload history | v6 reopen with redo, ms | v7 reopen with redo, ms | v6 clean reopen, ms | v7 clean reopen, ms |
|---|---:|---:|---:|---:|
| One 8-byte field | 81.360 | 37.198 | 74.830 | 36.299 |
| 32 scattered 8-byte fields | 78.616 | 38.146 | 75.888 | 35.680 |
| Same 32 fields, reverse order | 79.251 | 38.917 | 74.983 | 35.948 |
| One 4 KiB range | 81.448 | 44.163 | 71.822 | 36.488 |
| One 64 KiB range | 90.782 | 51.784 | 74.391 | 36.771 |
| One 1 MiB range | 109.178 | 74.907 | 69.469 | 36.633 |

Opening after 2000 scattered-word transactions falls from **78.62 ms to 38.15 ms (2.06× faster)**. After 80 full 1 MiB transactions it falls from **109.18 ms to 74.91 ms (1.46× faster)**. This measures the combined direct-load and buffered-replay changes; no separate attribution experiment was performed.

A fresh 8 MiB snapshot still costs roughly **38–44 ms** in the v7 sync cases. No first-snapshot acceleration is claimed. Keeping one snapshot pinned and requesting another of the same generation changes the repeated operation from another roughly 40 ms full copy to roughly **0.05 µs** of sharing. That number is the mean time for a 32-call loop within each trial, then the median across trials; it is not the latency of allocating/copying a new 8 MiB snapshot. Dropping the last handle or committing a changed generation removes this benefit for the next fresh snapshot.

## Checkpoints and write amplification

No record format, per-record byte count, checkpoint cadence or durability barrier was removed to obtain these gains. Output remains 88 bytes for one 8-byte field, 832 for 32 separate fields, and application range length plus 80 bytes for each single contiguous range.

A final 8 MiB checkpoint writes 8,392,704 bytes, including its header. The table below accounts for the measured commits plus one final checkpoint; initial creation and warm-up are excluded. Filesystem metadata, journaling and device-level write amplification are not measured.

| Workload | Total file bytes / application bytes, including checkpoint | v6 sync MB/s including checkpoint | v7 sync MB/s including checkpoint |
|---|---:|---:|---:|
| One 8-byte field | 220.817600× | 3.937 | 4.287 |
| 32 scattered 8-byte fields | 19.642000× | 22.230 | 54.728 |
| Same 32 fields, reverse order | 19.642000× | 40.902 | 53.083 |
| One 4 KiB range | 2.044031× | 516.745 | 565.758 |
| One 64 KiB range | 1.257346× | 973.956 | 1171.795 |
| One 1 MiB range | 1.100125× | 1039.138 | 1248.352 |

“MB/s including checkpoint” divides application bytes by commit time plus separately measured checkpoint time. It excludes intervening snapshot, validation and reopen time, so it is not end-to-end workload throughput. The checkpoint is measured after redo reopen. Checkpoint latency is particularly noisy; checkpoint code was not changed, so apparent checkpoint speedups are not attributed to a new checkpoint algorithm. Exact checkpoint timings and throughput ranges are retained in the CSV/JSON.

Frequent checkpoints of a mostly untouched large arena can dominate total bytes, especially for single-word workloads. V7 improves CPU/allocation/recovery work, not this amplification. Explicit checkpoint scheduling and arena sizing remain higher-layer decisions.

## Correctness, compatibility and limits

**110 executed cases pass in debug and release** with all features; strict Clippy and formatting checks pass. Four new integration cases cover:

1. Cached snapshot pointer sharing, generation isolation, abort behavior and independently advancing durability watermarks.
2. Scratch release preserving state, old snapshots, later abort and reopen.
3. Repeated pooled-undo reuse across validation rejection and overlapping commits.
4. Recovery across 64 KiB buffer boundaries and a record larger than the recovery buffer.

The prior cases still exercise process termination, partial appends, checkpoint publication, byte-by-byte truncation, corruption, locking, resource limits and independent Cap’n Proto decoding. A separate cross-version fixture is written by each version and opened by the other. The resulting checkpoint-plus-redo files are byte-for-byte identical.

The persistent adapter remains a local, cooperating single-writer design with fixed segment capacities and anonymous working mappings. Typed object allocation, full graph validation, indexes, distributed transactions and replication are outside this adapter. Real power-loss testing, cold-storage benchmarking, Miri/fuzzing and production qualification remain outstanding. See `rust/STORAGE-CONTRACT.md` for the complete persistence contract and `EAE-v6-Research-Archive.md` for its introduction.

## Reproduce

From the extracted package’s `rust` directory:

```sh
cargo build --release --locked --bins
cargo build --release --locked --manifest-path ../baselines/v6/Cargo.toml --bins
python3 run_arena_perf.py --trials 5
python3 check_arena_compat.py
cargo test --all-features --locked
cargo test --release --all-features --locked
cargo clippy --all-targets --all-features --locked -- -D warnings
cargo fmt --check
```

Run the benchmark without simultaneous builds/tests for comparable measurements. `arena-perf-results.csv` contains all 120 final runs; `arena-perf-results-summary.json` contains medians and throughput ranges. `arena-perf-baseline.csv` is the preliminary one-trial baseline only. The runner derives summaries directly from its own output and performs no outlier removal. Legacy v6 and earlier results remain under their original filenames.

## Additional storage-efficiency benchmark

A separate 270-run storage study is included in `EAE-Storage-Efficiency.md`. It measures redo bytes, checkpoint writes, retained history, live-data occupancy, filesystem allocation and modeled checkpoint coexistence space. Source and raw data are `rust/src/bin/storage_efficiency.rs` and `rust/storage-efficiency-results.csv`.

The study confirms that adjacent 32-field updates emit 336 log bytes versus 832 for spread-out fields. It also exposes the larger fixed-capacity cost: an 8 MiB arena containing only 128 KiB of live bytes still occupies 8,392,704 file bytes after checkpointing, or 64.03125× live data. No engine behavior was changed for this benchmark.
