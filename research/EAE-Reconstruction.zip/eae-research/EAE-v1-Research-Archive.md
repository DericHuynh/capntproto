# Elastic Arena Editing: researched reconstruction

20 September 2026

**Verdict:** reusable allocation and local relocation are viable for an exclusively edited Cap’n Proto message. The supplied proposal is not a correct snapshot or crash-consistency algorithm. Its performance claim becomes defensible only with retained capacity, bounded allocation work, and explicit limits on what an append promises. Implement the exclusive editor first; add a separately specified transaction layer.

This report reconstructs the design and supplies an executable wire-word model, randomized model comparisons, native allocator experiments, and reproducible counterexamples. It does **not** claim a production implementation, full wire-format conformance, stock-reader interoperability, or validated power-loss safety.

## 1. Wire-format facts that constrain the design

The encoding specification establishes the following: near offsets are signed 30-bit word offsets; far landing-pad offsets are unsigned 29-bit word offsets; composite lists have a separate tag; `Text` includes a terminating zero; capability pointers refer to an external table. Stream framing and mmap framing need not be identical. Canonicalization additionally removes trailing default words. [Encoding specification](https://capnproto.org/encoding.html)

Consequences for this design:

- Near-pointer reach is **−4 GiB through +4 GiB−8 bytes**, relative to the pointer end, not ±8 GiB. The draft confuses total span with reach in each direction.
- A 32-bit framing field alone is not a justification for a freely addressable 32 GiB segment. Far pointers cannot directly name an arbitrary landing pad anywhere in such a segment. Use deliberately bounded segments; a proposed conservative limit is 256 MiB, subject to runtime interoperability testing.
- Track landing pads as owned allocations, including two-word pads. They are not free gaps. Reclaiming only object bodies leaks pads; treating pads as free corrupts pointers.
- Reject capability pointers in the first storage implementation. Define durable references separately if needed.
- A compacted message is not automatically canonical. Use a proven canonicalizer before hashing/signing.

These are design deductions from the format, not experimental interoperability findings.

## 2. Specific failures in the original algorithm

| Original assumption | Failure or missing condition | Repair |
|---|---|---|
| Adjacent free space acts as capacity | Other objects can consume it; repeated forced moves can copy a growing list quadratically | Reserve actual owned capacity; never allocate it to another object |
| `offset -= displacement` handles relocation | Only true when the pointer slot moves and its target stays fixed in the same segment | Decode the target first, then encode from the new slot; use a far-pointer path across segments |
| Only the moved object's handle is invalidated | Moving a neighbor invalidates that neighbor; moving a parent moves child ownership slots | Remove neighbor evacuation initially; use IDs and repair child ownership metadata |
| Composite-list write ordering protects readers | A reader can cache the old pointer, then read the new tag | Lock, or keep each published list representation immutable |
| Copy-and-swing creates snapshots | An old root still sees edits to a mutable descendant | Immutable versions plus ancestor copying and one root publication, or locked reads |
| Atomic aligned store provides durability | CPU atomicity is not a storage failure guarantee | Recovery journal or fully specified durable version publication |
| Fixed-time quarantine protects readers | A paused reader can outlive any timeout | Registered reader lifetimes, locks, or immutable files |
| Full tree walk faults every page | Primitive payload interiors need not be read to determine extents | Measure pages containing metadata separately from payload pages |
| Subtree move is one store | Detachment and attachment touch two slots; cycle checks and landing-pad allocation may be necessary | Treat the move as an exclusive transaction |
| A root address is enough for deferred deletion | Struct/list shape is carried by pointer metadata; an empty object may have no body | Queue the decoded descriptor and pad ownership, not just an address |

Three small counterexamples are included in `model.py`:

1. **Composite list:** a reader loads a pointer describing four element-words and pauses. The writer publishes five words, then changes the tag to five elements. The reader resumes and sees `5 × 1 > 4`. Writer ordering cannot prevent this mixed-version observation.
2. **Text:** an old reader has a three-byte view of `ab\0`. Appending `c` overwrites byte two before publication. The old view now ends in `c`, not zero. Retaining the old pointer does not retain its former representation.
3. **Soft reservations:** an adversary takes every newly reserved tail before the next append. Copying lengths `1,2,…,N−1` costs `N(N−1)/2` words. Geometric capacity does not help if it is repeatedly revoked.

These are constructed schedules and cost models, not tests involving actual concurrent stock readers.

## 3. Reconstructed exclusive editor

### State and invariants

Use a single writer with exclusive access to the entire mutable message. All borrowed views end before structural mutation.

Maintain:

- `ObjectId -> {segment, start, logical_words, capacity_words, shape, owner, generation}`.
- `owner = (parent_id, slot_index)` where possible, rather than a permanently cached raw address. Composite-element slots also need an element index and pointer-field index.
- Free extents indexed both by `(segment,start)` and `(length,segment,start)`.
- Optional location-to-ID index for resolving children during schema-independent traversal.
- A queue of detached descriptors for deferred reclamation.

A live extent includes its private capacity. Free extents never overlap any live capacity, landing pad, retired extent or reclamation queue entry. Newly exposed logical contents are initialized before publication. Committed pointer metadata matches object layout. Each reachable nonempty object has exactly one owner within the edited version; no cycles or partial overlaps are permitted.

Zero-on-allocation is sufficient. Zeroing every freed byte immediately is a policy, not a wire requirement. If exporting the whole arena, scrub unreachable bytes or compact to prevent leaking residue. A private reservation may be zeroed lazily before use.

### Opening an existing message

Validate segment bounds, checked size arithmetic and every reachable pointer. Collect intervals for objects and landing pads; detect overlaps and repeated ownership. Account specially for empty bodies and embedded composite elements rather than inserting spurious independent extents. Limit depth, traversal work, object count and zero-sized-list work. Reject cycles and unsupported capability pointers.

A sort-and-scan implementation costs `O(K log K + P)` time and `O(K)` metadata for K physical extents and P inspected pointer slots. It is not an O(1) open. The scan may skip most bytes of large scalar blobs. A trusted persisted allocation map can reduce startup work only when its generation is covered by the same durable commit protocol as the data.

On rebuild, unreachable slack becomes free; the old owner's capacity cannot be inferred from the wire. Reconstructed objects start with logical capacity unless a verified allocator checkpoint restores larger capacity.

### Allocation and growth

```text
ensure_capacity(id, requested_words):
    o = objects[id]
    if requested_words <= o.capacity_words:
        return

    desired = max(requested_words, 2 * max(o.capacity_words, 1))
    check layout limits, segment limits, and arithmetic overflow

    if free extent at o.start + o.capacity_words fits desired - o.capacity_words:
        remove that extent from both free indexes
        extend o's private capacity, split any remainder
        return

    destination = allocate_best_fit(desired)
    if unavailable:
        allocate a bounded new segment and destination
        # Or return allocation failure without changing the live graph.

    preflight all outgoing edges and required landing pads
    build destination from old logical contents
    re-encode outgoing pointers from their new slots
    repair affected child owner records and location indexes
    redirect owner's pointer to destination
    update o's location and generation
    release old body/capacity and obsolete pads
```

Run this as an exception-safe exclusive operation. All fallible allocations, pad reservations and validation happen before the first destructive change. Retain enough temporary state to roll back metadata if construction fails. The executable model assumes successful allocation; it is not an exception-safety implementation.

Do not move live neighbors on the foreground path initially. It creates surprising invalidation and potentially long chains of evacuations. If later introduced, give each operation a byte/pointer budget and charge all such movement to that budget, not to the geometric append proof.

### Relocation and pointer repair

For each pointer slot, obtain its logical target before modifying source bytes. Compute:

```text
new_offset = target_word - new_slot_word - 1
```

This directly handles insert/erase shifts and avoids guessing signs. It is the old offset minus slot displacement only when the target did not move. If the target also moved, use its new address. Null, empty, far and capability encodings need separate cases. A copied far pointer remains valid only while its landing pad and target remain live at those locations.

Across segments, re-encode edges even when the old relative offset appears numerically plausible: the segment interpretation has changed. Plan any landing-pad allocations before publication. When a parent moves, update every child's owner-slot information or resolve it through parent identity. The child's body staying still does not make its former inbound slot valid.

### Editing details

- Append fixed-stride elements: ensure capacity, initialize new elements, then update logical metadata under the lock. Keep capacity on ordinary shrink; use hysteresis for explicit trimming.
- Text append: validate added UTF-8 as required, replace the old terminator with new content, and place the new terminator. This is an exclusive mutation.
- Erase pointer-bearing elements: detach their child descriptors before shifting; move remaining words, repair moved edges, clear vacated slots. Shrinking a pointer list must reclaim removed children.
- Insert in packed Boolean lists: shift bits, not merely words. Preserve unaffected bits and clear newly exposed/padding bits as appropriate.
- Struct widening: shift the pointer section, repair edges and owner slots, clear the newly exposed data gap, initialize added pointer slots, then publish the new layout.
- Composite widening: calculate new stride and total size with checked arithmetic; initialize each new layout and repair its pointer fields. A fresh destination is a simpler first implementation than overlapping reverse expansion.
- Move subtree: reject moving under its own descendant, prepare destination encoding, detach and attach while exclusively locked. Without a separate ancestry index, the cycle check can cost `O(height)` or more.
- Deferred deletion: save a complete descriptor, clear the owner slot, then incrementally scan children. Do not release a parent before saving unprocessed pointer contents. Bound work in pointer slots and bytes; a single huge node must not defeat the pause budget.

## 4. Why the exclusive version is correct

Proof sketch under the preceding invariants:

1. Allocation chooses a disjoint, exclusively owned extent. Constructing it cannot change a live object.
2. Copying scalars preserves values. Encoding every edge against the unchanged target preserves the graph relation, regardless of the source object's new location.
3. Correcting owner records ensures future edits patch the actual owning slots.
4. Redirecting the unique owner makes the new body reachable and the old body unreachable. Exclusive access prevents readers from observing intermediate states.
5. Releasing only unreachable bodies preserves all reachable contents. Keeping unused capacity private makes later in-capacity growth disjoint from other objects.

Inductively, each successful operation preserves representation and ownership. This is a design argument plus bounded experimental evidence, not a machine-checked proof of the full format.

## 5. Concurrency: select an explicit contract

| Mode | Reader contract | Editing method |
|---|---|---|
| Exclusive v1 | All readers hold a shared lock; writer holds exclusive lock | In-place mutation and immediate safe reuse |
| Immutable published version | Pin a version through a cooperative acquisition protocol | Copy changed bodies and ancestors; publish one root descriptor |
| Immutable export file | Open a stable completed file | Write new file, then replace published name with platform-appropriate durability |

An aligned atomic writer store does not make stock non-atomic loads a supported concurrent API. In Rust, data races and invalid aliasing remain undefined behavior inside unsafe code. Borrowed stock reader views should therefore refer to immutable or locked bytes. [Rust Reference](https://doc.rust-lang.org/reference/behavior-considered-undefined.html)

RCU postpones reclamation until readers finish; it does not automatically freeze an entire mutable object graph or define transaction semantics. [Linux RCU documentation](https://www.kernel.org/doc/html/latest/RCU/whatisRCU.html)

For immutable versions, acquire/pin the root without an acquisition-versus-reclamation race, retain all transitively reachable storage, copy each modified ancestor once per transaction, and publish one complete descriptor. Sharing between different versions needs version-aware allocation accounting. A single global `object -> owner` record no longer suffices when immutable subtrees have owners in multiple versions. Long readers retain storage; that cost must be budgeted.

Copy-on-write can be expensive: updating one element inside a large inline list may copy the whole list and large ancestors. If frequent small edits and snapshots are core requirements, use bounded records/chunks with a transactional index. That changes the application schema/container rather than making a flat list magically cheap.

## 6. mmap and durability

Recommended first persistent design: **bounded segments in a custom container, locked access, and a recovery journal**. Export ordinary framed Cap’n Proto when required. This preserves object encoding compatibility while acknowledging that a stock stream reader cannot directly interpret the custom container.

For one fixed-size segment, an ordinary framed file can be edited under locks without resizing its header. This is a useful simpler interoperability target. Adding/growing segments requires a real framing and mapping policy.

Use offset-based handles even if virtual address space is reserved. Reserve/map page-aligned extents, account for the stream header, and do not extend mappings from an arbitrary object boundary. Mapping lifetime is part of the reader lock/version contract. `MAP_PRIVATE` is not a guaranteed immutable snapshot of a file another process continues to modify. [Linux mmap documentation](https://man7.org/linux/man-pages/man2/mmap.2.html)

### Conservative undo-journal protocol (design, not implemented here)

1. Acquire the exclusive transaction lock; perform recovery before exposing a database with an unfinished journal.
2. Plan the complete write set. For every existing storage unit that may change, preserve its old contents. Include allocator metadata, roots, headers, truncation/growth metadata and any shared sector protection required by the storage assumptions.
3. Write a complete, checksummed undo journal with database identity, transaction generation, original length and recovery records. Durably publish its active state before the first database mutation. If creating files, include required directory durability.
4. Apply changes to the mapping. `MAP_SHARED` pages may be written back at any time, so step 3 must precede the stores, not merely the final flush.
5. Flush and durably synchronize changed data and necessary file metadata. Treat every error as a failed commit requiring recovery.
6. Durably mark the journal transaction committed using a defined recoverable record protocol. Only then acknowledge success and release locks. Journal cleanup/reuse must not revive an older transaction.
7. On recovery, a valid active uncommitted journal restores old contents and length, durably. A committed journal keeps the new version. Recovery itself must be idempotent across repeated failures.

This needs a concrete on-disk log format, sector-failure assumptions and crash tests before implementation is called safe. SQLite's design explains why rollback logging, write ordering and torn-sector assumptions matter. [SQLite atomic commit](https://www.sqlite.org/atomiccommit.html) File synchronization alone also does not ensure a new directory entry is durable. [Linux fsync documentation](https://man7.org/linux/man-pages/man2/fsync.2.html)

Do not promise two barriers per arbitrary multi-object transaction. Costs depend on the journal/commit protocol. Do not infer durable atomicity from 8-byte CPU alignment.

Hole punching is optional background reclamation only after reader and recovery requirements release those pages. It must not affect live or reserved data sharing a page. Linux supports punching ranges with filesystem-dependent constraints. [Linux fallocate documentation](https://man7.org/linux/man-pages/man2/fallocate.2.html) Do not use deallocation to bypass journaling for still-recoverable bytes.

## 7. Performance model

Let W be the body's logical words, P its pointer slots, F free extents, and N append operations. For fixed-width elements with retained doubling capacity, relocated bodies have capacities approximately `1,2,4,…`; total copied words are less than twice the final capacity scale. Aggregate relocation/initialization work is linear in appended data. Per-operation worst-case latency remains linear in the current object size.

| Operation | Defensible cost |
|---|---|
| Append within private capacity | O(element width), plus logical metadata update |
| Extend/allocate capacity with balanced indexes | O(log F) allocator work per extent operation |
| Relocate | O(W + P), plus landing-pad/index work; potentially O(P log F) with individual pad allocations |
| Middle insert/erase | O(tail words + moved pointers), plus capacity growth and detached-child reclamation |
| Scalar set under exclusive access | O(1) memory work; durability charged separately |
| Detach subtree | O(1) immediate work if queue space is available; full reclamation costs remain |
| Widen struct | O(P + new words) with room, otherwise relocation cost |
| Snapshot update | Copied changed bodies plus copied ancestor bodies and version bookkeeping |

Thus “amortized O(1) append” means **constant amortized payload work per fixed-width element under retained capacity**, not constant worst-case time, no allocator overhead, no I/O, or constant-time snapshots. Memory pressure that revokes reservations invalidates that bound. Adjacent free-space extension is an optimization, not the proof.

Allocator metadata can dominate small values. A proposed 64-byte descriptor for one million objects already costs about 61 MiB, before free indexes, allocation overhead, pads, versions and journals. Measure actual Rust layouts and collections. Keep simple scalar mutations off allocator indexes; index extents on structural changes only.

## 8. Reproduction and validation limits

Run from this directory:

```sh
python3 model.py
g++ -O3 -std=c++17 -Wall -Wextra -o /tmp/eae-bench bench.cpp
/tmp/eae-bench
```

`model.py` encodes real near-pointer words for a limited schema: root pointer-only struct, eight pointer lists, and one-word leaf structs. It compares wire traversal with an independent logical list model after every randomized edit, and checks allocation coverage, overlap, zeroed slack/free space and owner locations. Operations include insert, erase, swapping disjoint subtrees, parent relocation and list relocation. It also checks signed-offset boundaries and emits a standard-framed sample.

`bench.cpp` is a native **allocator/list-growth experiment**, not the complete wire editor. It uses two free-space indexes, private capacity, adjacent extension, best-fit relocation, coalescing and eager zero-on-free. It measures scalar lists only. Arena allocation and initialization are outside timing; the vector baseline reserves capacity outside timing. EAE timing includes a final linear content check; the vector checks its last value. These asymmetries and the shared host preclude speedup claims. Counters are more useful than absolute timings here. The exact-size comparator deliberately reallocates on every append; it is **not a benchmark of the stock Cap’n Proto builder**.

Not tested: a stock Cap’n Proto reader/canonicalizer, far/double-far handling, empty-value semantics beyond the restricted schema, general composite/Boolean/Text mutation, malformed-input import, Rust aliasing, error rollback, real mmap, concurrency, journaling, disk fault injection or power loss. Rust and Cap’n Proto tooling were not installed in the available environment; the native experiment uses GCC. These are explicit validation gates, not implied passes.

For a production gate, add differential tests against at least one stock runtime for every supported layout and upgrade; forced allocation failures at each preflight step; reader/writer schedule testing; truncated and torn log/data simulation; repeated crashes during recovery; and realistic workloads measuring p50/p99 latency, copied bytes, dirty pages, fragmentation, open time and retained-version space. Stop claiming snapshot support until immutable-version ownership and root acquisition are implemented and tested.

## 9. Results obtained in this session

All 30,000 randomized operations passed, across 30 deterministic seeds. The runs performed 8,836 relocations and copied 127,113 logical words. Each operation was checked against the logical model and allocator invariants. Signed near-offset boundary tests passed.

Native run: Linux x86-64, GCC 13.3.0, `-O3`, median of seven repetitions. Arena backing size: 64 MiB. Timings are local observations, not portable estimates.

| Workload | Appends | Median ms | Copied words | Zeroed words | Allocation/move count | Arena high-water words |
|---|---:|---:|---:|---:|---:|---:|
| eae_single | 1000000 | 6.03734 | 0 | 0 | 1 | 1048576 |
| eae_interleaved64 | 1000000 | 7.1976 | 1032160 | 1032160 | 951 | 1081278 |
| std_vector_reserved | 1000000 | 2.17782 | 0 | 0 | 0 | 0 |
| exact_relocate_each_append | 20000 | 87.6967 | 199990000 | 199990000 | 20000 | 59994 |

Zero counters for the vector baseline mean not instrumented/not applicable, not zero allocation or data movement. The arena high-water counter is an address extent, not resident memory: all arena runs pre-initialize the full backing array outside timing.

The interleaved case copied 8,257,280 bytes for 8,000,000 appended payload bytes, with the same number of bytes eagerly cleared after relocation. That is about 1.032 copied words per append. One unobstructed list grew entirely in place after its first allocation. The exact-size comparator copied 1,599,920,000 bytes for only 160,000 appended payload bytes. These counters demonstrate the geometric-growth benefit in the chosen workloads; they do not establish performance under adversarial fragmentation, pointer-heavy graphs or durable commits.

**Implementation decision:** proceed with a Rust exclusive editor using stable object IDs, private retained capacity and bounded segments. Keep neighbor evacuation disabled. Treat crash recovery and immutable snapshots as separate components with separate acceptance tests.
